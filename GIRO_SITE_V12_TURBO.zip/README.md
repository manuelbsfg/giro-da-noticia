Giro da Notícia V12 Turbo

Melhorias: progresso real do FFmpeg, renderização otimizada com crop antes do scale, textos pré-renderizados em frame estático, sem alterar PADRAO_GIRO_V1.
