GIRO DA NOTÍCIA V13
- Corrige erro cannot open resource com descoberta robusta da fonte DejaVu.
- Legendas aparecem automaticamente dentro das caixas brancas na prévia assim que ficam prontas.
- Mantém PADRAO_GIRO_V1 bloqueado.
