const CACHE="cortes-auto-v724-render-recovery";
const SHELL=["/","/static/template_overlay.png","/manifest.webmanifest"];

self.addEventListener("install",event=>{
  event.waitUntil(
    caches.open(CACHE)
      .then(cache=>cache.addAll(SHELL))
      .then(()=>self.skipWaiting())
  );
});

self.addEventListener("activate",event=>{
  event.waitUntil((async()=>{
    const keys=await caches.keys();
    await Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)));
    if(self.registration.navigationPreload){
      try{await self.registration.navigationPreload.enable()}catch(_){}
    }
    await self.clients.claim();
  })());
});

self.addEventListener("message",event=>{
  const type=event.data&&event.data.type;
  if(type==="SKIP_WAITING") self.skipWaiting();
  if(type==="CLEAR_CACHE"){
    event.waitUntil(caches.keys().then(keys=>Promise.all(keys.map(k=>caches.delete(k)))));
  }
});

async function networkFirstNavigation(event){
  try{
    const preload=await event.preloadResponse;
    if(preload&&preload.ok){
      const copy=preload.clone();
      caches.open(CACHE).then(c=>c.put("/",copy)).catch(()=>{});
      return preload;
    }
    const controller=new AbortController();
    const timer=setTimeout(()=>controller.abort(),8000);
    try{
      const res=await fetch(event.request,{cache:"no-store",signal:controller.signal});
      if(res&&res.ok){
        const copy=res.clone();
        caches.open(CACHE).then(c=>c.put("/",copy)).catch(()=>{});
      }
      return res;
    }finally{clearTimeout(timer)}
  }catch(_){
    return (await caches.match("/"))||new Response("Sem conexão. Abra novamente quando a internet voltar.",{
      status:503,headers:{"Content-Type":"text/plain; charset=utf-8","Cache-Control":"no-store"}
    });
  }
}

async function staleWhileRevalidate(req){
  const cache=await caches.open(CACHE);
  const hit=await cache.match(req);
  const fetchPromise=fetch(req).then(res=>{
    if(res&&res.ok&&res.type!=="opaque")cache.put(req,res.clone()).catch(()=>{});
    return res;
  }).catch(()=>null);
  return hit||(await fetchPromise)||new Response("",{status:504});
}

self.addEventListener("fetch",event=>{
  const req=event.request;
  const url=new URL(req.url);
  if(req.method!=="GET"||url.origin!==self.location.origin)return;
  if(req.headers.has("range"))return;
  if(url.pathname.startsWith("/api/")||url.pathname.startsWith("/download/")||url.pathname.startsWith("/preview/"))return;
  if(req.mode==="navigate"){
    event.respondWith(networkFirstNavigation(event));
    return;
  }
  if(url.pathname.startsWith("/static/")||url.pathname==="/manifest.webmanifest"){
    event.respondWith(staleWhileRevalidate(req));
  }
});
