import os, re, json, uuid, time, threading, subprocess, shutil, hashlib, sqlite3, math, atexit, resource, base64
import urllib.request, urllib.error
from urllib.parse import quote
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from flask import Flask, request, jsonify, send_file, send_from_directory, g
try:
    from faster_whisper import WhisperModel
    WHISPER_AVAILABLE = True
except Exception:
    WhisperModel = None
    WHISPER_AVAILABLE = False
from PIL import Image, ImageDraw, ImageFont

# V7.19: funciona tanto em servidor Linux quanto no Termux/Android.
# Por padrão os dados ficam ao lado deste server.py; CORTES_BASE pode sobrescrever.
BASE = Path(os.getenv("CORTES_BASE", str(Path(__file__).resolve().parent))).expanduser().resolve()
STATIC = BASE / "static"
DATA = BASE / "data"
UPLOADS = DATA / "uploads"
OUTPUTS = DATA / "outputs"
TMP = DATA / "tmp"
CHUNKS = DATA / "chunks"
MODELS = BASE / "models"
CACHE = DATA / "cache"
DB = DATA / "state.sqlite3"
def _resolve_binary(env_name, name):
    configured=(os.getenv(env_name, "") or "").strip()
    if configured:
        return configured
    bundled=BASE / "bin" / name
    if bundled.is_file():
        return str(bundled)
    return shutil.which(name) or name

FFMPEG = _resolve_binary("FFMPEG_BIN", "ffmpeg")
FFPROBE = _resolve_binary("FFPROBE_BIN", "ffprobe")
TEMPLATE = STATIC / "template_overlay.png"
FONT_CANDIDATES = [
    os.getenv("CAPTION_FONT", ""),
    "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
    "/usr/share/fonts/truetype/liberation2/LiberationSans-Bold.ttf",
    "/usr/share/fonts/truetype/freefont/FreeSansBold.ttf",
    "/usr/share/fonts/opentype/noto/NotoSans-Bold.ttf",
    "/system/fonts/Roboto-Bold.ttf",
    "/system/fonts/RobotoCondensed-Bold.ttf",
    "/data/data/com.termux/files/usr/share/fonts/TTF/DejaVuSans-Bold.ttf",
    "/data/data/com.termux/files/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
]

def _resolve_caption_font():
    for candidate in FONT_CANDIDATES:
        if candidate and Path(candidate).is_file():
            return candidate
    # Last attempt: ask fontconfig for a genuinely bold sans font.
    try:
        out=subprocess.check_output(["fc-match","-f","%{file}","sans:style=Bold"],text=True,timeout=2).strip()
        if out and Path(out).is_file():
            return out
    except Exception:
        pass
    return ""

PYFONT = _resolve_caption_font()
CAPTION_STYLE_VERSION = "v7.19-termux-bold-font-lock-1"
PIPELINE_VERSION = "v7.20"
PERFORMANCE_BUILD = "v7.23"

# V7.18 — Gemini no servidor. A chave nunca é enviada ao navegador.
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "").strip()
GEMINI_TRANSCRIBE_MODEL = os.getenv("GEMINI_TRANSCRIBE_MODEL", "gemini-3.5-transcribe").strip() or "gemini-3.5-transcribe"
GEMINI_CAPTION_MODEL = os.getenv("GEMINI_CAPTION_MODEL", "gemini-3.8-flash").strip() or "gemini-3.8-flash"
GEMINI_TIMEOUT = max(15, min(240, int(os.getenv("GEMINI_TIMEOUT", "90"))))
GEMINI_MAX_INLINE_AUDIO_BYTES = max(1024*1024, int(os.getenv("GEMINI_MAX_INLINE_AUDIO_BYTES", str(18*1024*1024))))
GEMINI_ENABLED = bool(GEMINI_API_KEY)

# V7.23 — fallback cloud para o Render. O serviço online já pode ter GROQ_API_KEY
# configurada desde as versões anteriores. Gemini continua sendo a prioridade.
GROQ_API_KEY = os.getenv("GROQ_API_KEY", "").strip()
GROQ_STT_MODEL = os.getenv("GROQ_STT_MODEL", "whisper-large-v3-turbo").strip() or "whisper-large-v3-turbo"
GROQ_TEXT_MODEL = os.getenv("GROQ_TEXT_MODEL", "openai/gpt-oss-20b").strip() or "openai/gpt-oss-20b"
GROQ_TIMEOUT = max(15, min(240, int(os.getenv("GROQ_TIMEOUT", "90"))))
GROQ_ENABLED = bool(GROQ_API_KEY)

for d in (STATIC, DATA, UPLOADS, OUTPUTS, TMP, CHUNKS, MODELS, CACHE):
    d.mkdir(parents=True, exist_ok=True)

app = Flask(__name__, static_folder=str(STATIC), static_url_path="/static")
app.config["MAX_CONTENT_LENGTH"] = 2 * 1024 * 1024 * 1024
app.config["SEND_FILE_MAX_AGE_DEFAULT"] = 0

def client_ip():
    forwarded=(request.headers.get("CF-Connecting-IP") or request.headers.get("X-Forwarded-For") or "").split(",")[0].strip()
    return forwarded or request.remote_addr or "unknown"

def mutation_rate_ok(limit=None,bucket_suffix="default"):
    if request.method not in ("POST","PUT","PATCH","DELETE"):
        return True,0
    limit=max(1,int(limit or RATE_MAX_MUTATIONS))
    now=time.time(); ip=client_ip(); key=ip+":"+str(bucket_suffix)
    with rate_lock:
        bucket=rate_buckets.setdefault(key,[])
        cutoff=now-RATE_WINDOW
        while bucket and bucket[0]<cutoff: bucket.pop(0)
        if len(bucket)>=limit:
            retry=max(1,int(RATE_WINDOW-(now-bucket[0])))
            return False,retry
        bucket.append(now)
        # Bound memory from stale IPs opportunistically.
        if len(rate_buckets)>2048:
            stale=[k for k,v in rate_buckets.items() if not v or v[-1]<cutoff]
            for k in stale[:512]: rate_buckets.pop(k,None)
    return True,0

@app.before_request
def request_context():
    g.request_started=time.perf_counter()
    rid=request.headers.get("X-Request-ID") or uuid.uuid4().hex[:12]
    g.request_id=re.sub(r"[^A-Za-z0-9_-]","",rid)[:64] or uuid.uuid4().hex[:12]
    if request.path.startswith("/api/"):
        if request.method in ("POST","PUT","PATCH","DELETE") and request.headers.get("Sec-Fetch-Site")=="cross-site":
            return api_error("Solicitação cross-site bloqueada.",403)
        upload_chunk=request.path=="/api/upload/chunk"
        ok,retry=mutation_rate_ok(RATE_UPLOAD_MUTATIONS if upload_chunk else RATE_MAX_MUTATIONS,"upload" if upload_chunk else "default")
        if not ok:
            resp=jsonify({"error":"Muitas solicitações em pouco tempo.","retry_after":retry,"request_id":g.request_id})
            resp.status_code=429; resp.headers["Retry-After"]=str(retry)
            return resp

jobs = {}
jobs_lock = threading.RLock()
_job_persist_state = {}
_job_persist_lock = threading.Lock()
worker = ThreadPoolExecutor(max_workers=1, thread_name_prefix="heavy")
atexit.register(lambda: worker.shutdown(wait=False,cancel_futures=False))
models = {}
model_lock = threading.Lock()
_template_lock = threading.Lock()
_template_rgba = None
_font_cache = {}
_font_lock = threading.Lock()
recovery_done = False
recovery_lock = threading.Lock()
rate_lock = threading.Lock()
rate_buckets = {}
telemetry_lock = threading.Lock()
telemetry = {
    "requests":0,"http_errors":0,"api_requests":0,
    "avg_request_ms":0.0,"max_request_ms":0.0,
    "cache_hits":0,"cache_misses":0,"cache_puts":0
}
RATE_WINDOW = 60.0
RATE_MAX_MUTATIONS = int(os.getenv("RATE_MAX_MUTATIONS","240"))
RATE_UPLOAD_MUTATIONS = int(os.getenv("RATE_UPLOAD_MUTATIONS","1200"))

ALLOWED = {".mp4", ".mov", ".m4v", ".webm", ".3gp", ".mkv"}
VALID_MODES = {"fast","smart","quality"}
MAX_QUEUE = int(os.getenv("MAX_HEAVY_QUEUE","20"))
MIN_FREE_DISK = int(os.getenv("MIN_FREE_DISK_BYTES",str(512*1024*1024)))
MAX_CHUNK_BYTES = int(os.getenv("MAX_CHUNK_BYTES",str(8*1024*1024)))
MAX_UPLOAD_BYTES = int(app.config["MAX_CONTENT_LENGTH"])
MAX_CACHE_BYTES = int(os.getenv("MAX_CACHE_BYTES",str(8*1024*1024*1024)))
MAX_JOB_MEMORY = int(os.getenv("MAX_JOB_MEMORY","500"))
_cleanup_last = 0.0
_cleanup_lock = threading.Lock()

def db_conn():
    c = sqlite3.connect(DB, timeout=30)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA journal_mode=WAL")
    c.execute("PRAGMA synchronous=NORMAL")
    c.execute("PRAGMA busy_timeout=30000")
    return c

def init_db():
    with db_conn() as c:
        c.execute("""CREATE TABLE IF NOT EXISTS jobs(
            id TEXT PRIMARY KEY, kind TEXT, file_id TEXT, status TEXT, progress INTEGER,
            message TEXT, error TEXT, result_json TEXT, payload_json TEXT,
            cancel_requested INTEGER DEFAULT 0, created_at REAL, updated_at REAL)""")
        c.execute("""CREATE TABLE IF NOT EXISTS cache(
            cache_key TEXT PRIMARY KEY, kind TEXT, value_json TEXT, file_path TEXT,
            created_at REAL, last_used REAL)""")
        c.execute("CREATE INDEX IF NOT EXISTS idx_jobs_status_updated ON jobs(status,updated_at)")
        c.execute("CREATE INDEX IF NOT EXISTS idx_jobs_kind_updated ON jobs(kind,updated_at)")
        c.execute("CREATE INDEX IF NOT EXISTS idx_cache_last_used ON cache(last_used)")

init_db()

def persist_job(j):
    with db_conn() as c:
        c.execute("""INSERT INTO jobs(id,kind,file_id,status,progress,message,error,result_json,payload_json,
                     cancel_requested,created_at,updated_at)
                     VALUES(?,?,?,?,?,?,?,?,?,?,?,?)
                     ON CONFLICT(id) DO UPDATE SET
                     kind=excluded.kind,file_id=excluded.file_id,status=excluded.status,
                     progress=excluded.progress,message=excluded.message,error=excluded.error,
                     result_json=excluded.result_json,payload_json=excluded.payload_json,
                     cancel_requested=excluded.cancel_requested,updated_at=excluded.updated_at""",
                  (j["id"],j["kind"],j["file_id"],j["status"],int(j.get("progress") or 0),
                   j.get("message"),j.get("error"),json.dumps(j.get("result"),ensure_ascii=False),
                   json.dumps(j.get("payload") or {},ensure_ascii=False),1 if j.get("cancel_requested") else 0,
                   j.get("created_at") or time.time(),j.get("updated_at") or time.time()))

def row_to_job(r):
    if not r: return None
    return {
        "id":r["id"],"kind":r["kind"],"file_id":r["file_id"],"status":r["status"],
        "progress":int(r["progress"] or 0),"message":r["message"],"error":r["error"],
        "result":json.loads(r["result_json"] or "null"),"payload":json.loads(r["payload_json"] or "{}"),
        "cancel_requested":bool(r["cancel_requested"]),"created_at":r["created_at"],"updated_at":r["updated_at"]
    }

def job_update(jid, **kwargs):
    now=time.time()
    with jobs_lock:
        j = jobs.get(jid)
        if not j:
            with db_conn() as c:
                r = c.execute("SELECT * FROM jobs WHERE id=?", (jid,)).fetchone()
            j = row_to_job(r)
            if not j: return
            jobs[jid] = j
        old_status=j.get("status"); old_progress=int(j.get("progress") or 0); old_message=j.get("message")
        j.update(kwargs); j["updated_at"]=now
        new_status=j.get("status"); new_progress=int(j.get("progress") or 0); new_message=j.get("message")
        force=(new_status!=old_status or new_status in ("done","error","cancelled") or new_message!=old_message)
        with _job_persist_lock:
            prev=_job_persist_state.get(jid,(0.0,-1))
            should=force or new_progress>=100 or new_progress-prev[1]>=3 or now-prev[0]>=1.5
            if should:
                _job_persist_state[jid]=(now,new_progress)
        if should: persist_job(j)

def get_job(jid):
    with jobs_lock:
        j = jobs.get(jid)
        if j: return dict(j)
    with db_conn() as c:
        r = c.execute("SELECT * FROM jobs WHERE id=?", (jid,)).fetchone()
    j = row_to_job(r)
    if j:
        with jobs_lock: jobs[jid] = j
        return dict(j)
    return None

def cancelled(jid):
    j = get_job(jid)
    return bool(j and j.get("cancel_requested"))

def safe_name(name):
    name = os.path.basename(name or "video.mp4")
    name = re.sub(r"[^A-Za-z0-9._ -]+", "_", name)
    return name[:160] or "video.mp4"

def atomic_json_write(path,data):
    path=Path(path); tmp=path.with_suffix(path.suffix+".tmp")
    tmp.write_text(json.dumps(data,ensure_ascii=False,separators=(",",":")),"utf-8")
    os.replace(tmp,path)

def free_disk_ok():
    try:
        return shutil.disk_usage(DATA).free >= MIN_FREE_DISK
    except Exception:
        return True

def upload_meta_path(fid): return UPLOADS / (fid + ".json")

def load_upload(fid):
    p = upload_meta_path(fid)
    if not p.exists(): return None
    try:
        meta = json.loads(p.read_text("utf-8"))
        path = Path(meta["path"])
        if not path.exists(): return None
        meta["path"] = str(path)
        return meta
    except Exception:
        return None

def sha256_file(path):
    h = hashlib.sha256()
    with open(path,"rb") as f:
        for b in iter(lambda:f.read(1024*1024), b""):
            h.update(b)
    return h.hexdigest()

def probe(path):
    cmd=[FFPROBE,"-v","error","-show_entries","format=duration:stream=codec_type,codec_name,width,height,avg_frame_rate,sample_rate,channels,channel_layout,bit_rate",
         "-of","json",str(path)]
    try:
        r=subprocess.run(cmd,capture_output=True,text=True,timeout=30)
        data=json.loads(r.stdout or "{}")
        duration=float((data.get("format") or {}).get("duration") or 0)
        width=height=0; has_audio=False; video_codec=""; audio_codec=""; fps=0.0
        audio_rate=0; audio_channels=0; audio_layout=""; audio_bitrate=0
        for st in data.get("streams",[]):
            if st.get("codec_type")=="video" and not width:
                width=int(st.get("width") or 0); height=int(st.get("height") or 0)
                video_codec=str(st.get("codec_name") or "")
                fr=str(st.get("avg_frame_rate") or "0/1")
                try:
                    a,b=fr.split("/",1); fps=float(a)/max(1.0,float(b))
                except Exception: fps=0.0
            if st.get("codec_type")=="audio" and not has_audio:
                has_audio=True; audio_codec=str(st.get("codec_name") or "")
                try: audio_rate=int(st.get("sample_rate") or 0)
                except Exception: audio_rate=0
                try: audio_channels=int(st.get("channels") or 0)
                except Exception: audio_channels=0
                audio_layout=str(st.get("channel_layout") or "")
                try: audio_bitrate=int(st.get("bit_rate") or 0)
                except Exception: audio_bitrate=0
        return {"duration":duration,"width":width,"height":height,"has_audio":has_audio,
                "video_codec":video_codec,"audio_codec":audio_codec,"fps":round(fps,3),
                "audio_sample_rate":audio_rate,"audio_channels":audio_channels,
                "audio_layout":audio_layout,"audio_bitrate":audio_bitrate}
    except Exception:
        return {"duration":0,"width":0,"height":0,"has_audio":False}

def detect_encoder():
    try:
        r=subprocess.run([FFMPEG,"-hide_banner","-encoders"],capture_output=True,text=True,timeout=10)
        txt=r.stdout+r.stderr
        if "h264_nvenc" in txt and shutil.which("nvidia-smi"):
            return "h264_nvenc"
    except Exception: pass
    return "libx264"

ENCODER = detect_encoder()
PROCESS_STARTED=time.time()

def get_model(name):
    if not WHISPER_AVAILABLE or WhisperModel is None:
        raise RuntimeError("Whisper não está instalado neste servidor; Gemini continua disponível se GEMINI_API_KEY estiver configurada.")
    model_name = "small" if name=="small" else "base"
    if model_name in models: return models[model_name]
    with model_lock:
        if model_name not in models:
            models[model_name] = WhisperModel(
                model_name,device="cpu",compute_type="int8",download_root=str(MODELS),
                cpu_threads=max(2,min(6,os.cpu_count() or 4)),num_workers=1)
    return models[model_name]

def clean_text(text):
    text=re.sub(r"\s+"," ",text or "").strip()
    return re.sub(r"^[,.;:!? -]+|[,.;:!? -]+$","",text)

def trim_words(text,n):
    w=clean_text(text).split()
    out=w[:n]
    dangling={"de","da","do","das","dos","no","na","nos","nas","em","para","por","com","que","e","mas","ou","a","o"}
    while len(out)>4 and out[-1].lower().strip(",.;:!?") in dangling:
        out.pop()
    return " ".join(out)

# V7.13: guarda rígida para impedir que mensagens internas da IA ou
# chamadas genéricas virem legenda final. Diagnóstico deve ficar na UI,
# nunca nas caixas brancas do vídeo.
_CAPTION_META_PATTERNS = (
    r"\ba\s+ia\b", r"evid[eê]ncia\s+(?:insuficiente|suficiente)",
    r"n[aã]o\s+(?:foi\s+poss[ií]vel|encontrou|h[aá])", r"afirmar\s+um\s+fato",
    r"sem\s+evid[eê]ncia", r"conte[uú]do\s+insuficiente",
    r"informa[cç][aã]o\s+insuficiente", r"precisa\s+de\s+revis[aã]o",
    r"n[aã]o\s+consigo", r"modelo\s+(?:n[aã]o|de\s+ia)",
)
_CAPTION_GENERIC_PATTERNS = (
    r"^v[ií]deo\s+(?:traz|mostra|apresenta|explica)\b",
    r"\b(?:um|o)\s+relato\b", r"\bcontexto\s+da\s+situa[cç][aã]o\b",
    r"\bexplica\s+o\s+contexto\b", r"\bmais\s+detalhes\s+da\s+situa[cç][aã]o\b",
    r"\bqueria\s+falar\s+(?:uma|de\s+uma)\s+coisa\b", r"\b(?:uma|essa)\s+situa[cç][aã]o\s+que\b",
    r"\btentando\s+entender\b", r"\bvou\s+explicar\b", r"\baconteceu\s+uma\s+coisa\b",
)
_CAPTION_STOP={
    "a","o","e","de","da","do","das","dos","em","no","na","nos","nas","um","uma","que","para","por",
    "com","se","é","foi","tem","mais","como","ele","ela","eles","elas","isso","esse","essa","ao","aos","as","os"
}

# V7.16 — a legenda deve nascer da fala real. Esses pesos servem apenas para
# escolher o trecho mais informativo; nenhuma palavra nova é acrescentada.
_CAPTION_ACTION_STEMS=(
    "demit","afast","assum","confirm","neg","anunci","revel","pres","prend","investig",
    "morr","morre","encontr","desapare","acident","denunci","aprov","decid","explic",
    "receb","perd","ganh","sai","entr","cheg","deix","retir","mud","volt","fic","vai",
    "roub","furt","agred","atac","resgat","socorr","intern","hospital","cham","mostr"
)
_CAPTION_VAGUE_WORDS={
    "video","relato","situacao","contexto","assunto","coisa","coisas","negocio","detalhe",
    "detalhes","informacao","informacoes","caso","momento","pessoa","pessoas","fala","falando"
}

def _strip_caption_fillers(text):
    t=clean_text(text)
    if not t: return ""
    # Remove somente bordões de conversa; o conteúdo factual permanece textual.
    for _ in range(3):
        newer=re.sub(r"^(?:bom|olha|gente|tipo|assim|ent[aã]o|a[ií]|da[ií]|sabe|n[eé])[, :;-]*", "", t, flags=re.I)
        if newer==t: break
        t=newer
    t=re.sub(r"^(?:eu\s+acho\s+que|eu\s+quero\s+dizer\s+que|o\s+que\s+eu\s+quero\s+dizer\s+[eé]\s+que)\s+", "", t, flags=re.I)
    t=re.sub(r"(?:,?\s+(?:n[eé]|t[aá]|viu|sabe))?[.!?…]*$", "", t, flags=re.I)
    t=re.sub(r"\b([A-Za-zÀ-ÖØ-öø-ÿ]+)(?:\s+\1){1,2}\b", r"\1", t, flags=re.I)
    return clean_text(t)

def _caption_specificity_score(text):
    words=[w for w in _normalized_words(text) if w not in _CAPTION_STOP and len(w)>=3]
    if not words: return -8.0
    uniq=set(words)
    score=min(3.0,len(uniq)*0.28)
    low=clean_text(text).lower()
    if any(stem in low for stem in _CAPTION_ACTION_STEMS): score+=2.4
    if re.search(r"\b(?:fui|foi|foram|será|sera|deve|vai)\s+(?:demitid|afastad|pres|investigad|internad|substitu|assum)",low): score+=2.0
    if re.search(r"\boutra\s+pessoa\b|\bdeve\s+assumir\b|\benquanto\b",low): score+=1.25
    if any(x in low for x in ("tentando entender","acho que","vou conversar","queria falar","quero dizer","não sei","nao sei")): score-=1.8
    vague=sum(1 for w in words if w in _CAPTION_VAGUE_WORDS)
    score-=vague*0.9
    # Um trecho com quase só palavras vagas nunca deve ganhar de um fato concreto.
    if len(uniq)<=4 and vague>=2: score-=4.0
    return score

def _transcript_caption_candidates(transcript,begin,end,prefer_late=False):
    raw=clean_text(transcript)
    if not raw: return []
    out=[]; seen=set()
    parts=[clean_text(x) for x in re.split(r"(?<=[.!?])\s+|\s+[–—]\s+|;\s+",raw) if clean_text(x)]
    if len(parts)>=2:
        total=max(1,len(parts)-1)
        for i,part in enumerate(parts):
            pos=i/total
            if pos < begin-0.08 or pos > end+0.08: continue
            variants=[part]
            # Vídeos falados frequentemente dividem o fato em duas frases curtas.
            if i+1<len(parts): variants.append(part+" "+parts[i+1])
            for v in variants:
                v=_strip_caption_fillers(v)
                v=trim_words(v,18)
                key=v.lower()
                if not v or key in seen: continue
                seen.add(key)
                sc=_caption_score(v,pos)+_caption_specificity_score(v)
                sc+=(pos*1.5 if prefer_late else (1.0-pos)*0.9)
                out.append({"text":v,"score":sc,"pos":pos,"idx":i,"source":"sentence"})
    # Se a pontuação do Whisper vier pobre, também cria janelas reais da fala.
    words=raw.split()
    if words:
        n=len(words)
        for start in range(0,n,max(5,min(9,n))):
            pos=start/max(1,n-1)
            if pos < begin-0.08 or pos > end+0.08: continue
            for size in (10,14,17):
                v=_strip_caption_fillers(" ".join(words[start:min(n,start+size)]))
                v=trim_words(v,18)
                key=v.lower()
                if len(v.split())<5 or key in seen: continue
                seen.add(key)
                sc=_caption_score(v,pos)+_caption_specificity_score(v)-0.35
                if start+size<n and not re.search(r"[.!?…]$",v): sc-=3.6
                sc+=(pos*0.55 if prefer_late else (1.0-pos)*0.95)
                out.append({"text":v,"score":sc,"pos":pos,"idx":start,"source":"window"})
    out.sort(key=lambda x:x["score"],reverse=True)
    return out[:24]

def _caption_has_meta(text):
    low=clean_text(text).lower()
    return any(re.search(p,low,re.I) for p in _CAPTION_META_PATTERNS)

def _caption_is_generic(text):
    low=clean_text(text).lower()
    if any(re.search(p,low,re.I) for p in _CAPTION_GENERIC_PATTERNS): return True
    meaningful=[w for w in _normalized_words(text) if w not in _CAPTION_STOP and len(w)>=3]
    return len(set(meaningful))<3

def _caption_grounding_ratio(caption, transcript):
    cap=[w for w in _normalized_words(caption) if w not in _CAPTION_STOP and len(w)>=3]
    if not cap: return 0.0
    tr=set(_normalized_words(transcript))
    return sum(1 for w in cap if w in tr)/max(1,len(cap))

def _caption_is_safe(text, transcript, other=""):
    t=trim_words(text,18)
    if not t or len(t.split())<4: return False
    if _caption_has_meta(t) or _caption_is_generic(t): return False
    if _caption_bad_start(t) or _caption_bad_end(t): return False
    if transcript and _caption_grounding_ratio(t,transcript)<0.72: return False
    if other and _jaccard(t,other)>0.55: return False
    return True

def _pick_safe_caption(candidates, transcript, exclude="", max_words=17):
    for c in candidates or []:
        raw=c.get("text","") if isinstance(c,dict) else str(c or "")
        t=trim_words(raw,max_words)
        if _caption_is_safe(t,transcript,exclude):
            return t, (c.get("pos",0.5) if isinstance(c,dict) else 0.5)
    return "",0.5


def _normalized_words(text):
    return re.findall(r"[0-9A-Za-zÀ-ÖØ-öø-ÿ]+", clean_text(text).lower())

def _token_set(text):
    return set(_normalized_words(text))

def _jaccard(a,b):
    sa,sb=_token_set(a),_token_set(b)
    if not sa or not sb: return 0.0
    return len(sa & sb)/max(1,len(sa | sb))

def _looks_incomplete(text):
    low=" "+clean_text(text).lower()+" "
    bad_starts=(" e "," mas "," porque "," que "," então "," aí "," daí "," só que "," porém "," sendo que ")
    bad_ends=(" de "," da "," do "," dos "," das "," que "," e "," mas "," porque "," para "," por "," com "," em ")
    return any(low.startswith(x) for x in bad_starts) or any(low.endswith(x) for x in bad_ends)

def _caption_score(text, position=0.5):
    t=clean_text(text); w=t.split()
    if not w: return -999.0
    n=len(w)
    score=0.0
    if 6<=n<=14: score+=7.0
    elif 4<=n<=18: score+=4.5
    elif 3<=n<=22: score+=2.0
    else: score-=3.0
    low=" "+t.lower()+" "
    for filler in (" né "," tipo "," assim "," então "," bom "," olha "," gente "," sabe "," tá "," viu "):
        if filler in low: score-=0.8
    if _looks_incomplete(t): score-=3.5
    if any(ch.isdigit() for ch in t): score+=1.0
    action_hits=0
    for action in ("afirma","anuncia","confirma","decide","prende","morre","morreu","demite","aprova","nega",
                   "revela","investiga","investigando","acontece","viraliza","vence","perde","cai","sobe","fecha","abre",
                   "disse","informou","mostra","deixa","entra","sai","chega","recebe","sofre","ganha","procura",
                   "encontra","encontrada","encontrado","apreende","apreendeu","descobre","tenta","vai"):
        if action in low:
            score+=0.62
            action_hits+=1
    for nounish in ("polícia","governo","justiça","presidente","prefeito","governador","cantor","atriz",
                    "médico","hospital","empresa","família","mulher","homem","criança","cidade","estado","estudante"):
        if nounish in low: score+=0.38
    for lead in (" a polícia "," a justiça "," segundo a polícia "," a família "," uma estudante "," um homem ",
                 " uma mulher "," o governo "," a vítima "," o namorado "," a jovem "):
        if low.startswith(lead): score+=1.6
    for newsword in (" morte "," morreu "," encontrada "," encontrado "," investigação "," investigando ",
                     " preso "," presa "," desaparecido "," desaparecida "," acidente "," hospital "):
        if newsword in low: score+=0.65
    # Long noun fragments without a clear action are poor headlines.
    if n>=6 and action_hits==0: score-=2.8
    # Top captions benefit substantially from earlier context.
    score += (1.0-position)*1.8
    return score

def _best_caption(items, begin, end, exclude="", prefer_late=False):
    if not items: return ""
    n=len(items)
    lo=max(0,min(n-1,int(n*begin)))
    hi=max(lo+1,min(n,int(n*end+0.999)))
    candidates=items[lo:hi] or items
    ex=clean_text(exclude)
    ranked=[]
    for idx,item in enumerate(candidates):
        t=clean_text(item.get("text",""))
        if not t: continue
        global_pos=(lo+idx)/max(1,n-1)
        score=_caption_score(t,global_pos)
        try:
            lp=float(item.get("avg_logprob",-0.5) or -0.5)
            nsp=float(item.get("no_speech_prob",0) or 0)
            score+=max(-2.0,min(1.5,(lp+0.8)*1.8))
            score-=nsp*2.2
        except Exception:
            pass
        if ex:
            sim=_jaccard(t,ex)
            if sim>0.72: score-=8.0
            elif sim>0.45: score-=3.0
        if prefer_late: score+=global_pos*1.6
        else: score+=(1.0-global_pos)*0.8
        ranked.append((score,t))
    ranked.sort(reverse=True,key=lambda x:x[0])
    return ranked[0][1] if ranked else ""

def _merge_neighbor_phrase(items, index, max_words=18):
    if index<0 or index>=len(items): return ""
    base=clean_text(items[index].get("text",""))
    if not base: return ""
    best=base; bestscore=_caption_score(base)
    for a,b in ((index-1,index),(index,index+1)):
        if a<0 or b>=len(items): continue
        merged=clean_text(items[a].get("text","")+" "+items[b].get("text",""))
        if len(merged.split())>max_words: continue
        sc=_caption_score(merged)+0.5
        if sc>bestscore:
            best,bestscore=merged,sc
    return best

def _caption_bad_start(text):
    words=_normalized_words(text)
    if not words: return True
    bad={"e","mas","porque","que","então","aí","daí","tipo","assim","bom","olha","gente","né","ele","ela","isso"}
    return words[0] in bad

def _caption_bad_end(text):
    words=_normalized_words(text)
    if not words: return True
    dangling={"de","da","do","das","dos","no","na","nos","nas","em","para","por","com","que","e","mas","ou","a","o"}
    return words[-1] in dangling

def _caption_candidate_score(text,item,position,prefer_late=False):
    score=_caption_score(text,position)
    try:
        lp=float(item.get("avg_logprob",-0.5) or -0.5)
        nsp=float(item.get("no_speech_prob",0) or 0)
        score+=max(-2.0,min(1.8,(lp+0.85)*2.0))
        score-=nsp*2.5
    except Exception:
        pass
    if _caption_bad_start(text): score-=2.0
    if _caption_bad_end(text): score-=2.8
    words=_normalized_words(text)
    if len(words)<5: score-=1.6
    if len(words)>19: score-=1.8
    if prefer_late: score+=position*0.75
    else: score+=(1.0-position)*1.35
    return score

def _caption_candidates(items,begin,end,prefer_late=False):
    if not items:return []
    n=len(items)
    lo=max(0,min(n-1,int(n*begin)))
    hi=max(lo+1,min(n,int(math.ceil(n*end))))
    out=[]; seen=set()
    for i in range(lo,hi):
        variants=[clean_text(items[i].get("text",""))]
        if i+1<hi:
            variants.append(clean_text(items[i].get("text","")+" "+items[i+1].get("text","")))
        if i+2<hi:
            variants.append(clean_text(items[i].get("text","")+" "+items[i+1].get("text","")+" "+items[i+2].get("text","")))
        if i>lo:
            variants.append(clean_text(items[i-1].get("text","")+" "+items[i].get("text","")))
        for t in variants:
            t=_strip_caption_fillers(t)
            if not t:continue
            words=t.split()
            # Não corta uma combinação longa no meio: isso criava manchetes truncadas.
            if len(words)>21: continue
            key=t.lower()
            if key in seen:continue
            seen.add(key)
            pos=i/max(1,n-1)
            score=_caption_candidate_score(t,items[i],pos,prefer_late)+_caption_specificity_score(t)
            out.append({"text":t,"score":score,"pos":pos,"idx":i,"source":"segment"})
    out.sort(key=lambda x:x["score"],reverse=True)
    return out[:18]

def automatic_captions(items, transcript):
    items=[x for x in items if clean_text(x.get("text",""))]
    if not items:
        return "","",{"quality":0.0,"overlap":0.0,"top_pos":0.0,"bottom_pos":0.0}

    top_candidates=_caption_candidates(items,0.0,0.62,False)+_transcript_caption_candidates(transcript,0.0,0.62,False)
    bottom_candidates=_caption_candidates(items,0.24,1.0,True)+_transcript_caption_candidates(transcript,0.24,1.0,True)
    # Deduplica e reordena depois de juntar evidência segmentada + frases completas.
    def _merge_ranked(rows):
        seen=set(); out=[]
        for row in sorted(rows,key=lambda x:x.get("score",-999),reverse=True):
            key=clean_text(row.get("text","")).lower()
            if not key or key in seen: continue
            seen.add(key); out.append(row)
        return out[:28]
    top_candidates=_merge_ranked(top_candidates)
    bottom_candidates=_merge_ranked(bottom_candidates)

    best=None
    for t in top_candidates or [{"text":clean_text(transcript),"score":0.0,"pos":0.0,"idx":0}]:
        for b in bottom_candidates or [{"text":clean_text(transcript),"score":0.0,"pos":1.0,"idx":len(items)-1}]:
            overlap=_jaccard(t["text"],b["text"])
            pair=t["score"]+b["score"]-(overlap*13.0)
            pair+=(1.0-float(t.get("pos",0.5)))*2.6
            if b["pos"]>t["pos"]: pair+=min(2.5,(b["pos"]-t["pos"])*3.0)
            else: pair-=2.0
            # Reward a useful setup -> consequence relationship without inventing text.
            if any(k in ("morreu","preso","presa","apreendeu","confirmou","negou","investiga","investigando",
                         "hospital","polícia","justiça","perícia","resultado","decisão")
                   for k in _normalized_words(b["text"])):
                pair+=0.7
            if best is None or pair>best[0]:
                best=(pair,t,b,overlap)

    if best:
        _,tc,bc,overlap=best
        top_raw=tc["text"]; bottom_raw=bc["text"]
        top_pos=tc["pos"]; bottom_pos=bc["pos"]; pair_quality=best[0]
    else:
        top_raw=clean_text(transcript); bottom_raw=clean_text(transcript)
        top_pos=0.0; bottom_pos=1.0; overlap=1.0; pair_quality=0.0

    top=trim_words(top_raw,16)
    bottom=trim_words(bottom_raw,17)

    # Final anti-duplication fallback.
    if _jaccard(top,bottom)>0.58:
        for alt in bottom_candidates[1:]:
            candidate=trim_words(alt["text"],17)
            if _jaccard(top,candidate)<0.48:
                bottom=candidate; bottom_pos=alt["pos"]; break

    # Remove dangling endings after trimming and avoid captions that are too tiny.
    top=trim_words(top,16)
    bottom=trim_words(bottom,17)
    if len(top.split())<4:
        top=trim_words(clean_text(transcript),12)
    if len(bottom.split())<4:
        words=clean_text(transcript).split()
        bottom=trim_words(" ".join(words[-min(14,len(words)):]),14)

    # V7.13 caption guard: qualquer texto meta/diagnóstico ou chamada vaga é
    # descartado e substituído por evidência extraída da própria fala.
    evidence=clean_text(transcript)
    if not _caption_is_safe(top,evidence):
        top,top_pos=_pick_safe_caption(top_candidates,evidence,"",16)
    if not _caption_is_safe(bottom,evidence,top):
        bottom,bottom_pos=_pick_safe_caption(bottom_candidates,evidence,top,17)

    # Último fallback estritamente extrativo: usa segmentos reais, nunca uma
    # mensagem explicando que a IA falhou. Se ainda não houver material seguro,
    # deixa o campo vazio e sinaliza revisão fora do vídeo.
    if not top:
        top,top_pos=_pick_safe_caption(_caption_candidates(items,0.0,1.0,False),evidence,"",16)
    if not bottom:
        bottom,bottom_pos=_pick_safe_caption(_caption_candidates(items,0.0,1.0,True),evidence,top,17)

    blocked=not (_caption_is_safe(top,evidence) and _caption_is_safe(bottom,evidence,top))
    if blocked:
        if not _caption_is_safe(top,evidence): top=""
        if not _caption_is_safe(bottom,evidence,top): bottom=""

    final_overlap=_jaccard(top,bottom) if top and bottom else 0.0
    meta={
        "quality":round(float(pair_quality),3),
        "overlap":round(final_overlap,3),
        "top_pos":round(float(top_pos),3),
        "bottom_pos":round(float(bottom_pos),3),
        "top_words":len(top.split()),
        "bottom_words":len(bottom.split()),
        "blocked":bool(blocked),
        "reason":"a IA ainda não obteve uma frase específica e segura da fala; o texto genérico foi bloqueado" if blocked else "",
        "grounding_top":round(_caption_grounding_ratio(top,evidence),3) if top else 0.0,
        "grounding_bottom":round(_caption_grounding_ratio(bottom,evidence),3) if bottom else 0.0
    }
    return top.upper(),bottom.upper(),meta

def _content_tokens(items):
    stop={"a","o","e","de","da","do","das","dos","em","no","na","nos","nas","um","uma","que","para","por",
          "com","se","é","foi","tem","mais","como","ele","ela","eles","elas","isso","esse","essa","meu","minha"}
    freq={}
    for item in items:
        for w in _normalized_words(item.get("text","")):
            if len(w)<3 or w in stop: continue
            freq[w]=freq.get(w,0)+1
    return freq

def _informativeness(text,freq):
    toks=[w for w in _normalized_words(text) if w in freq]
    if not toks: return 0.0
    # Reward meaningful tokens, especially those not repeated everywhere.
    vals=[1.0/math.sqrt(max(1,freq[w])) for w in toks]
    return sum(vals)/max(1,len(vals))

def _clip_items(items,start,end):
    return [x for x in items if float(x.get("end",0) or 0)>=start and float(x.get("start",0) or 0)<=end]

def _high_confidence_items(items):
    if len(items)<3:return items
    vals=sorted(float(x.get("avg_logprob",-1) or -1) for x in items)
    threshold=vals[max(0,int(len(vals)*0.25)-1)]
    chosen=[x for x in items if float(x.get("avg_logprob",-1) or -1)>=threshold and float(x.get("no_speech_prob",0) or 0)<0.7]
    return chosen if len(chosen)>=2 else items

def _segment_quality(item):
    text=clean_text(item.get("text",""))
    if not text: return -9.0
    q=_caption_score(text)
    if float(item.get("no_speech_prob",0) or 0)>0.6: q-=4.0
    lp=item.get("avg_logprob")
    if lp is not None:
        try:
            q+=max(-2.0,min(1.5,(float(lp)+1.0)*1.5))
        except Exception: pass
    return q

def _hook_score(item,freq):
    text=clean_text(item.get("text",""))
    if not text:return -6.0
    score=_segment_quality(item)+_informativeness(text,freq)*2.0
    low=" "+text.lower()+" "
    for word in ("polícia","justiça","morreu","preso","presa","encontrado","encontrada","revela","mostra",
                 "aconteceu","flagra","denuncia","confirma","nega","agora","hoje","vídeo","imagens"):
        if word in low: score+=0.45
    if any(ch.isdigit() for ch in text): score+=0.5
    if _looks_incomplete(text): score-=1.8
    if _caption_bad_start(text): score-=1.2
    return score

def _closure_score(item):
    text=clean_text(item.get("text",""))
    if not text:return -5.0
    score=_segment_quality(item)*0.7
    if _looks_incomplete(text) or _caption_bad_end(text): score-=2.5
    low=" "+text.lower()+" "
    for word in ("confirmou","negou","perícia","investigação","resultado","hospital","justiça","polícia",
                 "terminou","acabou","final","concluiu","informou","afirmou"):
        if word in low: score+=0.35
    return score

def suggest_clip(items,total,mode="smart"):
    if total<=0:
        return 0.0,0.0,{"score":0.0,"reason":"sem duração"}
    good=[x for x in items if clean_text(x.get("text",""))]
    if not good:
        end=min(total,45.0)
        return 0.0,end,{"score":0.0,"reason":"sem fala detectada"}

    first=max(0.0,float(good[0].get("start",0) or 0)-0.25)
    last=min(total,float(good[-1].get("end",total) or total)+0.35)
    spoken=max(0.0,last-first)
    freq=_content_tokens(good)

    if mode=="fast":
        ideal_lo,ideal_hi,max_clip=16.0,36.0,50.0
    elif mode=="quality":
        ideal_lo,ideal_hi,max_clip=22.0,75.0,120.0
    else:
        ideal_lo,ideal_hi,max_clip=18.0,60.0,90.0

    if total<=18 or spoken<=16:
        return round(first,2),round(last,2),{
            "score":round(sum(_segment_quality(x) for x in good),2),
            "reason":"vídeo curto preservado","hook":round(_hook_score(good[0],freq),2),
            "closure":round(_closure_score(good[-1]),2),"speech_density":1.0
        }

    best=None
    n=len(good)
    for i in range(n):
        start=max(first,float(good[i].get("start",0) or 0)-0.25)
        seen=[]; cumulative=0.0; gap_total=0.0; repeated=0.0; previous_end=None; spoken_inside=0.0
        for j in range(i,n):
            seg_start=float(good[j].get("start",0) or 0)
            seg_end=float(good[j].get("end",0) or 0)
            if previous_end is not None:
                gap=max(0.0,seg_start-previous_end);gap_total+=gap
            previous_end=seg_end
            end=min(last,seg_end+0.35)
            dur=end-start
            if dur>max_clip: break
            text=clean_text(good[j].get("text",""))
            segq=_segment_quality(good[j])
            info=_informativeness(text,freq)
            rep=max([_jaccard(text,x) for x in seen],default=0.0)
            repeated+=rep
            spoken_inside+=max(0.0,seg_end-seg_start)
            cumulative+=segq+info*1.7-rep*2.2
            seen.append(text)
            if dur<min(14.0,ideal_lo): continue

            density=min(1.0,spoken_inside/max(0.1,dur))
            hook=_hook_score(good[i],freq)
            closure=_closure_score(good[j])
            score=cumulative+hook*0.75+closure*0.55+density*3.0
            if ideal_lo<=dur<=ideal_hi: score+=4.5
            elif dur<ideal_lo: score-=max(0.0,(ideal_lo-dur)*0.18)
            else: score-=max(0.0,(dur-ideal_hi)*0.055)
            score-=gap_total*0.9
            if gap_total>dur*0.22: score-=2.0
            score+=(1.0-(start/max(total,1.0)))*0.6

            meta={
                "score":round(score,3),"hook":round(hook,3),"closure":round(closure,3),
                "speech_density":round(density,3),"gap_seconds":round(gap_total,3),
                "repetition_penalty":round(repeated,3),"segments":j-i+1,
                "reason":"melhor combinação de gancho, informação e fechamento"
            }
            if best is None or score>best[0]:
                best=(score,start,end,meta)

    if best is None:
        end=min(last,first+min(max_clip,max(ideal_lo,30.0)))
        return round(first,2),round(end,2),{"score":0.0,"reason":"fallback de duração"}

    _,start,end,meta=best

    if total<=60 and spoken<=60:
        spoken_sum=sum(max(0.0,float(x.get("end",0))-float(x.get("start",0))) for x in good)
        full_density=spoken_sum/max(0.1,last-first)
        full_score=sum(_segment_quality(x) for x in good)+_hook_score(good[0],freq)*0.6+_closure_score(good[-1])*0.5+full_density*2.0
        if full_score>=best[0]*0.92 and full_density>=0.62 and (last-first)<=60:
            start,end=first,last
            meta={"score":round(full_score,3),"hook":round(_hook_score(good[0],freq),3),
                  "closure":round(_closure_score(good[-1]),3),"speech_density":round(full_density,3),
                  "gap_seconds":round(max(0.0,(last-first)-spoken_sum),3),
                  "segments":len(good),"reason":"vídeo curto coerente preservado"}

    return round(start,2),round(end,2),meta
def _dedupe_segments(items):
    out=[]
    for item in items:
        t=clean_text(item.get("text",""))
        if not t: continue
        if float(item.get("no_speech_prob",0) or 0) >= 0.82:
            continue
        if out:
            prev=clean_text(out[-1].get("text",""))
            sim=_jaccard(prev,t)
            if sim>=0.88:
                # Keep the more confident duplicate.
                a=float(out[-1].get("avg_logprob",-9) or -9)
                b=float(item.get("avg_logprob",-9) or -9)
                if b>a: out[-1]=item
                continue
        out.append(item)
    return out

def _repetition_ratio(text):
    words=_normalized_words(text)
    if len(words)<6: return 0.0
    return 1.0-(len(set(words))/max(1,len(words)))

def _ngram_repeat_ratio(text,n=3):
    words=_normalized_words(text)
    if len(words)<n*2: return 0.0
    grams=[tuple(words[i:i+n]) for i in range(len(words)-n+1)]
    return 1.0-(len(set(grams))/max(1,len(grams)))

def _speech_coverage(items):
    if not items: return 0.0
    start=min(float(x.get("start",0) or 0) for x in items)
    end=max(float(x.get("end",0) or 0) for x in items)
    span=max(0.001,end-start)
    spoken=sum(max(0.0,float(x.get("end",0) or 0)-float(x.get("start",0) or 0)) for x in items)
    return min(1.0,spoken/span)

def _transcript_quality(items):
    if not items: return -9.0
    conf=avg_confidence(items)
    texts=[clean_text(x.get("text","")) for x in items if clean_text(x.get("text",""))]
    if not texts: return -9.0
    joined=" ".join(texts)
    rep=_repetition_ratio(joined)
    ngram_rep=_ngram_repeat_ratio(joined,3)
    speech=[1.0-float(x.get("no_speech_prob",0) or 0) for x in items]
    speech_score=sum(speech)/max(1,len(speech))
    coverage=_speech_coverage(items)
    avg_words=sum(len(t.split()) for t in texts)/max(1,len(texts))
    score=(conf+1.1)*2.1 + speech_score*1.6 + coverage*0.65 - rep*1.6 - ngram_rep*2.4
    if avg_words<2.2: score-=0.8
    if len(joined.split())<8: score-=1.2
    if len(texts)>=4 and len(set(t.lower() for t in texts))/len(texts)<0.55: score-=1.0
    return round(score,3)

def _needs_refine(items,mode):
    if mode!="smart" or not items: return False
    conf=avg_confidence(items)
    quality=_transcript_quality(items)
    joined=" ".join(clean_text(x.get("text","")) for x in items)
    rep=_repetition_ratio(joined); nrep=_ngram_repeat_ratio(joined,3)
    return conf < -0.50 or quality < 1.45 or rep > 0.46 or nrep > 0.30

def _merge_best_transcript(base_items,small_items):
    if not base_items: return small_items
    if not small_items: return base_items
    bq=_transcript_quality(base_items)
    sq=_transcript_quality(small_items)
    return small_items if sq >= bq+0.05 else base_items

def _choose_best_transcript(candidates):
    scored=[]
    for name,items,total in candidates:
        if not items: continue
        scored.append((_transcript_quality(items),avg_confidence(items),name,items,total))
    if not scored: return "none",[],0.0
    scored.sort(key=lambda x:(x[0],x[1]),reverse=True)
    best=scored[0]
    return best[2],best[3],best[4]

def _needs_rescue(items):
    if not items: return True
    text=" ".join(clean_text(x.get("text","")) for x in items)
    return _transcript_quality(items)<0.95 or _ngram_repeat_ratio(text,3)>0.38 or _repetition_ratio(text)>0.55

def _parse_intervals(text,prefix):
    starts=[float(x) for x in re.findall(rf"{prefix}_start:([0-9.]+)",text)]
    ends=[float(x) for x in re.findall(rf"{prefix}_end:([0-9.]+)",text)]
    out=[]
    for i,st in enumerate(starts):
        en=ends[i] if i<len(ends) else st
        if en>=st: out.append((st,en))
    return out

def analyze_visual_safety(path,start,end,mode="smart"):
    meta={"checked":False,"black_intervals":[],"freeze_intervals":[],"adjusted":False}
    if mode=="fast" or end<=start:
        return start,end,meta
    dur=end-start
    scan_dur=min(120.0,dur)
    t0=time.perf_counter()
    cmd=[FFMPEG,"-hide_banner","-loglevel","info","-ss",f"{start:.3f}","-t",f"{scan_dur:.3f}",
         "-i",str(path),"-an","-threads","2",
         "-vf","fps=5,scale=320:-2,blackdetect=d=0.12:pix_th=0.10,freezedetect=n=-50dB:d=1.5",
         "-f","null","-"]
    try:
        r=subprocess.run(cmd,capture_output=True,text=True,timeout=max(25,int(scan_dur*0.8)+12))
        logs=(r.stderr or "")+(r.stdout or "")
        blacks=_parse_intervals(logs,"black")
        freezes=_parse_intervals(logs,"freeze")
        meta.update({"checked":True,"black_intervals":blacks[:12],"freeze_intervals":freezes[:12],
                     "scan_seconds":round(time.perf_counter()-t0,3)})
        new_start,new_end=start,end

        # Only adjust boundaries. Internal black/freeze moments are reported but left intact.
        for st,en in blacks:
            if st<=0.45 and en<=min(scan_dur-1.0,4.0):
                new_start=max(new_start,start+en+0.08)
            if en>=scan_dur-0.35 and st>=max(0.0,scan_dur-4.0):
                new_end=min(new_end,start+max(0.0,st-0.08))
        for st,en in freezes:
            freeze_dur=en-st
            if freeze_dur>=1.5 and st<=0.35 and en<=min(scan_dur-1.0,4.0):
                new_start=max(new_start,start+en+0.05)
            if freeze_dur>=1.5 and en>=scan_dur-0.25 and st>=max(0.0,scan_dur-4.0):
                new_end=min(new_end,start+max(0.0,st-0.05))

        if new_end-new_start>=14.0 and (abs(new_start-start)>0.05 or abs(new_end-end)>0.05):
            meta["adjusted"]=True
            meta["start_shift"]=round(new_start-start,3)
            meta["end_shift"]=round(new_end-end,3)
            return round(new_start,2),round(new_end,2),meta
    except Exception as e:
        meta["error"]=str(e)[:160]
    return start,end,meta

def _safe_clip_bounds(start,end,total):
    start=max(0.0,float(start or 0))
    end=max(start,float(end or 0))
    if total>0: end=min(float(total),end)
    if end-start<1.0 and total>0:
        end=min(float(total),start+min(15.0,float(total)-start))
    return round(start,2),round(end,2)

def avg_confidence(items):
    vals=[x.get("avg_logprob") for x in items if x.get("avg_logprob") is not None]
    return sum(vals)/len(vals) if vals else -0.5


def _gemini_response_text(payload):
    texts=[]
    for cand in (payload or {}).get("candidates") or []:
        content=cand.get("content") or {}
        for part in content.get("parts") or []:
            t=part.get("text")
            if isinstance(t,str) and t.strip(): texts.append(t.strip())
    return clean_text(" ".join(texts))

def _gemini_http_error_message(exc):
    try:
        raw=exc.read().decode("utf-8","replace")[:4000]
        data=json.loads(raw)
        msg=((data.get("error") or {}).get("message") or raw)
    except Exception:
        msg=str(exc)
    # Never expose tokens/credentials in logs or API responses.
    msg=re.sub(r"AIza[0-9A-Za-z_-]{20,}","[API_KEY_OCULTA]",str(msg))
    return clean_text(msg)[:500]

def _gemini_generate(model, body, timeout=None):
    if not GEMINI_API_KEY:
        raise RuntimeError("Gemini não configurado no servidor")
    url="https://generativelanguage.googleapis.com/v1beta/models/"+quote(model,safe="")+":generateContent"
    data=json.dumps(body,ensure_ascii=False,separators=(",",":")).encode("utf-8")
    req=urllib.request.Request(url,data=data,method="POST",headers={
        "Content-Type":"application/json",
        "x-goog-api-key":GEMINI_API_KEY,
        "User-Agent":"CortesAutomatico/7.18"
    })
    try:
        with urllib.request.urlopen(req,timeout=timeout or GEMINI_TIMEOUT) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        raise RuntimeError("Gemini HTTP %s: %s"%(e.code,_gemini_http_error_message(e)))
    except urllib.error.URLError as e:
        raise RuntimeError("Gemini indisponível: "+clean_text(str(getattr(e,"reason",e))))

def _groq_http_error_message(exc):
    try:
        raw=exc.read().decode("utf-8","replace")[:4000]
        data=json.loads(raw)
        err=data.get("error") or {}
        msg=err.get("message") if isinstance(err,dict) else raw
        msg=msg or raw
    except Exception:
        msg=str(exc)
    # Nunca exponha credenciais em respostas/logs.
    msg=re.sub(r"gsk_[0-9A-Za-z_-]{16,}","[API_KEY_OCULTA]",str(msg))
    return clean_text(msg)[:500]

def _groq_json_post(path, body, timeout=None):
    if not GROQ_API_KEY:
        raise RuntimeError("Groq não configurado no servidor")
    url="https://api.groq.com/openai/v1/"+path.lstrip("/")
    data=json.dumps(body,ensure_ascii=False,separators=(",",":")).encode("utf-8")
    req=urllib.request.Request(url,data=data,method="POST",headers={
        "Content-Type":"application/json",
        "Authorization":"Bearer "+GROQ_API_KEY,
        "User-Agent":"CortesAutomatico/7.23"
    })
    try:
        with urllib.request.urlopen(req,timeout=timeout or GROQ_TIMEOUT) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        raise RuntimeError("Groq HTTP %s: %s"%(e.code,_groq_http_error_message(e)))
    except urllib.error.URLError as e:
        raise RuntimeError("Groq indisponível: "+clean_text(str(getattr(e,"reason",e))))

def _groq_multipart_transcribe(path):
    if not GROQ_API_KEY:
        raise RuntimeError("Groq não configurado no servidor")
    p=Path(path)
    boundary="----CortesAutomatico"+uuid.uuid4().hex
    crlf=b"\r\n"
    chunks=[]
    def field(name,value):
        chunks.extend([
            ("--"+boundary).encode()+crlf,
            ('Content-Disposition: form-data; name="%s"'%name).encode()+crlf+crlf,
            str(value).encode("utf-8")+crlf
        ])
    field("model",GROQ_STT_MODEL)
    field("language","pt")
    field("response_format","verbose_json")
    field("temperature","0")
    field("timestamp_granularities[]","segment")
    mime="audio/wav" if p.suffix.lower()==".wav" else "application/octet-stream"
    chunks.extend([
        ("--"+boundary).encode()+crlf,
        ('Content-Disposition: form-data; name="file"; filename="%s"'%safe_name(p.name)).encode()+crlf,
        ("Content-Type: "+mime).encode()+crlf+crlf,
        p.read_bytes(),crlf,
        ("--"+boundary+"--").encode()+crlf
    ])
    data=b"".join(chunks)
    req=urllib.request.Request("https://api.groq.com/openai/v1/audio/transcriptions",data=data,method="POST",headers={
        "Content-Type":"multipart/form-data; boundary="+boundary,
        "Content-Length":str(len(data)),
        "Authorization":"Bearer "+GROQ_API_KEY,
        "User-Agent":"CortesAutomatico/7.23"
    })
    try:
        with urllib.request.urlopen(req,timeout=max(GROQ_TIMEOUT,120)) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        raise RuntimeError("Groq STT HTTP %s: %s"%(e.code,_groq_http_error_message(e)))
    except urllib.error.URLError as e:
        raise RuntimeError("Groq STT indisponível: "+clean_text(str(getattr(e,"reason",e))))

def groq_transcribe_once(path,total_hint=0.0):
    payload=_groq_multipart_transcribe(path)
    transcript=clean_text(str((payload or {}).get("text") or ""))
    items=[]
    for seg in (payload or {}).get("segments") or []:
        t=clean_text(str(seg.get("text") or ""))
        if not t: continue
        try: st=float(seg.get("start") or 0)
        except Exception: st=0.0
        try: en=float(seg.get("end") or st)
        except Exception: en=st
        try: alp=float(seg.get("avg_logprob") if seg.get("avg_logprob") is not None else -0.18)
        except Exception: alp=-0.18
        try: nsp=float(seg.get("no_speech_prob") if seg.get("no_speech_prob") is not None else 0.02)
        except Exception: nsp=0.02
        items.append({"text":t,"start":st,"end":max(st,en),"avg_logprob":alp,"no_speech_prob":nsp})
    items=_dedupe_segments(items)
    if not transcript and items:
        transcript=clean_text(" ".join(x["text"] for x in items))
    if not transcript:
        raise RuntimeError("Groq não retornou fala reconhecível")
    if not items:
        items=_synthetic_segments(transcript,total_hint)
    total=max([float(x.get("end",0) or 0) for x in items] or [float(total_hint or 0)])
    return items,total,transcript

def groq_caption_pair(transcript, fallback_top="", fallback_bottom=""):
    evidence=clean_text(transcript)
    if not GROQ_ENABLED or len(evidence.split())<6:
        return "","",{"used":False,"reason":"groq_unavailable_or_short"}
    prompt=(
        "Você edita vídeos curtos de notícias em português do Brasil. "
        "Crie duas chamadas para as caixas de legenda, usando SOMENTE fatos presentes na TRANSCRIÇÃO. "
        "A chamada TOP deve apresentar o acontecimento principal de forma forte e concreta. "
        "A chamada BOTTOM deve acrescentar consequência, detalhe, reação ou desfecho diferente. "
        "Se houver nomes, números, locais ou ações importantes, priorize-os. "
        "Seja chamativo pelo fato real, nunca por exagero inventado. "
        "PROIBIDO usar frases genéricas como 'vídeo mostra', 'vídeo traz', 'um relato', 'entenda o caso', "
        "'situação', 'mais detalhes', 'a IA', ou comentar falta de evidência. "
        "Não repita TOP no BOTTOM. Não acrescente informação externa. "
        "Cada texto deve ter entre 8 e 17 palavras e funcionar bem em exatamente 3 linhas visuais. "
        "Responda APENAS JSON no formato {\"top\":\"...\",\"bottom\":\"...\"}.\n\n"
        "TRANSCRIÇÃO:\n"+evidence[:12000]
    )
    body={
        "model":GROQ_TEXT_MODEL,
        "messages":[{"role":"user","content":prompt}],
        "temperature":0.25,
        "max_completion_tokens":220
    }
    payload=_groq_json_post("chat/completions",body,timeout=GROQ_TIMEOUT)
    raw=""
    try: raw=((payload.get("choices") or [])[0].get("message") or {}).get("content") or ""
    except Exception: raw=""
    obj=_json_object_from_text(raw)
    top=trim_words(clean_text(str(obj.get("top") or "")),17)
    bottom=trim_words(clean_text(str(obj.get("bottom") or "")),17)
    if _caption_has_meta(top) or _caption_is_generic(top) or _caption_bad_start(top) or _caption_bad_end(top): top=""
    if _caption_has_meta(bottom) or _caption_is_generic(bottom) or _caption_bad_start(bottom) or _caption_bad_end(bottom): bottom=""
    if top and _caption_grounding_ratio(top,evidence)<0.48: top=""
    if bottom and _caption_grounding_ratio(bottom,evidence)<0.45: bottom=""
    if top and bottom and _jaccard(top,bottom)>0.62: bottom=""
    if len(top.split())<6: top=""
    if len(bottom.split())<6: bottom=""
    pair=bool(top and bottom)
    if not top: top=clean_text(fallback_top)
    if not bottom: bottom=clean_text(fallback_bottom)
    safe=bool(top and bottom and not _caption_has_meta(top) and not _caption_has_meta(bottom) and not _caption_is_generic(top) and not _caption_is_generic(bottom))
    return top,bottom,{"used":True,"safe":safe,"source":"groq" if pair else "fallback","model":GROQ_TEXT_MODEL}

def _seconds_offset(v):
    if v is None: return 0.0
    if isinstance(v,(int,float)): return float(v)
    m=re.match(r"^\s*([0-9]+(?:\.[0-9]+)?)s?\s*$",str(v))
    return float(m.group(1)) if m else 0.0

def _gemini_word_rows(payload):
    rows=[]
    for cand in (payload or {}).get("candidates") or []:
        for part in ((cand.get("content") or {}).get("parts") or []):
            tr=part.get("audioTranscription") or part.get("audio_transcription") or {}
            speaker=tr.get("speakerLabel") or tr.get("speaker_label") or ""
            for w in tr.get("words") or []:
                word=re.sub(r"\s+"," ",str(w.get("word") or w.get("text") or "")).strip()
                if not word: continue
                st=_seconds_offset(w.get("startOffset",w.get("start_offset")))
                en=_seconds_offset(w.get("endOffset",w.get("end_offset")))
                if en<st: en=st
                rows.append({"word":word,"start":st,"end":en,"speaker":speaker})
    rows.sort(key=lambda x:(x["start"],x["end"]))
    return rows

def _word_rows_to_segments(rows):
    if not rows: return []
    out=[]; buf=[]; seg_start=None; seg_end=None; last_end=None; speaker=""
    def flush():
        nonlocal buf,seg_start,seg_end,speaker,last_end
        if not buf: return
        text=clean_text(" ".join(buf))
        if text:
            out.append({"text":text,"start":float(seg_start or 0),"end":float(seg_end or seg_start or 0),
                        "avg_logprob":-0.10,"no_speech_prob":0.01,"speaker":speaker})
        buf=[]; seg_start=seg_end=last_end=None; speaker=""
    for r in rows:
        gap=(r["start"]-(last_end if last_end is not None else r["start"]))
        new_speaker=bool(speaker and r.get("speaker") and r.get("speaker")!=speaker)
        if buf and (gap>0.85 or new_speaker or len(buf)>=12 or ((seg_end or 0)-(seg_start or 0)>=4.6)):
            flush()
        if not buf:
            seg_start=r["start"]; speaker=r.get("speaker") or ""
        buf.append(r["word"]); seg_end=r["end"]; last_end=r["end"]
        if re.search(r"[.!?]$",r["word"]) and len(buf)>=4: flush()
    flush()
    return _dedupe_segments(out)

def _synthetic_segments(text,total):
    words=clean_text(text).split()
    if not words: return []
    total=max(float(total or 0), max(1.0,len(words)/2.6))
    chunks=[]
    i=0
    while i<len(words):
        j=min(len(words),i+11)
        chunks.append(words[i:j]); i=j
    nwords=max(1,len(words)); cursor=0.0; used=0
    out=[]
    for chunk in chunks:
        frac=len(chunk)/nwords
        dur=max(0.45,total*frac)
        st=cursor; en=min(total,st+dur)
        out.append({"text":clean_text(" ".join(chunk)),"start":st,"end":en,"avg_logprob":-0.18,"no_speech_prob":0.02})
        cursor=en; used+=len(chunk)
    if out: out[-1]["end"]=total
    return out

def gemini_transcribe_once(path,total_hint=0.0):
    p=Path(path)
    if not GEMINI_ENABLED: raise RuntimeError("Gemini não configurado")
    size=p.stat().st_size
    if size>GEMINI_MAX_INLINE_AUDIO_BYTES:
        raise RuntimeError("áudio acima do limite inline configurado para Gemini")
    audio_b64=base64.b64encode(p.read_bytes()).decode("ascii")
    body={
        "contents":[{"role":"user","parts":[{"inlineData":{"mimeType":"audio/wav","data":audio_b64}}]}],
        "generationConfig":{"audioTranscriptionConfig":{"languageCodes":["pt-BR"],"wordTimestamp":True}}
    }
    payload=_gemini_generate(GEMINI_TRANSCRIBE_MODEL,body,timeout=max(GEMINI_TIMEOUT,120))
    transcript=_gemini_response_text(payload)
    rows=_gemini_word_rows(payload)
    items=_word_rows_to_segments(rows)
    if not transcript and items:
        transcript=clean_text(" ".join(x["text"] for x in items))
    if not transcript:
        raise RuntimeError("Gemini não retornou fala reconhecível")
    if not items:
        items=_synthetic_segments(transcript,total_hint)
    total=max([float(x.get("end",0) or 0) for x in items] or [float(total_hint or 0)])
    return items,total,transcript

def _json_object_from_text(text):
    raw=(text or "").strip()
    raw=re.sub(r"^```(?:json)?\s*|\s*```$","",raw,flags=re.I|re.S).strip()
    try:
        obj=json.loads(raw)
        return obj if isinstance(obj,dict) else {}
    except Exception:
        m=re.search(r"\{.*\}",raw,re.S)
        if not m: return {}
        try:
            obj=json.loads(m.group(0)); return obj if isinstance(obj,dict) else {}
        except Exception: return {}

def gemini_caption_pair(transcript, fallback_top="", fallback_bottom=""):
    evidence=clean_text(transcript)
    if not GEMINI_ENABLED or len(evidence.split())<6:
        return "","",{"used":False,"reason":"gemini_unavailable_or_short"}
    prompt=(
        "Você edita vídeos curtos de notícias em português do Brasil. "
        "Crie duas chamadas para as caixas de legenda, usando SOMENTE fatos presentes na TRANSCRIÇÃO. "
        "A chamada TOP deve apresentar o acontecimento principal de forma forte e concreta. "
        "A chamada BOTTOM deve acrescentar consequência, detalhe, reação ou desfecho diferente. "
        "Se houver nomes, números, locais ou ações importantes, priorize-os. "
        "Seja chamativo pelo fato real, nunca por exagero inventado. "
        "PROIBIDO usar frases genéricas como 'vídeo mostra', 'vídeo traz', 'um relato', 'entenda o caso', "
        "'situação', 'mais detalhes', 'a IA', ou comentar falta de evidência. "
        "Não repita TOP no BOTTOM. Não acrescente informação externa. "
        "Cada texto deve ter entre 8 e 17 palavras e funcionar bem em exatamente 3 linhas visuais. "
        "Responda APENAS JSON no formato {\"top\":\"...\",\"bottom\":\"...\"}.\n\n"
        "TRANSCRIÇÃO:\n"+evidence[:12000]
    )
    body={
        "contents":[{"role":"user","parts":[{"text":prompt}]}],
        "generationConfig":{"temperature":0.25,"maxOutputTokens":220,"responseMimeType":"application/json"}
    }
    payload=_gemini_generate(GEMINI_CAPTION_MODEL,body,timeout=GEMINI_TIMEOUT)
    obj=_json_object_from_text(_gemini_response_text(payload))
    top=trim_words(clean_text(str(obj.get("top") or "")),17)
    bottom=trim_words(clean_text(str(obj.get("bottom") or "")),17)
    # Keep a strict factual guard. Gemini may paraphrase, so allow slightly more
    # lexical flexibility than the extractive path, while still requiring overlap.
    if _caption_has_meta(top) or _caption_is_generic(top) or _caption_bad_start(top) or _caption_bad_end(top): top=""
    if _caption_has_meta(bottom) or _caption_is_generic(bottom) or _caption_bad_start(bottom) or _caption_bad_end(bottom): bottom=""
    if top and _caption_grounding_ratio(top,evidence)<0.48: top=""
    if bottom and _caption_grounding_ratio(bottom,evidence)<0.45: bottom=""
    if top and bottom and _jaccard(top,bottom)>0.62: bottom=""
    if len(top.split())<6: top=""
    if len(bottom.split())<6: bottom=""
    gemini_pair=bool(top and bottom)
    source="gemini" if gemini_pair else "fallback"
    if not top: top=clean_text(fallback_top)
    if not bottom: bottom=clean_text(fallback_bottom)
    safe=bool(top and bottom and not _caption_has_meta(top) and not _caption_has_meta(bottom) and not _caption_is_generic(top) and not _caption_is_generic(bottom))
    return top,bottom,{"used":True,"safe":safe,"source":source,"model":GEMINI_CAPTION_MODEL}

def transcribe_once(path, model_name, quality=False, condition_previous=True, vad_silence_ms=380):
    m=get_model(model_name)
    segs,info=m.transcribe(
        path, language="pt",
        beam_size=5 if quality else 3,
        best_of=5 if quality else 3,
        vad_filter=True,
        vad_parameters={"min_silence_duration_ms":int(vad_silence_ms),"speech_pad_ms":180},
        condition_on_previous_text=bool(condition_previous),
        word_timestamps=quality,
        no_speech_threshold=0.70 if quality else 0.74,
        log_prob_threshold=-0.95 if quality else -1.05,
        compression_ratio_threshold=2.25 if quality else 2.4
    )
    items=[]
    for seg in segs:
        t=clean_text(getattr(seg,"text",""))
        if t:
            items.append({"text":t,"start":float(getattr(seg,"start",0) or 0),
                          "end":float(getattr(seg,"end",0) or 0),
                          "avg_logprob":float(getattr(seg,"avg_logprob",-0.5) or -0.5),
                          "no_speech_prob":float(getattr(seg,"no_speech_prob",0) or 0)})
    items=_dedupe_segments(items)
    return items,float(getattr(info,"duration",0) or 0)

def cache_get(key):
    with db_conn() as c:
        r=c.execute("SELECT * FROM cache WHERE cache_key=?",(key,)).fetchone()
        if not r:
            with telemetry_lock: telemetry["cache_misses"]+=1
            return None
        with telemetry_lock: telemetry["cache_hits"]+=1
        c.execute("UPDATE cache SET last_used=? WHERE cache_key=?",(time.time(),key))
        try:
            value=json.loads(r["value_json"] or "null")
        except Exception:
            c.execute("DELETE FROM cache WHERE cache_key=?",(key,))
            return None
        fp=r["file_path"]
        if fp and not Path(fp).exists():
            c.execute("DELETE FROM cache WHERE cache_key=?",(key,))
            return None
        return {"value":value,"file_path":fp}

def cache_put(key,kind,value=None,file_path=None):
    now=time.time()
    with telemetry_lock: telemetry["cache_puts"]+=1
    with db_conn() as c:
        c.execute("""INSERT INTO cache(cache_key,kind,value_json,file_path,created_at,last_used)
                     VALUES(?,?,?,?,?,?)
                     ON CONFLICT(cache_key) DO UPDATE SET value_json=excluded.value_json,file_path=excluded.file_path,last_used=excluded.last_used""",
                  (key,kind,json.dumps(value,ensure_ascii=False),file_path,now,now))

def run_transcription(jid,fid,opts):
    if cancelled(jid):
        job_update(jid,status="cancelled",message="Cancelado antes de iniciar."); return
    meta=load_upload(fid)
    if not meta:
        job_update(jid,status="error",error="Vídeo não encontrado no servidor."); return
    if not meta.get("has_audio"):
        job_update(jid,status="error",error="Este vídeo não possui faixa de áudio para transcrição.",message="SEM ÁUDIO"); return
    mode=str((opts or {}).get("mode") or "smart")
    if mode not in VALID_MODES: mode="smart"
    sha=meta.get("sha256") or sha256_file(meta["path"]); meta["sha256"]=sha
    atomic_json_write(upload_meta_path(fid),meta)
    ckey=f"transcript:{PIPELINE_VERSION}:{sha}:{mode}:g{int(GEMINI_ENABLED)}q{int(GROQ_ENABLED)}w{int(WHISPER_AVAILABLE)}"
    cached=cache_get(ckey)
    if cached and cached["value"]:
        job_update(jid,status="done",progress=100,message="Transcrição recuperada do cache.",result=cached["value"]); return
    audio=TMP/(jid+"_16k.wav")
    try:
        stage_started=time.perf_counter()
        timing={}
        job_update(jid,status="running",progress=1,message="PREPARANDO ÁUDIO")
        if mode=="fast":
            af="highpass=f=80,lowpass=f=11000,dynaudnorm=f=180:g=7:p=0.9"
        elif mode=="quality":
            af="highpass=f=70,lowpass=f=12000,afftdn=nf=-28,dynaudnorm=f=100:g=10:p=0.8"
        else:
            af="highpass=f=75,lowpass=f=11500,afftdn=nf=-30,dynaudnorm=f=120:g=10:p=0.85"
        prep=subprocess.run([FFMPEG,"-y","-hide_banner","-loglevel","error","-i",meta["path"],"-vn","-ac","1","-ar","16000","-af",af,
                             "-c:a","pcm_s16le",str(audio)],capture_output=True,text=True,timeout=240)
        source=str(audio) if prep.returncode==0 and audio.exists() else meta["path"]
        timing["audio_prep_seconds"]=round(time.perf_counter()-stage_started,3)
        if cancelled(jid): job_update(jid,status="cancelled",message="Cancelado."); return
        model_name="small" if mode=="quality" else "base"
        initial_items=[]; total=0.0; cloud_transcript=""; cloud_errors=[]; provider=""
        if source==str(audio) and GEMINI_ENABLED:
            job_update(jid,progress=4,message="TRANSCREVENDO · GEMINI")
            model_started=time.perf_counter()
            try:
                initial_items,total,cloud_transcript=gemini_transcribe_once(source,float(meta.get("duration") or 0))
                provider="gemini"
            except Exception as ge:
                cloud_errors.append("Gemini: "+clean_text(str(ge))[:220])
            timing["gemini_transcribe_seconds"]=round(time.perf_counter()-model_started,3)

        # V7.23: no Render, Groq reaproveita a configuração cloud das versões online anteriores.
        # Ele entra apenas quando Gemini não está configurado ou falha.
        if not initial_items and source==str(audio) and GROQ_ENABLED:
            job_update(jid,progress=6,message="TRANSCREVENDO · IA ONLINE")
            model_started=time.perf_counter()
            try:
                initial_items,total,cloud_transcript=groq_transcribe_once(source,float(meta.get("duration") or 0))
                provider="groq"
            except Exception as qe:
                cloud_errors.append("Groq: "+clean_text(str(qe))[:220])
            timing["groq_transcribe_seconds"]=round(time.perf_counter()-model_started,3)

        if not initial_items:
            if not WHISPER_AVAILABLE:
                detail=(" | "+" | ".join(cloud_errors)) if cloud_errors else ""
                job_update(jid,status="error",message="TRANSCRIÇÃO INDISPONÍVEL",
                           error="Nenhum transcritor online conseguiu concluir e o Whisper local não está instalado."+detail)
                return
            prefix="IA ONLINE INDISPONÍVEL · " if (GEMINI_ENABLED or GROQ_ENABLED) else ""
            job_update(jid,progress=8,message=prefix+f"WHISPER {model_name.upper()}")
            model_started=time.perf_counter()
            initial_items,total=transcribe_once(source,model_name,quality=(mode=="quality"),condition_previous=True,
                                                vad_silence_ms=320 if float(meta.get("duration") or 0)<45 else 420)
            timing["whisper_initial_seconds"]=round(time.perf_counter()-model_started,3)
            provider="whisper_fallback" if (GEMINI_ENABLED or GROQ_ENABLED) else "whisper"
        candidates=[(provider if provider in ("gemini","groq") else ("small_quality" if mode=="quality" else "base"),initial_items,total)]
        refined=False; rescue_used=False

        # Gemini is the main transcriber. Whisper refinement is only used when
        # Gemini's timestamped result is too weak, or when Gemini itself failed.
        if WHISPER_AVAILABLE and _needs_refine(initial_items,mode):
            if cancelled(jid):
                job_update(jid,status="cancelled",message="Cancelado."); return
            job_update(jid,progress=50,message="REFINANDO ÁUDIO DIFÍCIL · SMALL")
            refine_started=time.perf_counter()
            small_items,total2=transcribe_once(source,"small",quality=True,condition_previous=True,vad_silence_ms=360)
            timing["small_refine_seconds"]=round(time.perf_counter()-refine_started,3)
            candidates.append(("small_refine",small_items,total2 or total))

            # A rescue pass is expensive, so only use it for genuinely poor/repetitive results.
            best_preview=_merge_best_transcript(initial_items,small_items)
            if mode=="smart" and _needs_rescue(best_preview) and float(meta.get("duration") or 0)<=240:
                if cancelled(jid):
                    job_update(jid,status="cancelled",message="Cancelado."); return
                job_update(jid,progress=76,message="CORRIGINDO REPETIÇÕES · SMALL LIMPO")
                rescue_started=time.perf_counter()
                rescue_items,total3=transcribe_once(source,"small",quality=True,condition_previous=False,vad_silence_ms=300)
                timing["rescue_transcribe_seconds"]=round(time.perf_counter()-rescue_started,3)
                candidates.append(("small_rescue",rescue_items,total3 or total2 or total))
                rescue_used=True

        strategy,items,total=_choose_best_transcript(candidates)
        refined=(strategy not in ("base","small_quality","gemini","groq"))
        if not items:
            raise RuntimeError("A IA não encontrou fala suficiente no vídeo.")
        transcript=clean_text(cloud_transcript if strategy in ("gemini","groq") and cloud_transcript else " ".join(x["text"] for x in items))
        duration=total or meta.get("duration",0)
        start,end,clip_meta=suggest_clip(items,duration,mode)
        start,end=_safe_clip_bounds(start,end,duration)
        if cancelled(jid):
            job_update(jid,status="cancelled",message="Cancelado."); return
        if mode!="fast":
            job_update(jid,progress=88,message="CONFERINDO INÍCIO E FIM DO CORTE")
        start,end,visual_meta=analyze_visual_safety(meta["path"],start,end,mode)
        start,end=_safe_clip_bounds(start,end,duration)
        clip_items=_clip_items(items,start,end) or items
        clip_transcript=clean_text(" ".join(x["text"] for x in clip_items))

        # V7.16: legenda independente da escolha global de transcrição. Testa todas
        # as passagens já disponíveis e usa a que explica melhor ESTE trecho.
        caption_trials=[]
        def _try_caption_pass(pass_name,pass_items):
            pclip=_clip_items(pass_items,start,end) or pass_items
            ptext=clean_text(" ".join(x.get("text","") for x in pclip))
            pconf=_high_confidence_items(pclip) or pclip
            pt,pb,pm=automatic_captions(pconf,ptext or transcript)
            safe=not bool(pm.get("blocked"))
            rank=(100.0 if safe else 0.0)+float(pm.get("quality") or 0.0)-float(pm.get("overlap") or 0.0)*8.0
            rank+=float(pm.get("grounding_top") or 0.0)*3.0+float(pm.get("grounding_bottom") or 0.0)*3.0
            caption_trials.append((rank,pass_name,pt,pb,pm,ptext,pclip))

        for pname,pitems,_ptotal in candidates:
            if pitems: _try_caption_pass(pname,pitems)
        caption_trials.sort(key=lambda x:x[0],reverse=True)
        best_caption=caption_trials[0] if caption_trials else None

        # Se todas as passagens ainda estiverem genéricas/incompletas, a IA escuta
        # novamente com SMALL focado em clareza. Isso só roda quando necessário.
        caption_rescue_used=False
        if (not best_caption or best_caption[4].get("blocked")) and mode!="fast" and float(duration or 0)<=300 and not any(n=="caption_rescue" for n,_,_ in candidates):
            if cancelled(jid):
                job_update(jid,status="cancelled",message="Cancelado."); return
            job_update(jid,progress=92,message="REOUVINDO O TRECHO · GERANDO LEGENDA ESPECÍFICA")
            cap_started=time.perf_counter()
            cap_items,cap_total=transcribe_once(source,"small",quality=True,condition_previous=False,vad_silence_ms=250)
            timing["caption_rescue_seconds"]=round(time.perf_counter()-cap_started,3)
            if cap_items:
                candidates.append(("caption_rescue",cap_items,cap_total or total))
                _try_caption_pass("caption_rescue",cap_items)
                caption_trials.sort(key=lambda x:x[0],reverse=True)
                best_caption=caption_trials[0]
                caption_rescue_used=True
                rescue_used=True

        if best_caption:
            _,caption_strategy,top,bottom,caption_meta,chosen_clip_transcript,chosen_clip_items=best_caption
            if chosen_clip_transcript: clip_transcript=chosen_clip_transcript
        else:
            caption_strategy="none"; top=bottom=""
            caption_meta={"quality":0.0,"overlap":0.0,"blocked":True,"reason":"não foi possível extrair legenda específica da fala"}

        # Cloud redactor: Gemini primeiro; Groq é reserva online. Ambos recebem apenas
        # a transcrição e passam pelas mesmas guardas factuais antes do render.
        gemini_caption_meta={"used":False}; groq_caption_meta={"used":False}
        cloud_pair_applied=False
        if clip_transcript and GEMINI_ENABLED:
            try:
                job_update(jid,progress=95,message="IA · CRIANDO LEGENDA CHAMATIVA")
                gtop,gbottom,gemini_caption_meta=gemini_caption_pair(clip_transcript,top,bottom)
                if gtop and gbottom and gemini_caption_meta.get("safe"):
                    top,bottom=gtop,gbottom; cloud_pair_applied=True
                    caption_strategy="gemini_contextual" if gemini_caption_meta.get("source")=="gemini" else caption_strategy
            except Exception as gce:
                gemini_caption_meta={"used":True,"safe":False,"error":clean_text(str(gce))[:300]}
        if clip_transcript and not cloud_pair_applied and GROQ_ENABLED:
            try:
                job_update(jid,progress=96,message="IA · FINALIZANDO LEGENDA")
                qtop,qbottom,groq_caption_meta=groq_caption_pair(clip_transcript,top,bottom)
                if qtop and qbottom and groq_caption_meta.get("safe"):
                    top,bottom=qtop,qbottom; cloud_pair_applied=True
                    caption_strategy="groq_contextual" if groq_caption_meta.get("source")=="groq" else caption_strategy
            except Exception as qce:
                groq_caption_meta={"used":True,"safe":False,"error":clean_text(str(qce))[:300]}
        if cloud_pair_applied:
            caption_meta=dict(caption_meta or {})
            caption_meta["blocked"]=False
            caption_meta["reason"]=""
            caption_meta["quality"]=max(float(caption_meta.get("quality") or 0.0),6.0)
            caption_meta["overlap"]=_jaccard(top,bottom)
            caption_meta["grounding_top"]=_caption_grounding_ratio(top,clip_transcript)
            caption_meta["grounding_bottom"]=_caption_grounding_ratio(bottom,clip_transcript)

        quality_score=_transcript_quality(items)
        clip_quality=_transcript_quality(clip_items)
        confidence=round(avg_confidence(items),3)
        warnings=[]
        rep_ratio=_repetition_ratio(transcript); ngram_ratio=_ngram_repeat_ratio(transcript,3)
        if confidence < -0.70: warnings.append("confiança baixa")
        if clip_quality < 1.0: warnings.append("fala difícil no trecho")
        if rep_ratio>0.50 or ngram_ratio>0.35: warnings.append("fala repetitiva")
        if _speech_coverage(items)<0.35: warnings.append("muitas pausas ou pouco diálogo")
        if caption_meta.get("overlap",0)>0.5: warnings.append("legendas com conteúdo parecido")
        if caption_meta.get("quality",0)<4.0: warnings.append("legenda extraída de fala pouco informativa")
        if caption_meta.get("blocked"): warnings.append("legenda automática bloqueada: faltou evidência factual segura")
        if visual_meta.get("black_intervals"): warnings.append("tela preta detectada no trecho")
        if visual_meta.get("freeze_intervals"): warnings.append("imagem congelada detectada no trecho")
        if visual_meta.get("adjusted"): warnings.append("bordas do corte ajustadas visualmente")
        result={"transcript":transcript,"clip_transcript":clip_transcript,
                "top":top,"bottom":bottom,"language":"pt",
                "duration":duration,"suggested_start":start,"suggested_end":end,
                "clip_score":clip_meta.get("score"),"clip_reason":clip_meta.get("reason"),
                "hook_score":clip_meta.get("hook"),"closure_score":clip_meta.get("closure"),
                "speech_density":clip_meta.get("speech_density"),"clip_gap_seconds":clip_meta.get("gap_seconds"),
                "confidence":confidence,"quality_score":quality_score,"clip_quality":clip_quality,
                "repetition_ratio":round(rep_ratio,3),"ngram_repeat_ratio":round(ngram_ratio,3),
                "speech_coverage":round(_speech_coverage(items),3),
                "caption_quality":caption_meta.get("quality"),"caption_overlap":caption_meta.get("overlap"),
                "caption_top_pos":caption_meta.get("top_pos"),"caption_bottom_pos":caption_meta.get("bottom_pos"),
                "caption_blocked":bool(caption_meta.get("blocked")),"caption_reason":caption_meta.get("reason") or "",
                "caption_strategy":caption_strategy,"caption_rescue_used":bool(caption_rescue_used),
                "caption_grounding_top":caption_meta.get("grounding_top"),"caption_grounding_bottom":caption_meta.get("grounding_bottom"),
                "visual_checked":visual_meta.get("checked"),"visual_adjusted":visual_meta.get("adjusted"),
                "black_intervals":len(visual_meta.get("black_intervals") or []),
                "freeze_intervals":len(visual_meta.get("freeze_intervals") or []),
                "visual_scan_seconds":visual_meta.get("scan_seconds"),
                "refined":refined,"rescue_used":rescue_used,"strategy":strategy,
                "transcription_provider":provider,"gemini_enabled":GEMINI_ENABLED,"groq_enabled":GROQ_ENABLED,
                "gemini_transcribe_model":GEMINI_TRANSCRIBE_MODEL if GEMINI_ENABLED else "",
                "gemini_caption_model":GEMINI_CAPTION_MODEL if GEMINI_ENABLED else "",
                "groq_transcribe_model":GROQ_STT_MODEL if GROQ_ENABLED else "",
                "groq_caption_model":GROQ_TEXT_MODEL if GROQ_ENABLED else "",
                "cloud_fallback_reason":" | ".join(cloud_errors),
                "gemini_caption_used":bool(gemini_caption_meta.get("used")),
                "gemini_caption_safe":bool(gemini_caption_meta.get("safe")),
                "groq_caption_used":bool(groq_caption_meta.get("used")),
                "groq_caption_safe":bool(groq_caption_meta.get("safe")),
                "passes":len(candidates),"segments":len(items),"clip_segments":len(clip_items),
                "warnings":warnings,"mode":mode,"timing":timing}
        cache_put(ckey,"transcript",result)
        final_msg="TRANSCRIÇÃO + LEGENDAS ESPECÍFICAS PRONTAS" if not caption_meta.get("blocked") else "TRANSCRIÇÃO PRONTA · LEGENDA ESPECÍFICA PRECISA DE REVISÃO"
        job_update(jid,status="done",progress=100,message=final_msg,result=result)
    except Exception as e:
        job_update(jid,status="error",error="Falha na transcrição: "+str(e),message="ERRO NA IA")
    finally:
        audio.unlink(missing_ok=True)

def template_signature():
    try:
        st=TEMPLATE.stat()
        return f"{st.st_size}:{st.st_mtime_ns}"
    except Exception:
        return "missing"

def get_template_copy():
    global _template_rgba
    sig=template_signature()
    with _template_lock:
        if _template_rgba is None or getattr(get_template_copy,"sig",None)!=sig:
            _template_rgba=Image.open(TEMPLATE).convert("RGBA")
            get_template_copy.sig=sig
        return _template_rgba.copy()

def get_font(size):
    size=int(size)
    if not PYFONT:
        # Never render with Pillow's thin/default fallback. That was the cause
        # of exported captions looking different from the bold preview.
        raise RuntimeError("Fonte negrito de legenda indisponível no servidor")
    with _font_lock:
        f=_font_cache.get(size)
        if f is None:
            try:
                f=ImageFont.truetype(PYFONT,size)
            except Exception as exc:
                raise RuntimeError("Falha ao carregar a fonte negrito de legenda") from exc
            _font_cache[size]=f
        return f

def font_signature():
    if not PYFONT:
        return CAPTION_STYLE_VERSION+":builtin"
    try:
        st=Path(PYFONT).stat()
        return CAPTION_STYLE_VERSION+":"+Path(PYFONT).name+f":{st.st_size}:{st.st_mtime_ns}"
    except Exception:
        return CAPTION_STYLE_VERSION+":"+str(PYFONT)

def text_width(draw,text,font):
    b=draw.textbbox((0,0),text,font=font); return b[2]-b[0]

def partitions(words,n):
    if n==1: yield [" ".join(words)]
    elif n==2:
        for i in range(1,len(words)): yield [" ".join(words[:i])," ".join(words[i:])]
    else:
        for i in range(1,len(words)-1):
            for j in range(i+1,len(words)): yield [" ".join(words[:i])," ".join(words[i:j])," ".join(words[j:])]

def fit_caption(draw,text,widths,max_size=72,min_size=32):
    words=clean_text(text).upper().split()
    if not words: return [],max_size
    # Fixed visual standard: prefer exactly 3 lines whenever possible.
    order=[3,2,1] if len(words)>=3 else [len(words)]
    for size in range(max_size,min_size-1,-2):
        font=get_font(size)
        for n in order:
            if n<1 or len(words)<n: continue
            best=None; best_score=None
            for lines in partitions(words,n):
                if len(lines)>len(widths): continue
                used=[]; ok=True
                for k,line in enumerate(lines):
                    w=text_width(draw,line,font); lim=widths[k]
                    if w>lim: ok=False; break
                    used.append(w/lim)
                if ok:
                    score=sum((1-u)**2 for u in used)
                    if best_score is None or score<best_score: best_score=score; best=lines
            if best: return best,size
    font=get_font(min_size)
    lines=[]; remain=words[:]
    for lim in widths:
        line=[]
        while remain:
            test=" ".join(line+[remain[0]])
            if line and text_width(draw,test,font)>lim: break
            line.append(remain.pop(0))
        if line: lines.append(" ".join(line))
        if not remain: break
    if remain and lines: lines[-1]=trim_words(lines[-1]+" "+" ".join(remain),max(1,len(lines[-1].split())))+"…"
    return lines[:3],min_size


def caption_overlay_key(top,bottom):
    raw=(template_signature()+"|"+font_signature()+"|"+clean_text(top).upper()+"|"+clean_text(bottom).upper()).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()

def get_caption_overlay(top,bottom,target):
    key=caption_overlay_key(top,bottom)
    cached=CACHE/("overlay_"+key+".png")
    if cached.exists():
        try:
            os.link(cached,target)
        except Exception:
            shutil.copy2(cached,target)
        return True,key
    make_caption_overlay(top,bottom,target)
    try:
        shutil.copy2(target,cached)
    except Exception:
        pass
    return False,key

def make_caption_overlay(top,bottom,out_path):
    im=get_template_copy(); draw=ImageDraw.Draw(im)
    for text,widths,ys in [(top,[620,730,730],[170,365,480]),(bottom,[740,740,640],[1425,1580,1715])]:
        lines,size=fit_caption(draw,text,widths)
        font=get_font(size)
        use_ys=ys[:len(lines)] if len(lines)>=3 else ([ys[1]] if len(lines)==1 else [ys[0]+30,ys[2]-30])
        for line,y in zip(lines,use_ys):
            draw.text((540,y),line,font=font,fill=(0,0,0,255),anchor="mm",align="center",stroke_width=max(2,int(size/28)),stroke_fill=(0,0,0,255))
    im.save(out_path,"PNG",compress_level=1)

def validate_output(path,expected_duration,expect_audio=False):
    p=probe(path)
    if p["width"]!=1080 or p["height"]!=1920: return False,"Resolução final inválida.",p
    if expected_duration>0 and abs(p["duration"]-expected_duration)>max(2.0,expected_duration*0.08):
        return False,"Duração final inválida.",p
    if Path(path).stat().st_size<10000: return False,"Arquivo final vazio.",p
    if p.get("video_codec") not in ("h264","avc1"): return False,"Codec de vídeo final inválido.",p
    if expect_audio and not p.get("has_audio"): return False,"Áudio original não chegou ao arquivo final.",p
    if p.get("has_audio") and p.get("audio_codec") not in ("aac","mp4a"): return False,"Codec de áudio final inválido.",p
    if p.get("has_audio") and int(p.get("audio_sample_rate") or 0) not in (0,44100,48000): return False,"Taxa de áudio final incompatível.",p
    if p.get("has_audio") and int(p.get("audio_channels") or 0)>2: return False,"Número de canais de áudio inesperado.",p
    fps=float(p.get("fps") or 0)
    if fps and not (28.0<=fps<=31.0): return False,"FPS final fora do padrão.",p
    return True,"",p

def render_cache_key(meta,opts):
    stable={k:opts.get(k) for k in ("top","bottom","start","end","zoom","posY","mode")}
    raw=(PIPELINE_VERSION+"|"+template_signature()+"|"+(meta.get("sha256") or "")+"|"+json.dumps(stable,sort_keys=True,ensure_ascii=False)).encode()
    return hashlib.sha256(raw).hexdigest()

def ensure_thumbnail(video_path,jid):
    thumb=OUTPUTS/(jid+".jpg")
    if thumb.exists() and thumb.stat().st_size>1000: return thumb
    try:
        r=subprocess.run([FFMPEG,"-y","-hide_banner","-loglevel","error","-ss","0.2","-i",str(video_path),
                          "-vf","scale=360:-2:flags=fast_bilinear","-frames:v","1","-q:v","5",str(thumb)],
                         capture_output=True,timeout=30)
        if r.returncode==0 and thumb.exists() and thumb.stat().st_size>1000:return thumb
    except Exception: pass
    thumb.unlink(missing_ok=True)
    return None

def run_render(jid,fid,opts):
    if cancelled(jid):
        job_update(jid,status="cancelled",message="Cancelado antes de iniciar."); return
    meta=load_upload(fid)
    if not meta:
        job_update(jid,status="error",error="Vídeo não encontrado no servidor."); return
    if not meta.get("sha256"):
        meta["sha256"]=sha256_file(meta["path"]); atomic_json_write(upload_meta_path(fid),meta)
    start=max(0.0,float(opts.get("start") or 0)); duration_all=float(meta.get("duration") or 0)
    end=float(opts.get("end") or duration_all or 0)
    if duration_all>0: end=min(end if end>0 else duration_all,duration_all)
    if end<=start: job_update(jid,status="error",error="O fim do corte precisa ser maior que o início."); return
    clip=end-start; mode=str(opts.get("mode") or "smart")
    if mode not in VALID_MODES: mode="smart"
    key=render_cache_key(meta,opts); cached=cache_get("render:"+key)
    output=OUTPUTS/(jid+".mp4")
    partial=OUTPUTS/(jid+".partial.mp4")
    if cached and cached.get("file_path") and Path(cached["file_path"]).exists():
        try: os.link(cached["file_path"],output)
        except Exception: shutil.copy2(cached["file_path"],output)
        cp=probe(output); thumb=ensure_thumbnail(output,jid)
        result={"download_url":"/download/"+jid,"name":safe_name(Path(meta["original_name"]).stem+"_EDITADO.mp4"),
                "cached":True,"size":output.stat().st_size,"duration":cp.get("duration"),
                "width":cp.get("width"),"height":cp.get("height"),"fps":cp.get("fps"),
                "video_codec":cp.get("video_codec"),"audio_codec":cp.get("audio_codec"),
                "audio_sample_rate":cp.get("audio_sample_rate"),"audio_channels":cp.get("audio_channels"),
                "applied_zoom":min(1.8,max(1.0,float(opts.get("zoom") or 1.0))),
                "applied_posY":min(100,max(-100,float(opts.get("posY") or 0))),
                "framing_version":"v7.20-preview-match",
                "preview_url":("/preview/"+jid if thumb else None)}
        job_update(jid,status="done",progress=100,message="VÍDEO PRONTO · CACHE",result=result); return
    overlay=TMP/(jid+"_overlay.png")
    try:
        job_update(jid,status="running",progress=1,message="PREPARANDO MODELO VISUAL")
        overlay_cached,overlay_key=get_caption_overlay(clean_text(opts.get("top") or ""),clean_text(opts.get("bottom") or ""),overlay)
        zoom=min(1.8,max(1.0,float(opts.get("zoom") or 1.0))); pos_y=min(100,max(-100,float(opts.get("posY") or 0)))
        tw=int(round(1080*zoom/2)*2); th=int(round(810*zoom/2)*2)
        # V7.20: o controle vertical precisa reproduzir exatamente a escala usada
        # na prévia web: +/-100 = +/-12% da altura central, multiplicado pelo zoom.
        # Antes, posY percorria TODO o excesso vertical do source e o MP4 podia sair
        # muito acima/abaixo do que o usuário havia visto na tela.
        pan_px=(pos_y/100.0)*(0.12*810.0*zoom)
        crop_y=f"max(0,min(ih-oh,(ih-oh)/2+({pan_px:.4f})))"
        if mode=="quality":
            scale_flags="lanczos"; quality_filter=",unsharp=5:5:0.32:5:5:0"
        elif mode=="fast":
            scale_flags="fast_bilinear"; quality_filter=""
        else:
            scale_flags="bicubic"; quality_filter=""
        filt=(f"[0:v]scale={tw}:{th}:force_original_aspect_ratio=increase:flags={scale_flags},"
              f"crop=1080:810:x='(iw-ow)/2':y='{crop_y}'{quality_filter},setsar=1,"
              "pad=1080:1920:0:555:color=0x111b28[v0];"
              "[1:v]format=rgba[ov];[v0][ov]overlay=0:0:format=auto[outv]")
        if ENCODER=="h264_nvenc":
            cq="18" if mode=="quality" else ("22" if mode=="fast" else "20")
            venc=["-c:v","h264_nvenc","-preset","p4","-cq",cq,"-profile:v","high","-g","60"]
        else:
            if mode=="quality": preset,crf="fast","17"
            elif mode=="fast": preset,crf="superfast","21"
            else: preset,crf="veryfast","19"
            venc=["-c:v","libx264","-preset",preset,"-crf",crf,"-profile:v","high",
                  "-g","60","-keyint_min","30","-sc_threshold","40"]
        # V7.21 performance-only: usa até 8 núcleos no encoder sem mudar preset/CRF/resolução.
        threads=max(2,min(8,os.cpu_count() or 4))
        if mode=="quality":
            audio_filter="highpass=f=55,loudnorm=I=-16:LRA=11:TP=-1.5,alimiter=limit=0.95,aresample=async=1:first_pts=0"
        elif mode=="fast":
            audio_filter="dynaudnorm=f=180:g=6,alimiter=limit=0.96,aresample=async=1:first_pts=0"
        else:
            audio_filter="highpass=f=60,dynaudnorm=f=150:g=8,alimiter=limit=0.95,aresample=async=1:first_pts=0"
        cmd=[FFMPEG,"-y","-hide_banner","-fflags","+genpts","-threads",str(threads),"-filter_threads",str(max(1,threads//2)),
             "-ss",f"{start:.3f}","-i",meta["path"],"-loop","1","-framerate","30","-i",str(overlay),
             "-t",f"{clip:.3f}","-filter_complex",filt,"-map","[outv]"]
        if meta.get("has_audio"):
            cmd+=["-map","0:a:0?"]
        cmd+=["-sn","-dn","-map_metadata","-1","-r","30"]+venc+[
              "-pix_fmt","yuv420p","-colorspace","bt709","-color_primaries","bt709","-color_trc","bt709"]
        if meta.get("has_audio"):
            cmd+=["-c:a","aac","-b:a","160k","-ar","48000","-af",audio_filter]
        cmd+=[
             "-movflags","+faststart","-max_muxing_queue_size","2048",
             "-progress","pipe:1","-nostats","-loglevel","error",str(partial)]
        job_update(jid,progress=2,message="RENDERIZANDO MP4")
        render_started=time.time()
        proc=subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,bufsize=1)
        max_wall=max(180.0,clip*8.0)
        watchdog=threading.Timer(max_wall,lambda: proc.kill() if proc.poll() is None else None)
        watchdog.daemon=True; watchdog.start()
        for line in proc.stdout:
            if cancelled(jid):
                proc.terminate(); partial.unlink(missing_ok=True); output.unlink(missing_ok=True)
                job_update(jid,status="cancelled",message="Cancelado."); return
            if line.startswith("out_time_us="):
                try:
                    sec=int(line.split("=",1)[1])/1_000_000.0
                    job_update(jid,progress=min(96,max(2,int(sec/clip*94))),message="RENDERIZANDO MP4")
                except Exception: pass
        rc=proc.wait(); watchdog.cancel()
        err=(proc.stderr.read() or "").strip()
        if rc!=0 or not partial.exists(): raise RuntimeError(err[-1200:] or "FFmpeg falhou ou excedeu o tempo limite.")
        os.replace(partial,output)
        job_update(jid,progress=97,message="CONFERINDO ARQUIVO FINAL")
        ok,msg,out_probe=validate_output(output,clip,bool(meta.get("has_audio")))
        if not ok: raise RuntimeError(msg)
        thumb=ensure_thumbnail(output,jid)
        canonical=CACHE/("render_"+key+".mp4")
        if not canonical.exists():
            # V7.21 performance-only: OUTPUTS e CACHE ficam no mesmo volume no Termux.
            # Hard-link evita copiar o MP4 inteiro uma segunda vez após renderizar.
            try: os.link(output,canonical)
            except Exception: shutil.copy2(output,canonical)
        cache_put("render:"+key,"render",{"validated":True},str(canonical))
        result={"download_url":"/download/"+jid,
                "name":safe_name(Path(meta["original_name"]).stem+"_EDITADO.mp4"),
                "cached":False,"size":output.stat().st_size,"duration":out_probe.get("duration",clip),
                "width":out_probe.get("width"),"height":out_probe.get("height"),
                "video_codec":out_probe.get("video_codec"),"audio_codec":out_probe.get("audio_codec"),
                "audio_sample_rate":out_probe.get("audio_sample_rate"),"audio_channels":out_probe.get("audio_channels"),
                "fps":out_probe.get("fps"),"overlay_cached":overlay_cached,"encoder":ENCODER,"template_signature":template_signature(),
                "applied_zoom":zoom,"applied_posY":pos_y,"framing_version":"v7.20-preview-match",
                "render_seconds":round(time.time()-render_started,2),
                "preview_url":("/preview/"+jid if thumb.exists() else None)}
        job_update(jid,status="done",progress=100,message="PRONTO PARA BAIXAR",result=result)
    except Exception as e:
        partial.unlink(missing_ok=True); output.unlink(missing_ok=True)
        job_update(jid,status="error",error="Falha na renderização: "+str(e),message="ERRO NA RENDERIZAÇÃO")
    finally:
        overlay.unlink(missing_ok=True)


def normalize_job_payload(kind,opts):
    opts=dict(opts or {})
    mode=str(opts.get("mode") or "smart")
    if mode not in VALID_MODES: mode="smart"
    if kind=="transcribe":
        return {"mode":mode}
    def num(name,default=0.0,digits=3):
        try: return round(float(opts.get(name,default) or default),digits)
        except Exception: return round(float(default),digits)
    return {
        "top":clean_text(str(opts.get("top") or ""))[:240],
        "bottom":clean_text(str(opts.get("bottom") or ""))[:240],
        "start":num("start",0.0,3),
        "end":num("end",0.0,3),
        "zoom":min(1.8,max(1.0,num("zoom",1.0,3))),
        "posY":min(100.0,max(-100.0,num("posY",0.0,2))),
        "mode":mode
    }

def _payload_stable(kind,opts):
    return json.dumps(normalize_job_payload(kind,opts),sort_keys=True,ensure_ascii=False,separators=(",",":"))

def find_equivalent_job(kind,fid,opts):
    stable=_payload_stable(kind,opts)
    now=time.time()
    with jobs_lock:
        candidates=list(jobs.values())
    for j in reversed(candidates):
        if j.get("kind")!=kind or j.get("file_id")!=fid: continue
        if j.get("status") not in ("queued","running","done"): continue
        if now-float(j.get("updated_at") or 0)>86400: continue
        other=_payload_stable(kind,j.get("payload") or {})
        if other==stable:
            if j.get("status")=="done" and kind=="render" and not (OUTPUTS/(j["id"]+".mp4")).exists():
                continue
            return j.get("id")
    # Also search persisted jobs so retries after a process/browser restart are idempotent.
    with db_conn() as c:
        rows=c.execute("""SELECT * FROM jobs
                          WHERE kind=? AND file_id=? AND status IN ('queued','running','done')
                            AND updated_at>? ORDER BY updated_at DESC LIMIT 50""",
                       (kind,fid,now-86400)).fetchall()
    for row in rows:
        j=row_to_job(row)
        if _payload_stable(kind,j.get("payload") or {})!=stable: continue
        if j.get("status")=="done" and kind=="render" and not (OUTPUTS/(j["id"]+".mp4")).exists():
            continue
        with jobs_lock: jobs[j["id"]]=j
        return j["id"]
    return None

def queued_count():
    with jobs_lock:
        return sum(1 for j in jobs.values() if j.get("status") in ("queued","running"))

def create_job(kind,fid,opts=None):
    opts=normalize_job_payload(kind,opts or {})
    existing=find_equivalent_job(kind,fid,opts)
    if existing: return existing
    if queued_count()>=MAX_QUEUE:
        raise RuntimeError("Fila cheia. Aguarde alguns trabalhos terminarem.")
    jid=uuid.uuid4().hex; now=time.time()
    qpos=queued_count()+1
    j={"id":jid,"kind":kind,"file_id":fid,"status":"queued","progress":0,"message":f"NA FILA · POSIÇÃO {qpos}",
       "error":None,"result":None,"payload":opts,"cancel_requested":False,"created_at":now,"updated_at":now}
    with jobs_lock: jobs[jid]=j; persist_job(j)
    if kind=="transcribe": worker.submit(run_transcription,jid,fid,opts)
    else: worker.submit(run_render,jid,fid,opts)
    return jid

def recover_jobs_once():
    global recovery_done
    with recovery_lock:
        if recovery_done: return
        recovery_done=True
        with db_conn() as c:
            rows=c.execute("SELECT * FROM jobs WHERE status IN ('queued','running') ORDER BY created_at").fetchall()
        for r in rows:
            j=row_to_job(r)
            if time.time()-float(j.get("updated_at") or 0)>6*3600:
                j["status"]="error";j["message"]="JOB ANTIGO NÃO RETOMADO";j["error"]="Processamento antigo expirou após reinício."
                with jobs_lock: jobs[j["id"]]=j;persist_job(j)
                continue
            j["status"]="queued"; j["message"]="RECUPERADO APÓS REINÍCIO"; j["cancel_requested"]=False
            with jobs_lock: jobs[j["id"]]=j; persist_job(j)
            if load_upload(j["file_id"]):
                if j["kind"]=="transcribe": worker.submit(run_transcription,j["id"],j["file_id"],j["payload"])
                else: worker.submit(run_render,j["id"],j["file_id"],j["payload"])
            else: job_update(j["id"],status="error",error="Arquivo de origem não está mais disponível.")

def prune_cache_size():
    try:
        files=[p for p in CACHE.glob("*") if p.is_file()]
        total=sum(p.stat().st_size for p in files)
        if total<=MAX_CACHE_BYTES: return 0
        removed=0
        files.sort(key=lambda p:p.stat().st_mtime)
        target=int(MAX_CACHE_BYTES*0.85)
        for p in files:
            if total<=target: break
            size=p.stat().st_size
            # Remove DB rows pointing to this file before unlinking.
            with db_conn() as c:
                c.execute("DELETE FROM cache WHERE file_path=?",(str(p),))
            p.unlink(missing_ok=True)
            total-=size; removed+=1
        return removed
    except Exception:
        return 0

def prune_job_memory():
    with jobs_lock:
        if len(jobs)<=MAX_JOB_MEMORY:return 0
        finished=[j for j in jobs.values() if j.get("status") in ("done","error","cancelled")]
        finished.sort(key=lambda j:float(j.get("updated_at") or 0))
        remove=max(0,len(jobs)-MAX_JOB_MEMORY)
        removed=0
        for j in finished[:remove]:
            jid=j.get("id"); jobs.pop(jid,None); _job_persist_state.pop(jid,None); removed+=1
        return removed

def cleanup_old(force=False):
    global _cleanup_last
    now=time.time()
    with _cleanup_lock:
        if not force and now-_cleanup_last<300:
            return
        _cleanup_last=now
    with jobs_lock:
        active_file_ids={j.get("file_id") for j in jobs.values() if j.get("status") in ("queued","running")}
    for folder,age in ((CHUNKS,2*3600),(TMP,6*3600),(UPLOADS,48*3600),(OUTPUTS,72*3600),(CACHE,7*86400)):
        for p in folder.glob("*"):
            if folder==UPLOADS and p.stem in active_file_ids:
                continue
            if p.name.endswith(".partial.mp4") and now-p.stat().st_mtime>3600:
                p.unlink(missing_ok=True); continue
            if p.suffix==".jpg" and folder==OUTPUTS and now-p.stat().st_mtime>72*3600:
                p.unlink(missing_ok=True); continue
            try:
                if now-p.stat().st_mtime>age:
                    if p.is_dir(): shutil.rmtree(p,ignore_errors=True)
                    else: p.unlink(missing_ok=True)
            except Exception: pass
    with db_conn() as c:
        c.execute("DELETE FROM jobs WHERE updated_at < ?",(now-14*86400,))
        c.execute("DELETE FROM cache WHERE last_used < ?",(now-14*86400,))
        rows=c.execute("SELECT cache_key,file_path FROM cache WHERE file_path IS NOT NULL").fetchall()
        for r in rows:
            if r["file_path"] and not Path(r["file_path"]).exists():
                c.execute("DELETE FROM cache WHERE cache_key=?",(r["cache_key"],))
    # Remove orphan thumbnails when the corresponding MP4 no longer exists.
    for thumb in OUTPUTS.glob("*.jpg"):
        if not (OUTPUTS/(thumb.stem+".mp4")).exists():
            thumb.unlink(missing_ok=True)
    prune_cache_size()
    prune_job_memory()
    with rate_lock:
        cutoff=now-RATE_WINDOW*2
        for ip in list(rate_buckets):
            vals=rate_buckets.get(ip) or []
            if not vals or vals[-1]<cutoff: rate_buckets.pop(ip,None)

@app.after_request
def add_headers(resp):
    resp.headers["X-Content-Type-Options"]="nosniff"
    resp.headers["Referrer-Policy"]="no-referrer"
    resp.headers["X-Frame-Options"]="SAMEORIGIN"
    resp.headers["Permissions-Policy"]="camera=(),microphone=(),geolocation=(),payment=(),usb=()"
    resp.headers["Cross-Origin-Resource-Policy"]="same-origin"
    resp.headers["Cross-Origin-Opener-Policy"]="same-origin"
    resp.headers["X-Permitted-Cross-Domain-Policies"]="none"
    resp.headers["X-Download-Options"]="noopen"
    resp.headers["Content-Security-Policy"]="default-src 'self'; img-src 'self' data: blob:; media-src 'self' blob:; style-src 'self' 'unsafe-inline'; script-src 'self'; connect-src 'self'; worker-src 'self' blob:; object-src 'none'; base-uri 'self'; frame-ancestors 'self'; form-action 'self'"
    resp.headers["X-Request-ID"]=getattr(g,"request_id","")
    started=getattr(g,"request_started",None)
    if started is not None:
        resp.headers["Server-Timing"]=f'app;dur={(time.perf_counter()-started)*1000:.1f}'
    if request.path.startswith("/api/"):
        resp.headers["Cache-Control"]="no-store"
    elif request.path in ("/","/sw.js","/manifest.webmanifest"):
        resp.headers["Cache-Control"]="no-cache, no-store, must-revalidate"
    elif request.path.startswith("/static/"):
        resp.headers["Cache-Control"]="public, max-age=3600"
    elapsed=(time.perf_counter()-started)*1000 if started is not None else 0.0
    with telemetry_lock:
        telemetry["requests"]+=1
        if request.path.startswith("/api/"): telemetry["api_requests"]+=1
        if resp.status_code>=400: telemetry["http_errors"]+=1
        n=max(1,telemetry["requests"])
        telemetry["avg_request_ms"]+= (elapsed-telemetry["avg_request_ms"])/n
        telemetry["max_request_ms"]=max(telemetry["max_request_ms"],elapsed)
    return resp

@app.get("/favicon.ico")
def favicon():
    svg="""<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" rx="14" fill="#061b38"/><path d="M18 16h28v32H18z" fill="#fff"/><path d="M23 22h18v5H23zm0 9h18v5H23zm0 9h12v5H23z" fill="#008cff"/></svg>"""
    return app.response_class(svg,mimetype="image/svg+xml",headers={"Cache-Control":"public,max-age=86400"})

@app.get("/api/version")
def version():
    return jsonify({"pipeline":PIPELINE_VERSION,"build":PERFORMANCE_BUILD,"started_at":PROCESS_STARTED,"encoder":ENCODER})

@app.get("/")
def index():
    recover_jobs_once(); return send_from_directory(str(STATIC),"index.html")

@app.get("/manifest.webmanifest")
def manifest():
    return send_from_directory(str(STATIC),"manifest.webmanifest")

@app.get("/sw.js")
def sw():
    return send_from_directory(str(STATIC),"sw.js",mimetype="application/javascript")


def runtime_metrics():
    try:
        load=os.getloadavg()
        load1=round(load[0],2)
    except Exception:
        load1=None
    try:
        du=shutil.disk_usage(DATA)
        disk_free=du.free
        disk_total=du.total
    except Exception:
        disk_free=disk_total=0
    with jobs_lock:
        mem=list(jobs.values())
    active=sum(1 for j in mem if j.get("status") in ("queued","running"))
    running=sum(1 for j in mem if j.get("status")=="running")
    queued=sum(1 for j in mem if j.get("status")=="queued")
    queued_times=[float(j.get("created_at") or time.time()) for j in mem if j.get("status")=="queued"]
    oldest_queue_age=round(max(0.0,time.time()-min(queued_times)),1) if queued_times else 0.0
    done_recent=sum(1 for j in mem if j.get("status")=="done" and time.time()-float(j.get("updated_at") or 0)<3600)
    errors_recent=sum(1 for j in mem if j.get("status")=="error" and time.time()-float(j.get("updated_at") or 0)<3600)
    try:
        cache_bytes=sum(p.stat().st_size for p in CACHE.glob("*") if p.is_file())
        output_bytes=sum(p.stat().st_size for p in OUTPUTS.glob("*") if p.is_file())
        upload_bytes=sum(p.stat().st_size for p in UPLOADS.glob("*") if p.is_file() and p.suffix!=".json")
        db_bytes=DB.stat().st_size if DB.exists() else 0
    except Exception:
        cache_bytes=output_bytes=upload_bytes=db_bytes=0
    try:
        rss_kb=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
        memory_mb=round(rss_kb/1024.0,1)
    except Exception:
        memory_mb=None
    with telemetry_lock:
        tel={k:(round(v,2) if isinstance(v,float) else v) for k,v in telemetry.items()}
    cache_total=tel.get("cache_hits",0)+tel.get("cache_misses",0)
    tel["cache_hit_rate"]=round(tel.get("cache_hits",0)/cache_total,3) if cache_total else None
    return {
        "active_jobs":active,"running_jobs":running,"queued_jobs":queued,
        "oldest_queue_age":oldest_queue_age,
        "done_last_hour":done_recent,"errors_last_hour":errors_recent,
        "loaded_models":sorted(models.keys()),
        "load1":load1,"disk_free":disk_free,"disk_total":disk_total,
        "disk_free_percent":round((disk_free/disk_total*100),1) if disk_total else None,
        "cache_bytes":cache_bytes,"output_bytes":output_bytes,"upload_bytes":upload_bytes,
        "database_bytes":db_bytes,"memory_mb":memory_mb,
        "jobs_in_memory":len(mem),"telemetry":tel
    }

@app.get("/api/health")
def health():
    recover_jobs_once()
    cleanup_old()
    m=runtime_metrics()
    ai_desc=("Gemini + Groq fallback" if GEMINI_ENABLED and GROQ_ENABLED else ("Gemini" if GEMINI_ENABLED else ("Groq" if GROQ_ENABLED else ("Whisper local" if WHISPER_AVAILABLE else "IA não configurada"))))
    return jsonify({"ok":True,"whisper":("Whisper fallback · base/small" if WHISPER_AVAILABLE else "Whisper opcional não instalado"),
                    "ai":ai_desc,
                    "gemini_configured":GEMINI_ENABLED,
                    "gemini_transcribe_model":GEMINI_TRANSCRIBE_MODEL if GEMINI_ENABLED else "",
                    "gemini_caption_model":GEMINI_CAPTION_MODEL if GEMINI_ENABLED else "",
                    "groq_configured":GROQ_ENABLED,
                    "groq_transcribe_model":GROQ_STT_MODEL if GROQ_ENABLED else "",
                    "groq_caption_model":GROQ_TEXT_MODEL if GROQ_ENABLED else "",
                    "renderer":"ffmpeg-h264-aac",
                    "encoder":ENCODER,"max_heavy_jobs":1,"pipeline":PIPELINE_VERSION,"build":PERFORMANCE_BUILD,"performance_profile":"v7.20-locked-speed-only",
                    "uptime_seconds":round(time.time()-PROCESS_STARTED,1),
                    "pid":os.getpid(),"rate_limit_per_min":RATE_MAX_MUTATIONS,
                    "queue_capacity":MAX_QUEUE,**m})

@app.get("/api/metrics")
def metrics():
    return jsonify({"ok":True,"pipeline":PIPELINE_VERSION,"build":PERFORMANCE_BUILD,**runtime_metrics()})

@app.get("/api/diagnostics")
def diagnostics():
    m=runtime_metrics()
    return jsonify({
        "ok":True,"pipeline":PIPELINE_VERSION,"build":PERFORMANCE_BUILD,
        "queue":{"active":m.get("active_jobs"),"running":m.get("running_jobs"),"queued":m.get("queued_jobs"),
                 "oldest_age":m.get("oldest_queue_age"),"capacity":MAX_QUEUE},
        "system":{"load1":m.get("load1"),"memory_mb":m.get("memory_mb"),
                  "disk_free_percent":m.get("disk_free_percent")},
        "storage":{"uploads":m.get("upload_bytes"),"outputs":m.get("output_bytes"),
                   "cache":m.get("cache_bytes"),"database":m.get("database_bytes")},
        "requests":m.get("telemetry"),"models":m.get("loaded_models")
    })

@app.get("/api/ready")
def ready():
    db_ok=False
    try:
        with db_conn() as c: c.execute("SELECT 1").fetchone()
        db_ok=True
    except Exception: pass
    checks={
        "template":TEMPLATE.exists(),
        "ffmpeg":bool(shutil.which(FFMPEG) or Path(FFMPEG).is_file()),
        "ffprobe":bool(shutil.which(FFPROBE) or Path(FFPROBE).is_file()),
        "data_writable":os.access(DATA,os.W_OK),
        "outputs_writable":os.access(OUTPUTS,os.W_OK),
        "database":db_ok,
        "disk_ok":free_disk_ok()
    }
    checks["caption_bold_font"] = bool(PYFONT and Path(PYFONT).is_file())
    ok=all(checks.values())
    return jsonify({"ok":ok,"checks":checks,"pipeline":PIPELINE_VERSION,"termux_compatible":True,"whisper_available":WHISPER_AVAILABLE,"base_dir":str(BASE),"port":int(os.getenv("PORT","8080")),"gemini_configured":GEMINI_ENABLED,"gemini_transcribe_model":GEMINI_TRANSCRIBE_MODEL if GEMINI_ENABLED else "","gemini_caption_model":GEMINI_CAPTION_MODEL if GEMINI_ENABLED else "","groq_configured":GROQ_ENABLED,"groq_transcribe_model":GROQ_STT_MODEL if GROQ_ENABLED else "","groq_caption_model":GROQ_TEXT_MODEL if GROQ_ENABLED else "","caption_font":(Path(PYFONT).name if PYFONT else "PIL-default"),"caption_style":CAPTION_STYLE_VERSION,"upload_rate_limit":RATE_UPLOAD_MUTATIONS,"heavy_workers":1,"queue_capacity":MAX_QUEUE,"build":PERFORMANCE_BUILD}), (200 if ok else 503)

def _valid_upload_id(v): return bool(re.fullmatch(r"[A-Za-z0-9_-]{8,96}",v or ""))

@app.post("/api/upload/lookup")
def upload_lookup():
    data=request.get_json(silent=True) or {}
    name=safe_name(data.get("name") or "")
    try:
        size=int(data.get("size") or 0)
    except Exception:
        size=0
    wanted_sha=str(data.get("sha256") or "").lower().strip()
    if wanted_sha and not re.fullmatch(r"[a-f0-9]{64}",wanted_sha):
        wanted_sha=""
    if not name or size<=0 or size>MAX_UPLOAD_BYTES:
        return jsonify({"found":False})
    newest=None
    for meta_file in UPLOADS.glob("*.json"):
        try:
            meta=json.loads(meta_file.read_text("utf-8"))
            path=Path(meta.get("path") or "")
            same=(meta.get("original_name")==name and int(meta.get("size") or 0)==size and path.exists())
            if same and wanted_sha:
                same=str(meta.get("sha256") or "").lower()==wanted_sha
            if same and (newest is None or float(meta.get("created_at") or 0)>float(newest.get("created_at") or 0)):
                newest=meta
        except Exception:
            continue
    return jsonify({"found":bool(newest),"meta":newest})

@app.get("/api/upload/status/<upload_id>")
def upload_status(upload_id):
    if not _valid_upload_id(upload_id): return jsonify({"error":"ID inválido."}),400
    meta=load_upload(upload_id)
    if meta: return jsonify({"complete":True,"meta":meta,"received":[]})
    d=CHUNKS/upload_id
    rec=[]; received_bytes=0; meta_info={}
    if d.exists():
        try: meta_info=json.loads((d/"meta.json").read_text("utf-8")) if (d/"meta.json").exists() else {}
        except Exception: meta_info={}
        for p in d.glob("*.part"):
            try:
                rec.append(int(p.stem)); received_bytes+=p.stat().st_size
            except Exception: pass
    total=int(meta_info.get("total") or 0)
    return jsonify({"complete":False,"received":sorted(rec),"received_bytes":received_bytes,
                    "total":total,"name":meta_info.get("name"),"size":int(meta_info.get("size") or 0)})

@app.post("/api/upload/chunk")
def api_upload_chunk():
    upload_id=str(request.form.get("upload_id") or ""); name=safe_name(request.form.get("name") or "video.mp4")
    try:
        index=int(request.form.get("index") or -1); total=int(request.form.get("total") or 0)
        file_size=int(request.form.get("size") or 0)
    except Exception:
        return api_error("Índice ou tamanho inválido.",400)
    part=request.files.get("chunk"); expected=(request.form.get("sha256") or "").lower()
    if expected and not re.fullmatch(r"[a-f0-9]{64}",expected): return api_error("Hash da parte inválido.",400)
    if not _valid_upload_id(upload_id) or part is None or total<1 or total>10000 or index<0 or index>=total:
        return api_error("Dados de upload inválidos.",400)
    if file_size<=0 or file_size>MAX_UPLOAD_BYTES: return api_error("Tamanho total do vídeo inválido.",400)
    if not free_disk_ok(): return api_error("Servidor sem espaço livre suficiente. Tente novamente depois.",507)
    d=CHUNKS/upload_id; d.mkdir(parents=True,exist_ok=True)
    meta_path=d/"meta.json"
    if meta_path.exists():
        try:
            oldmeta=json.loads(meta_path.read_text("utf-8"))
            if oldmeta.get("name")!=name or int(oldmeta.get("total") or 0)!=total or int(oldmeta.get("size") or 0)!=file_size:
                return api_error("Metadados do upload não conferem com as partes já recebidas.",409)
        except Exception:
            return api_error("Metadados de retomada corrompidos.",409)
    dst=d/(f"{index:06d}.part"); tmp=d/(f"{index:06d}.tmp")
    # Repetir a mesma parte é seguro: não regrava se ela já confere.
    if dst.exists():
        same=True
        if expected:
            try: same=sha256_file(dst)==expected
            except Exception: same=False
        if same:
            return jsonify({"ok":True,"index":index,"duplicate":True,"bytes":dst.stat().st_size})
    part.save(tmp)
    chunk_size=tmp.stat().st_size if tmp.exists() else 0
    if chunk_size<=0 or chunk_size>MAX_CHUNK_BYTES:
        tmp.unlink(missing_ok=True); return api_error("Parte vazia ou grande demais.",413,index=index)
    if expected:
        got=sha256_file(tmp)
        if got!=expected:
            tmp.unlink(missing_ok=True); return api_error("Parte corrompida; reenvie.",409,index=index)
    os.replace(tmp,dst)
    atomic_json_write(meta_path,{"name":name,"total":total,"size":file_size,"updated_at":time.time()})
    return jsonify({"ok":True,"index":index,"bytes":chunk_size})

@app.post("/api/upload/complete")
def api_upload_complete():
    data=request.get_json(silent=True) or {}; upload_id=str(data.get("upload_id") or ""); name=safe_name(data.get("name") or "video.mp4")
    try:
        total=int(data.get("total") or 0); expected_size=int(data.get("size") or 0)
    except Exception:
        total=0; expected_size=0
    if not _valid_upload_id(upload_id) or total<1: return api_error("Upload inválido.",400)
    if expected_size<=0 or expected_size>MAX_UPLOAD_BYTES: return api_error("Tamanho final inválido.",400)
    existing=load_upload(upload_id)
    if existing:
        if int(existing.get("size") or 0)!=expected_size: return api_error("Arquivo existente tem tamanho diferente.",409)
        return jsonify(existing)
    ext=Path(name).suffix.lower()
    if ext not in ALLOWED: return api_error("Formato não suportado.",400)
    d=CHUNKS/upload_id
    try:
        dm=json.loads((d/"meta.json").read_text("utf-8"))
        if dm.get("name")!=name or int(dm.get("total") or 0)!=total or int(dm.get("size") or 0)!=expected_size:
            return api_error("Metadados finais não conferem com o upload.",409)
    except Exception:
        return api_error("Metadados do upload ausentes ou inválidos.",409)
    parts=[d/(f"{i:06d}.part") for i in range(total)]
    missing=[i for i,p in enumerate(parts) if not p.exists()]
    if missing: return api_error("Upload incompleto.",409,missing=missing[:50])
    actual_sum=sum(p.stat().st_size for p in parts)
    if actual_sum!=expected_size: return api_error("Tamanho das partes não confere com o vídeo original.",409,received=actual_sum,expected=expected_size)
    final=UPLOADS/(upload_id+ext); assembling=UPLOADS/(upload_id+ext+".assembling")
    assembling.unlink(missing_ok=True)
    try:
        # V7.21 performance-only: calcula o SHA-256 enquanto monta o arquivo.
        # Evita reler o vídeo inteiro do armazenamento após o upload.
        hasher=hashlib.sha256()
        with open(assembling,"wb") as out:
            for part in parts:
                with open(part,"rb") as inp:
                    while True:
                        block=inp.read(8*1024*1024)
                        if not block: break
                        out.write(block); hasher.update(block)
            out.flush(); os.fsync(out.fileno())
        if assembling.stat().st_size!=expected_size: raise RuntimeError("Tamanho montado não confere.")
        sha=hasher.hexdigest()
        os.replace(assembling,final)
    except Exception as e:
        assembling.unlink(missing_ok=True)
        return api_error("Falha ao montar o upload: "+str(e),500)
    pr=probe(final)
    if pr["duration"]<=0 or pr["width"]<=0 or pr["height"]<=0:
        final.unlink(missing_ok=True); return api_error("Vídeo inválido ou corrompido.",400)
    meta={"id":upload_id,"path":str(final),"original_name":name,"size":final.stat().st_size,
          "created_at":time.time(),"sha256":sha,**pr}
    atomic_json_write(upload_meta_path(upload_id),meta); shutil.rmtree(d,ignore_errors=True)
    cleanup_old(); return jsonify(meta)

@app.delete("/api/file/<fid>")
def api_delete_file(fid):
    if not _valid_upload_id(fid): return api_error("ID de arquivo inválido.",400)
    with db_conn() as c:
        active=c.execute("SELECT COUNT(*) FROM jobs WHERE file_id=? AND status IN ('queued','running')",(fid,)).fetchone()[0]
    if active: return api_error("Arquivo está sendo usado por um processamento.",409)
    meta=load_upload(fid)
    if meta: Path(meta["path"]).unlink(missing_ok=True)
    upload_meta_path(fid).unlink(missing_ok=True)
    return jsonify({"ok":True})

@app.post("/api/transcribe")
def api_transcribe():
    data=request.get_json(silent=True) or {}; fid=str(data.get("file_id") or "")
    if not load_upload(fid): return api_error("Vídeo não encontrado.",404)
    mode=str(data.get("mode") or "smart")
    data["mode"]=mode if mode in VALID_MODES else "smart"
    try: jid=create_job("transcribe",fid,data)
    except RuntimeError as e: return api_error(str(e),429)
    return jsonify({"job_id":jid})

@app.post("/api/render")
def api_render():
    data=request.get_json(silent=True) or {}; fid=str(data.get("file_id") or "")
    if not load_upload(fid): return api_error("Vídeo não encontrado.",404)
    data["top"]=clean_text(str(data.get("top") or ""))[:240]
    data["bottom"]=clean_text(str(data.get("bottom") or ""))[:240]
    # Nunca permitir que mensagem interna/diagnóstico da IA seja queimada no vídeo.
    if _caption_has_meta(data["top"]) or _caption_has_meta(data["bottom"]):
        return api_error("A legenda contém texto interno da IA. Gere/revise a legenda antes de exportar.",400)
    try:
        data["zoom"]=min(1.8,max(1.0,float(data.get("zoom") or 1.0)))
        data["posY"]=min(100,max(-100,float(data.get("posY") or 0)))
    except Exception:
        return api_error("Parâmetros de enquadramento inválidos.",400)
    try: jid=create_job("render",fid,data)
    except RuntimeError as e: return api_error(str(e),429)
    return jsonify({"job_id":jid})

@app.get("/api/job/<jid>")
def api_job(jid):
    if not re.fullmatch(r"[a-f0-9]{32}",jid or ""): return api_error("ID inválido.",400)
    j=get_job(jid)
    if not j: return api_error("Job não encontrado.",404)
    if j.get("status")=="queued":
        with db_conn() as c:
            ahead=c.execute("""SELECT COUNT(*) FROM jobs
                               WHERE status IN ('queued','running') AND created_at < ?""",
                            (float(j.get("created_at") or 0),)).fetchone()[0]
        j["queue_ahead"]=int(ahead)
    j["age_seconds"]=round(max(0.0,time.time()-float(j.get("created_at") or time.time())),1)
    j.pop("payload",None)
    return jsonify(j)

@app.post("/api/job/<jid>/cancel")
def api_cancel(jid):
    if not re.fullmatch(r"[a-f0-9]{32}",jid or ""): return api_error("ID inválido.",400)
    j=get_job(jid)
    if not j: return api_error("Job não encontrado.",404)
    if j.get("status") in ("done","error","cancelled"):
        return jsonify({"ok":True,"status":j.get("status"),"already_finished":True})
    if j.get("status")=="queued":
        job_update(jid,cancel_requested=True,status="cancelled",message="CANCELADO NA FILA")
        return jsonify({"ok":True,"status":"cancelled"})
    job_update(jid,cancel_requested=True,message="CANCELANDO")
    return jsonify({"ok":True,"status":"cancelling"})

@app.post("/api/job/<jid>/retry")
def retry_job(jid):
    if not re.fullmatch(r"[a-f0-9]{32}",jid or ""): return api_error("ID inválido.",400)
    j=get_job(jid)
    if not j: return api_error("Job não encontrado.",404)
    if not load_upload(j["file_id"]): return api_error("Arquivo original não está mais disponível.",410)
    return jsonify({"job_id":create_job(j["kind"],j["file_id"],j.get("payload") or {})})

@app.get("/api/history")
def history():
    try:
        limit=max(1,min(100,int(request.args.get("limit","30"))))
        offset=max(0,int(request.args.get("offset","0")))
    except Exception:
        limit,offset=30,0
    with db_conn() as c:
        total=c.execute("SELECT COUNT(*) FROM jobs WHERE kind='render' AND status='done'").fetchone()[0]
        rows=c.execute("SELECT * FROM jobs WHERE kind='render' AND status='done' ORDER BY updated_at DESC LIMIT ? OFFSET ?",(limit,offset)).fetchall()
    out=[]
    for r in rows:
        j=row_to_job(r)
        if not (OUTPUTS/(j["id"]+".mp4")).exists():
            continue
        out.append({"id":j["id"],"updated_at":j["updated_at"],"result":j["result"],"file_id":j["file_id"]})
    return jsonify({"items":out,"limit":limit,"offset":offset,"total":int(total),"has_more":offset+len(rows)<int(total)})

@app.get("/preview/<jid>")
def preview(jid):
    if not re.fullmatch(r"[a-f0-9]{32}",jid or ""): return jsonify({"error":"ID inválido."}),400
    p=OUTPUTS/(jid+".jpg")
    if not p.exists(): return jsonify({"error":"Prévia não encontrada."}),404
    return send_file(str(p),mimetype="image/jpeg",conditional=True,max_age=3600)

@app.get("/download/<jid>")
def download(jid):
    if not re.fullmatch(r"[a-f0-9]{32}",jid or ""): return api_error("ID inválido.",400)
    j=get_job(jid)
    if not j or j.get("status")!="done" or j.get("kind")!="render": return jsonify({"error":"Arquivo ainda não está pronto."}),404
    p=OUTPUTS/(jid+".mp4")
    if not p.exists(): return jsonify({"error":"Arquivo não encontrado."}),404
    name=((j.get("result") or {}).get("name") or "video_editado.mp4")
    resp=send_file(str(p),as_attachment=True,download_name=name,mimetype="video/mp4",conditional=True,max_age=0)
    resp.headers["Cache-Control"]="private, no-store"
    return resp

def api_error(message,status=400,**extra):
    payload={"error":message,"request_id":getattr(g,"request_id","")}
    payload.update(extra)
    return jsonify(payload),status

@app.errorhandler(404)
def not_found(err):
    if request.path.startswith("/api/"):
        return api_error("Rota ou recurso não encontrado.",404)
    return err

@app.errorhandler(500)
def internal_error(_):
    if request.path.startswith("/api/"):
        return api_error("Erro interno do servidor.",500)
    return "Erro interno",500

@app.errorhandler(413)
def too_large(_): return api_error("Arquivo grande demais para este servidor.",413)

recover_jobs_once()
cleanup_old()

if __name__=="__main__":
    app.run(host="0.0.0.0",port=int(os.getenv("PORT","8080")),threaded=True)
