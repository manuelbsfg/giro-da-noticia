(function(){
"use strict";
var $=function(id){return document.getElementById(id)};
var el={
 input:$("fileInput"),pick:$("pickBtn"),drop:$("dropZone"),aiAll:$("aiAllBtn"),all:$("processAllBtn"),clear:$("clearBtn"),
 items:$("items"),count:$("countStat"),aiStat:$("aiStat"),done:$("doneStat"),server:$("serverStat"),queueLabel:$("queueLabel"),
 globalError:$("globalError"),editorError:$("editorError"),preview:$("previewVideo"),noVideo:$("noVideo"),
 top:$("topText"),bottom:$("bottomText"),start:$("startTime"),end:$("endTime"),zoom:$("zoom"),zoomVal:$("zoomVal"),posY:$("posY"),posYVal:$("posYVal"),
 aiBtn:$("aiBtn"),play:$("playBtn"),reset:$("resetBtn"),export:$("exportBtn"),download:$("downloadBtn"),transcript:$("transcript"),diag:$("diag"),frame:$("frame"),
 t1:$("t1"),t2:$("t2"),t3:$("t3"),b1:$("b1"),b2:$("b2"),b3:$("b3"),
 mode:$("modeSelect"),history:$("historyItems"),refreshHistory:$("refreshHistory"),editorStatus:$("editorStatus"),editorStep:$("editorStep"),netBadge:$("netBadge"),versionBadge:$("versionBadge")
};
var entries=[],activeId=null,busy=false,seq=1,renderQueued=false,lastHealth=null;
var isLocalServer=(location.hostname==="127.0.0.1"||location.hostname==="localhost");
var lastEditorVisualSig="";
var wakeLock=null,wakeUsers=0;
async function acquireWakeLock(){
 wakeUsers++;
 try{if("wakeLock" in navigator&&!wakeLock)wakeLock=await navigator.wakeLock.request("screen")}catch(_){}
}
async function releaseWakeLock(){
 wakeUsers=Math.max(0,wakeUsers-1);
 if(wakeUsers>0)return;
 try{if(wakeLock){await wakeLock.release();wakeLock=null}}catch(_){}
}
try{if(navigator.storage&&navigator.storage.persist)navigator.storage.persist().catch(function(){})}catch(_){}
try{var savedMode=localStorage.getItem("cortes:mode");if(savedMode)el.mode.value=savedMode}catch(_){}
el.mode.onchange=function(){
 try{localStorage.setItem("cortes:mode",el.mode.value)}catch(_){}
 entries.forEach(function(e){if(e&&e.status==="done")invalidateRenderedOutput(e,"MODO ALTERADO · RENDERIZE NOVAMENTE");if(e)saveDraft(e)});
 renderList();syncActiveFields();
};


function showError(node,msg){node.textContent=msg||"";node.classList.toggle("show",!!msg)}
function updateNetBadge(){
 if(!el.netBadge)return;
 el.netBadge.textContent=navigator.onLine?"REDE ONLINE":"SEM INTERNET";
 el.netBadge.style.borderColor=navigator.onLine?"#1f609b":"#8c3348";
}
window.addEventListener("online",function(){updateNetBadge();
try{if(navigator.connection)navigator.connection.addEventListener("change",function(){updateNetBadge();if(!busy)checkHealth()})}catch(_){}checkHealth()});
window.addEventListener("offline",function(){
 updateNetBadge();
 if(el.server)el.server.textContent="SEM REDE";
 if(el.diag)el.diag.textContent="Sem internet. O lote e os ajustes locais continuam salvos.";
});
updateNetBadge();
function fmtBytes(n){if(!Number.isFinite(n))return "—";var u=["B","KB","MB","GB"],i=0;while(n>=1024&&i<u.length-1){n/=1024;i++}return n.toFixed(i?1:0)+" "+u[i]}
function fmtTime(s){if(!Number.isFinite(s))return "—";var m=Math.floor(s/60),ss=Math.floor(s%60).toString().padStart(2,"0");return m+":"+ss}
function isVideoFile(f){return (f.type&&f.type.indexOf("video/")===0)||/\.(mp4|mov|m4v|webm|3gp|mkv)$/i.test(f.name||"")}
function getActive(){return entries.find(function(e){return e.id===activeId})||null}
function stateText(s){return({local:"Pronto",uploading:"Enviando",ready:"Pronto",transcribing:"IA transcrevendo",transcribed:"Legenda IA pronta",rendering:"Renderizando MP4",done:"Pronto para baixar",error:"Erro"})[s]||s}
function fileKey(f){return "draft:"+[f.name,f.size,f.lastModified].join("|")}
function loadDraft(f){
 try{return JSON.parse(localStorage.getItem(fileKey(f))||"null")}catch(_){return null}
}
function saveDraft(e){
 if(!e||!e.file)return;
 try{
   localStorage.setItem(fileKey(e.file),JSON.stringify({
     top:e.top||"",bottom:e.bottom||"",start:e.start||0,end:e.end||e.duration||0,
     zoom:e.zoom||1,posY:e.posY||0,transcript:e.transcript||"",clipTranscript:e.clipTranscript||"",
     manualCaptionEdited:!!e.manualCaptionEdited,outputStale:!!e.outputStale,
     renderedTop:e.renderedTop||"",renderedBottom:e.renderedBottom||"",
     renderedStart:Number(e.renderedStart)||0,renderedEnd:Number(e.renderedEnd)||0,
     renderedZoom:Number(e.renderedZoom)||0,renderedPosY:Number(e.renderedPosY)||0,
     aiConfidence:e.aiConfidence,aiQuality:e.aiQuality,aiRefined:e.aiRefined||false,
     aiRescue:e.aiRescue||false,aiStrategy:e.aiStrategy||"",aiPasses:e.aiPasses||1,
     speechCoverage:e.speechCoverage,repetitionRatio:e.repetitionRatio,
     captionQuality:e.captionQuality,captionOverlap:e.captionOverlap,
     clipScore:e.clipScore,hookScore:e.hookScore,closureScore:e.closureScore,
     clipSpeechDensity:e.clipSpeechDensity,clipReason:e.clipReason||"",clipGapSeconds:e.clipGapSeconds,
     aiWarnings:e.aiWarnings||[],jobId:e.jobId||null,
     downloadUrl:e.outputStale?null:(e.downloadUrl||null),downloadName:e.downloadName||null,
     savedAt:Date.now()
   }));
 }catch(_){}
}
function setEditorStep(text){if(el.editorStep)el.editorStep.textContent=text||"AGUARDANDO"}

function readDuration(file){
 return new Promise(function(resolve){
   var u=URL.createObjectURL(file),v=document.createElement("video");
   v.preload="metadata";
   v.onloadedmetadata=function(){var d=Number(v.duration)||0;URL.revokeObjectURL(u);resolve(d)};
   v.onerror=function(){URL.revokeObjectURL(u);resolve(0)};
   v.src=u;
 });
}

function splitWords(text,maxLines){
 var words=(text||"").trim().toUpperCase().split(/\s+/).filter(Boolean);
 if(!words.length)return [];
 var n=words.length>=3?3:words.length;
 var lines=[],start=0;
 for(var i=0;i<n;i++){
   var left=words.length-start;
   var take=Math.ceil(left/(n-i));
   lines.push(words.slice(start,start+take).join(" "));
   start+=take;
 }
 return lines;
}

// V7.16 — legenda obrigatoriamente baseada na fala + rescue automático + persistência V7.15.
function _foldCaptionText(t){return String(t||"").normalize("NFD").replace(/[\u0300-\u036f]/g,"").toLowerCase().replace(/\s+/g," ").trim()}
function captionLooksInternal(t){
 var x=_foldCaptionText(t);
 if(!x)return false;
 return /\ba ia\b|evidencia (?:insuficiente|suficiente)|nao (?:foi possivel|encontrou|ha)|afirmar um fato|sem evidencia|conteudo insuficiente|informacao insuficiente|precisa de revisao|nao consigo|modelo de ia/.test(x);
}
function captionLooksGeneric(t){
 var x=_foldCaptionText(t);
 if(!x)return true;
 if(/^video (?:traz|mostra|apresenta|explica)\b/.test(x))return true;
 if(/\b(?:um|o) relato\b|contexto da situacao|explica o contexto|mais detalhes da situacao|queria falar (?:uma|de uma) coisa|tentando entender|vou explicar|aconteceu uma coisa/.test(x))return true;
 var stop=new Set(["a","o","e","de","da","do","das","dos","em","no","na","nos","nas","um","uma","que","para","por","com","se","foi","tem","mais","como","ele","ela","eles","elas","isso","esse","essa","ao","aos","as","os"]);
 var words=x.replace(/[^a-z0-9 ]/g," ").split(/\s+/).filter(function(w){return w.length>=3&&!stop.has(w)});
 return new Set(words).size<3;
}
function _trimCaptionWords(t,max){
 var w=String(t||"").replace(/\s+/g," ").trim().split(" ").filter(Boolean).slice(0,max);
 var dangling=new Set(["de","da","do","das","dos","no","na","nos","nas","em","para","por","com","que","e","mas","ou","a","o"]);
 while(w.length>4&&dangling.has(_foldCaptionText(w[w.length-1]).replace(/[^a-z]/g,"")))w.pop();
 return w.join(" ").trim();
}
function _captionTokens(t){
 var stop=new Set(["a","o","e","de","da","do","das","dos","em","no","na","nos","nas","um","uma","que","para","por","com","se","foi","tem","mais","como","ele","ela","eles","elas","isso","esse","essa","ao","aos","as","os"]);
 return _foldCaptionText(t).replace(/[^a-z0-9 ]/g," ").split(/\s+/).filter(function(w){return w.length>=3&&!stop.has(w)});
}
function captionGroundingRatio(cap,tr){
 var c=_captionTokens(cap),set=new Set(_captionTokens(tr));if(!c.length)return 0;
 var hit=0;c.forEach(function(w){if(set.has(w))hit++});return hit/c.length;
}
function captionOverlapRatio(a,b){
 var A=new Set(_captionTokens(a)),B=new Set(_captionTokens(b));if(!A.size||!B.size)return 0;
 var hit=0;A.forEach(function(w){if(B.has(w))hit++});return hit/Math.max(1,Math.min(A.size,B.size));
}
function captionIsSafe(t,tr,other){
 var x=_trimCaptionWords(t,18),n=x.split(/\s+/).filter(Boolean).length;
 if(n<4||captionLooksInternal(x)||captionLooksGeneric(x))return false;
 if(tr&&captionGroundingRatio(x,tr)<0.68)return false;
 if(other&&captionOverlapRatio(x,other)>0.58)return false;
 return true;
}
function captionFallbackCandidates(tr){
 var raw=String(tr||"").replace(/\s+/g," ").trim();if(!raw)return [];
 var out=[],seen=new Set();
 function add(x,pos){x=_trimCaptionWords(x,17);var k=_foldCaptionText(x);if(!x||seen.has(k)||captionLooksInternal(x)||captionLooksGeneric(x))return;seen.add(k);out.push({text:x,pos:pos})}
 var parts=raw.split(/(?<=[.!?])\s+|\s+[–—-]\s+/).filter(Boolean);
 parts.forEach(function(x,i){add(x,parts.length>1?i/(parts.length-1):0.5)});
 var words=raw.split(/\s+/).filter(Boolean);
 for(var start=0;start<words.length;start+=8){add(words.slice(start,start+16).join(" "),words.length>1?start/(words.length-1):0.5)}
 return out;
}
function ensureSafeCaptionPair(top,bottom,tr){
 tr=String(tr||"");var t=_trimCaptionWords(top,16),b=_trimCaptionWords(bottom,17),replaced=false;
 var cands=captionFallbackCandidates(tr);
 if(!captionIsSafe(t,tr,"")){t="";replaced=true;for(var i=0;i<cands.length;i++){if(cands[i].pos<=0.65&&captionIsSafe(cands[i].text,tr,"")){t=cands[i].text;break}}}
 if(!captionIsSafe(b,tr,t)){b="";replaced=true;for(var j=cands.length-1;j>=0;j--){if(cands[j].pos>=0.25&&captionIsSafe(cands[j].text,tr,t)){b=cands[j].text;break}}}
 if(!b){for(var k=0;k<cands.length;k++){if(captionIsSafe(cands[k].text,tr,t)){b=cands[k].text;break}}}
 return {top:t.toUpperCase(),bottom:b.toUpperCase(),blocked:!(captionIsSafe(t,tr,"")&&captionIsSafe(b,tr,t)),replaced:replaced};
}

function fitPreviewLine(node,text,widthRatio){
 node.textContent=text||"";
 if(!text){node.style.fontSize="1px";return}
 var frameW=el.frame.clientWidth||405;
 var maxPx=frameW*(72/1080);
 var minPx=frameW*(32/1080);
 var canvas=fitPreviewLine.canvas||(fitPreviewLine.canvas=document.createElement("canvas"));
 var ctx=canvas.getContext("2d");
 var target=frameW*widthRatio;
 var size=maxPx;
 while(size>minPx){
   ctx.font="900 "+size+"px Arial Black,Arial,Helvetica,sans-serif";
   if(ctx.measureText(text).width<=target)break;
   size-=1;
 }
 node.style.fontSize=Math.max(minPx,size)+"px";
}

if(document.fonts&&document.fonts.ready){document.fonts.ready.then(function(){try{drawCaptions()}catch(_){}})}

function drawCaptions(){
 var tops=splitWords(el.top.value,3),bots=splitWords(el.bottom.value,3);
 [el.t1,el.t2,el.t3].forEach(function(n){n.textContent=""});
 [el.b1,el.b2,el.b3].forEach(function(n){n.textContent=""});
 var tNodes=tops.length===1?[el.t2]:(tops.length===2?[el.t1,el.t3]:[el.t1,el.t2,el.t3]);
 var bNodes=bots.length===1?[el.b2]:(bots.length===2?[el.b1,el.b3]:[el.b1,el.b2,el.b3]);
 var tw=tops.length===1?[.676]:(tops.length===2?[.574,.676]:[.574,.676,.676]);
 var bw=bots.length===1?[.685]:(bots.length===2?[.685,.593]:[.685,.685,.593]);
 tops.forEach(function(line,i){fitPreviewLine(tNodes[i],line,tw[i])});
 bots.forEach(function(line,i){fitPreviewLine(bNodes[i],line,bw[i])});
}

function updatePreviewTransform(){
 var z=Number(el.zoom.value||100)/100;
 var py=Number(el.posY.value||0);
 // V7.20: esta é a referência visual usada também pelo FFmpeg.
 el.preview.style.transformOrigin="50% 50%";
 el.preview.style.transform="scale("+z+") translateY("+(-py*0.12)+"%)";
 el.zoomVal.textContent=Math.round(z*100)+"%";
 el.posYVal.textContent=String(py);
}

function updateStats(){
 el.count.textContent=entries.length+"/10";
 el.aiStat.textContent=entries.filter(function(e){return !!e.transcript}).length;
 el.done.textContent=entries.filter(function(e){return e.status==="done"}).length;
 el.queueLabel.textContent=entries.length+(entries.length===1?" item":" itens");
 el.aiAll.disabled=busy||!entries.some(function(e){return !e.transcript&&e.status!=="done"&&!e.working});
 el.all.disabled=busy||!entries.some(function(e){return e.status!=="done"&&!e.working});
 el.clear.disabled=busy||entries.length===0||entries.some(function(e){return e.working});
}

function createQueueRow(e){
 var row=document.createElement("div");
 row.className="item";row.dataset.id=e.id;row.setAttribute("role","listitem");row.tabIndex=0;
 row.innerHTML='<div class="thumb">🎬</div><div class="info"><div class="name"></div><div class="meta mainmeta"></div><div class="state"><span class="dot"></span><span class="stateText"></span></div><div class="progress-track"><div class="progress"></div></div><div class="meta errmsg" style="color:#ff9bb7"></div></div><div class="item-actions"><button class="btn btn-soft mini edit" type="button">Editar</button><button class="btn btn-ai mini ai" type="button">IA</button><button class="btn btn-primary mini action" type="button">Processar</button><button class="btn btn-danger mini remove" type="button">Remover</button></div>';
 var id=e.id;
 row.querySelector(".edit").onclick=function(){selectEntry(id)};
 row.querySelector(".ai").onclick=function(){var x=entries.find(function(v){return v.id===id});if(!x)return;if(x.working)cancelEntry(id);else transcribeOne(id)};
 row.querySelector(".action").onclick=function(){var x=entries.find(function(v){return v.id===id});if(!x)return;if(x.status==="done")downloadEntry(id);else if(!x.transcript)processOneAuto(id);else renderOne(id)};
 row.querySelector(".remove").onclick=function(){removeEntry(id)};
 row.onclick=function(ev){if(ev.target.tagName!=="BUTTON")selectEntry(id)};
 row.onkeydown=function(ev){if((ev.key==="Enter"||ev.key===" ")&&ev.target===row){ev.preventDefault();selectEntry(id)}};
 return row;
}

function updateQueueRow(row,e){
 var active=e.id===activeId;
 row.className="item"+(active?" active":"")+(e.working?" working":"");
 row.setAttribute("aria-current",active?"true":"false");
 row.setAttribute("aria-busy",e.working?"true":"false");
 var name=row.querySelector(".name");if(name.textContent!==e.file.name)name.textContent=e.file.name;
 var meta=fmtTime(e.duration)+" · "+fmtBytes(e.file.size)
   +(e.outputSize?" · saída "+fmtBytes(e.outputSize):"")
   +(e.renderSeconds?" · render "+e.renderSeconds.toFixed(1)+"s":"");
 var metaNode=row.querySelector(".mainmeta");if(metaNode.textContent!==meta)metaNode.textContent=meta;
 var st=row.querySelector(".state");if(st.dataset.s!==e.status)st.dataset.s=e.status;
 var state=(e.message||stateText(e.status))+(e.progress>0&&["uploading","transcribing","rendering"].indexOf(e.status)>=0?" "+e.progress+"%":"");
 var stateNode=row.querySelector(".stateText");if(stateNode.textContent!==state)stateNode.textContent=state;
 var prog=row.querySelector(".progress"),pct=Math.max(0,Math.min(100,Number(e.progress)||0));
 if(prog.dataset.pct!==String(pct)){prog.dataset.pct=String(pct);prog.style.width=pct+"%"}
 var track=prog.parentElement;
 track.setAttribute("role","progressbar");track.setAttribute("aria-valuemin","0");track.setAttribute("aria-valuemax","100");track.setAttribute("aria-valuenow",String(Math.round(pct)));
 var err=row.querySelector(".errmsg");if(err.textContent!==(e.error||""))err.textContent=e.error||"";
 var ai=row.querySelector(".ai"),action=row.querySelector(".action"),edit=row.querySelector(".edit"),remove=row.querySelector(".remove");
 ai.textContent=e.working?"Cancelar":(e.transcript?"IA ✓":"IA");
 ai.disabled=e.status==="done"||(!e.working&&busy);
 if(e.status==="done"){action.textContent="Baixar";action.className="btn btn-good mini action";action.disabled=false}
 else if(e.status==="error"){action.textContent="Tentar de novo";action.className="btn btn-primary mini action";action.disabled=busy||!!e.working}
 else if(!e.transcript){action.textContent="IA + Processar";action.className="btn btn-primary mini action";action.disabled=busy||!!e.working}
 else{action.textContent="Processar";action.className="btn btn-primary mini action";action.disabled=busy||!!e.working}
 edit.disabled=!!e.working;
 remove.disabled=busy||!!e.working;
}

function renderListNow(){
 renderQueued=false;
 if(!entries.length){
   if(!el.items.querySelector(".empty"))el.items.innerHTML='<div class="empty">Nenhum vídeo adicionado.</div>';
   updateStats();return;
 }
 var empty=el.items.querySelector(".empty");if(empty)empty.remove();
 var wanted=new Set(entries.map(function(e){return e.id}));
 Array.from(el.items.querySelectorAll(".item[data-id]")).forEach(function(row){
   if(!wanted.has(row.dataset.id))row.remove();
 });
 entries.forEach(function(e){
   var row=el.items.querySelector('.item[data-id="'+CSS.escape(e.id)+'"]');
   if(!row){row=createQueueRow(e);el.items.appendChild(row)}
   updateQueueRow(row,e);
   el.items.appendChild(row);
 });
 updateStats();
}

function renderList(){
 if(renderQueued)return;
 renderQueued=true;
 requestAnimationFrame(renderListNow);
}

function syncActiveFields(){
 var e=getActive(),disabled=!e||!!(e&&e.working);
 [el.top,el.bottom,el.start,el.end,el.zoom,el.posY,el.aiBtn,el.play,el.reset,el.export].forEach(function(n){n.disabled=disabled});
 el.download.disabled=!e||e.status!=="done";
 if(!e){
   el.aiBtn.textContent="IA: transcrever + colocar legendas";
   if(el.editorStatus)el.editorStatus.firstChild.nodeValue="Selecione um vídeo e toque em IA.";
   setEditorStep("AGUARDANDO");
   el.preview.pause();el.preview.removeAttribute("src");el.preview.load();el.noVideo.style.display="flex";
   el.top.value="";el.bottom.value="";el.start.value=0;el.end.value=0;el.zoom.value=100;el.posY.value=0;el.transcript.textContent="A transcrição aparecerá aqui.";lastEditorVisualSig="";drawCaptions();return;
 }
 var statusMsg=e.message||stateText(e.status);
 if(e.status==="uploading"){
   el.aiBtn.textContent="ENVIANDO VÍDEO…";
   if(el.editorStatus)el.editorStatus.textContent=statusMsg+(e.progress?(" · "+e.progress+"%"):"");
 }else if(e.status==="transcribing"){
   el.aiBtn.textContent="IA TRANSCREVENDO…";
   if(el.editorStatus)el.editorStatus.textContent=statusMsg+" · aguarde";
 }else if(e.status==="rendering"){
   el.aiBtn.textContent="IA CONCLUÍDA";
   if(el.editorStatus)el.editorStatus.textContent=statusMsg+(e.progress?(" · "+e.progress+"%"):"");
 }else if(e.status==="transcribed"){
   el.aiBtn.textContent="IA ✓ transcrição pronta";
   if(el.editorStatus)el.editorStatus.textContent="TRANSCRIÇÃO + LEGENDAS PRONTAS";
 }else if(e.status==="done"){
   el.aiBtn.textContent="IA ✓";
   if(el.editorStatus)el.editorStatus.textContent="VÍDEO PRONTO PARA BAIXAR";
 }else if(e.status==="error"){
   el.aiBtn.textContent="TENTAR IA NOVAMENTE";
   if(el.editorStatus)el.editorStatus.textContent="ERRO: "+(e.error||"tente novamente");
 }else{
   el.aiBtn.textContent=e.transcript?"IA ✓ transcrição pronta":"IA: transcrever + colocar legendas";
   if(el.editorStatus)el.editorStatus.textContent=statusMsg||"Pronto para iniciar.";
 }
 el.noVideo.style.display="none";if(el.preview.src!==e.localUrl)el.preview.src=e.localUrl;
 el.top.value=e.top||"";el.bottom.value=e.bottom||"";el.start.value=e.start||0;el.end.value=e.end||e.duration||0;el.zoom.value=Math.round((e.zoom||1)*100);el.posY.value=e.posY||0;
 var aiInfo="";
 if(Number.isFinite(e.aiConfidence))aiInfo+="Confiança: "+e.aiConfidence.toFixed(2);
 if(Number.isFinite(e.aiQuality))aiInfo+=(aiInfo?" · ":"")+"Qualidade: "+e.aiQuality.toFixed(2);
 if(e.aiRefined)aiInfo+=(aiInfo?" · ":"")+"Refinado com SMALL";
 if(e.aiRescue)aiInfo+=(aiInfo?" · ":"")+"Correção anti-repetição aplicada";
 if(e.aiStrategy)aiInfo+=(aiInfo?" · ":"")+"Estratégia: "+e.aiStrategy;
 if(Number.isFinite(e.aiPasses)&&e.aiPasses>1)aiInfo+=(aiInfo?" · ":"")+e.aiPasses+" passagens";
 if(Number.isFinite(e.speechCoverage))aiInfo+=(aiInfo?" · ":"")+"Fala útil: "+Math.round(e.speechCoverage*100)+"%";
 if(Number.isFinite(e.captionQuality))aiInfo+=(aiInfo?" · ":"")+"Legenda: "+e.captionQuality.toFixed(1);
 if(Number.isFinite(e.captionOverlap))aiInfo+=(aiInfo?" · ":"")+"Sobreposição: "+Math.round(e.captionOverlap*100)+"%";
 if(Number.isFinite(e.hookScore))aiInfo+=(aiInfo?" · ":"")+"Gancho: "+e.hookScore.toFixed(1);
 if(Number.isFinite(e.closureScore))aiInfo+=(aiInfo?" · ":"")+"Fechamento: "+e.closureScore.toFixed(1);
 if(Number.isFinite(e.clipSpeechDensity))aiInfo+=(aiInfo?" · ":"")+"Densidade: "+Math.round(e.clipSpeechDensity*100)+"%";
 if(e.clipReason)aiInfo+=(aiInfo?" · ":"")+e.clipReason;
 if(e.aiWarnings&&e.aiWarnings.length)aiInfo+=(aiInfo?" · ":"")+"Avisos: "+e.aiWarnings.join(", ");
 if(e.aiTiming&&Number(e.aiTiming.base_transcribe_seconds))aiInfo+=(aiInfo?" · ":"")+"IA "+Number(e.aiTiming.base_transcribe_seconds).toFixed(1)+"s";
 var transcriptText=(aiInfo?aiInfo+"\n\n":"")+(e.transcript||"Ainda não transcrito pela IA.");
 if(el.transcript.textContent!==transcriptText)el.transcript.textContent=transcriptText;
 // V7.21 performance-only: não recalcula fonte/canvas e transform do vídeo em todo poll de progresso.
 // Redesenha somente quando vídeo, texto ou enquadramento realmente mudarem.
 var visualSig=[e.id,e.top||"",e.bottom||"",Number(e.zoom||1).toFixed(4),Number(e.posY||0)].join("|");
 if(visualSig!==lastEditorVisualSig){
   lastEditorVisualSig=visualSig;drawCaptions();updatePreviewTransform();
 }
}

function invalidateRenderedOutput(e,reason){
 if(!e)return;
 var hadOutput=!!(e.downloadUrl||e.previewUrl||e.status==="done");
 if(!hadOutput)return;
 e.outputStale=true;
 e.downloadUrl=null;e.previewUrl=null;e.outputSize=0;e.outputDuration=0;e.outputFps=0;e.renderSeconds=0;
 e.status=e.transcript?"transcribed":"ready";e.progress=0;
 e.message=reason||"ALTERAÇÃO SALVA · RENDERIZE NOVAMENTE";
}
function saveActiveEdits(markManual){
 var e=getActive();if(!e)return;
 var top=el.top.value,bottom=el.bottom.value,start=Math.max(0,Number(el.start.value||0)),end=Math.max(0,Number(el.end.value||e.duration||0)),zoom=Number(el.zoom.value||100)/100,posY=Number(el.posY.value||0);
 var textChanged=top!==String(e.top||"")||bottom!==String(e.bottom||"");
 var renderChanged=textChanged||start!==Number(e.start||0)||end!==Number(e.end||0)||zoom!==Number(e.zoom||1)||posY!==Number(e.posY||0);
 if(textChanged&&markManual)e.manualCaptionEdited=true;
 e.top=top;e.bottom=bottom;e.start=start;e.end=end;e.zoom=zoom;e.posY=posY;
 if(renderChanged)invalidateRenderedOutput(e,textChanged?"LEGENDA ALTERADA E SALVA · RENDERIZE NOVAMENTE":"AJUSTE ALTERADO E SALVO · RENDERIZE NOVAMENTE");
 saveDraft(e);
}

function selectEntry(id){
 if(activeId && activeId!==id)saveActiveEdits();
 activeId=id;
 renderList();
 syncActiveFields();
 showError(el.editorError,"");
}

async function addFiles(files){
 showError(el.globalError,"");
 var list=Array.from(files||[]).filter(isVideoFile);
 if(!list.length){showError(el.globalError,"Selecione arquivos de vídeo válidos.");return}
 if(entries.length+list.length>10){showError(el.globalError,"O limite é 10 vídeos por lote. Remova algum item ou selecione menos arquivos.");return}
 for(var i=0;i<list.length;i++){
   var f=list[i];
   if(entries.some(function(x){return x.file.name===f.name&&x.file.size===f.size&&x.file.lastModified===f.lastModified})){continue}
   var d=await readDuration(f);
   if(!d){showError(el.globalError,"Não consegui ler: "+f.name);continue}
   var draft=loadDraft(f)||{};
   var draftPair=draft.manualCaptionEdited?{top:String(draft.top||""),bottom:String(draft.bottom||""),blocked:false}:ensureSafeCaptionPair(draft.top||"",draft.bottom||"",draft.transcript||"");
   var e={id:"v"+(seq++),file:f,localUrl:URL.createObjectURL(f),duration:d,
     start:Number.isFinite(Number(draft.start))?Number(draft.start):0,
     end:Number.isFinite(Number(draft.end))&&Number(draft.end)>0?Math.min(Number(draft.end),d):d,
     zoom:Number(draft.zoom)||1,posY:Number(draft.posY)||0,top:draftPair.top||"",bottom:draftPair.bottom||"",captionBlocked:!!draftPair.blocked,
     transcript:draft.transcript||"",clipTranscript:draft.clipTranscript||"",manualCaptionEdited:!!draft.manualCaptionEdited,outputStale:!!draft.outputStale,
     renderedTop:draft.renderedTop||"",renderedBottom:draft.renderedBottom||"",renderedStart:Number(draft.renderedStart)||0,renderedEnd:Number(draft.renderedEnd)||0,renderedZoom:Number(draft.renderedZoom)||0,renderedPosY:Number(draft.renderedPosY)||0,
     aiConfidence:Number(draft.aiConfidence),aiQuality:Number(draft.aiQuality),
     aiRefined:!!draft.aiRefined,aiRescue:!!draft.aiRescue,aiStrategy:draft.aiStrategy||"",
     aiPasses:Number(draft.aiPasses||1),speechCoverage:Number(draft.speechCoverage),
     repetitionRatio:Number(draft.repetitionRatio),captionQuality:Number(draft.captionQuality),
     captionOverlap:Number(draft.captionOverlap),clipScore:Number(draft.clipScore),
     hookScore:Number(draft.hookScore),closureScore:Number(draft.closureScore),
     clipSpeechDensity:Number(draft.clipSpeechDensity),clipReason:draft.clipReason||"",
     clipGapSeconds:Number(draft.clipGapSeconds),
     aiWarnings:Array.isArray(draft.aiWarnings)?draft.aiWarnings:[],
     remoteId:null,status:draft.transcript?"transcribed":"local",
     progress:0,message:draft.transcript?"Rascunho recuperado":"Pronto",error:"",
     downloadUrl:draft.outputStale?null:(draft.downloadUrl||null),downloadName:draft.downloadName||null,jobId:draft.jobId||null};
   if(e.downloadUrl&&!e.outputStale){e.status="done";e.message="VÍDEO PRONTO · TOQUE EM BAIXAR";}
   else if(e.outputStale){e.status=e.transcript?"transcribed":"ready";e.message="ALTERAÇÃO SALVA · RENDERIZE NOVAMENTE";}
   entries.push(e);
 }
 if(!activeId&&entries.length)activeId=entries[0].id;
 renderList();syncActiveFields();
 entries.forEach(function(e){if(e.jobId)recoverPriorJob(e)});
}

function sleep(ms){return new Promise(function(res){setTimeout(res,ms)})}
async function fetchTimeout(url,options,ms){
 var ctrl=new AbortController(),timer=setTimeout(function(){ctrl.abort()},ms||12000);
 try{
   var opts=Object.assign({},options||{});opts.signal=ctrl.signal;
   return await fetch(url,opts);
 }finally{clearTimeout(timer)}
}
async function sha256Blob(blob){
 var buf=await blob.arrayBuffer();
 var dig=await crypto.subtle.digest("SHA-256",buf);
 return Array.from(new Uint8Array(dig)).map(function(x){return x.toString(16).padStart(2,"0")}).join("");
}
async function makeUploadId(file){
 var raw=new TextEncoder().encode([file.name,file.size,file.lastModified].join("|"));
 var dig=await crypto.subtle.digest("SHA-256",raw);
 return Array.from(new Uint8Array(dig)).slice(0,16).map(function(x){return x.toString(16).padStart(2,"0")}).join("");
}
async function postChunk(form,attempts){
 var last=null;
 for(var i=1;i<=attempts;i++){
   try{
     var r=await fetchTimeout("/api/upload/chunk",{method:"POST",body:form,cache:"no-store"},20000);
     var j=await r.json().catch(function(){return {}});
     if(r.ok)return j;
     last=new Error(j.error||("Falha HTTP "+r.status));
     if([408,409,429,500,502,503,504,522,523,524].indexOf(r.status)<0)break;
   }catch(err){last=err}
   if(i<attempts)await sleep(Math.min(4000,450*i*i));
 }
 throw last||new Error("Falha ao enviar parte do vídeo.");
}

async function lookupExistingUpload(e,tries){
 var last=null;
 for(var attempt=1;attempt<=Math.max(1,tries||1);attempt++){
   try{
     var lr=await fetchTimeout("/api/upload/lookup",{method:"POST",headers:{"Content-Type":"application/json"},
       body:JSON.stringify({name:e.file.name,size:e.file.size}),cache:"no-store"},15000);
     var lj=await lr.json().catch(function(){return {}});
     if(lr.ok&&lj.found&&lj.meta&&lj.meta.id){
       e.remoteId=lj.meta.id;
       e.duration=Number(lj.meta.duration)||e.duration;
       e.end=Math.min(e.end,e.duration)||e.duration;
       e.status=e.transcript?"transcribed":"ready";
       e.progress=0;
       e.error="";
       e.message="VÍDEO RECUPERADO DO SERVIDOR";
       renderList();syncActiveFields();
       return e.remoteId;
     }
   }catch(err){last=err}
   if(attempt<tries)await sleep(800*attempt);
 }
 return null;
}

async function _uploadFileCore(e){
 if(e.remoteId)return e.remoteId;
 e.status="uploading";e.progress=0;e.message="VERIFICANDO ENVIO";e.error="";renderList();
 var net=navigator.connection||{},down=Number(net.downlink||0);
 // V7.21 performance-only: no Termux local, menos requisições = envio bem mais rápido.
 // Fora do localhost, mantém tamanhos conservadores para redes instáveis.
 var chunkSize=isLocalServer
   ?(e.file.size>80*1024*1024?8*1024*1024:(e.file.size>16*1024*1024?4*1024*1024:2*1024*1024))
   :((down>=10||e.file.size>150*1024*1024)?2*1024*1024:(down>=3||e.file.size>40*1024*1024?1024*1024:512*1024));
 var total=Math.ceil(e.file.size/chunkSize);
 try{
   var existing=await lookupExistingUpload(e,3);
   if(existing)return existing;

   if(!e.uploadId)e.uploadId=await makeUploadId(e.file);
   var received=new Set();
   try{
     var sr=await fetchTimeout("/api/upload/status/"+e.uploadId,{cache:"no-store"},12000);
     var sj=await sr.json().catch(function(){return {}});
     if(sj.complete&&sj.meta&&sj.meta.id){
       e.remoteId=sj.meta.id;e.duration=Number(sj.meta.duration)||e.duration;e.end=Math.min(e.end,e.duration)||e.duration;
       e.status=e.transcript?"transcribed":"ready";e.progress=0;e.message="UPLOAD RECUPERADO";renderList();syncActiveFields();
       return e.remoteId;
     }
     (sj.received||[]).forEach(function(x){received.add(Number(x))});
     if(Number(sj.received_bytes)>0&&e.file.size>0){
       e.progress=Math.max(1,Math.min(95,Math.round((Number(sj.received_bytes)/e.file.size)*96)));
       e.message="RETOMANDO · "+e.progress+"% JÁ NO SERVIDOR";renderList();
     }
   }catch(_){e.message="CONTINUANDO ENVIO";renderList()}

   for(var i=0;i<total;i++){
     while(!navigator.onLine){
       e.message="SEM INTERNET · AGUARDANDO PARA CONTINUAR";renderList();
       await new Promise(function(resolve){
         var done=function(){window.removeEventListener("online",done);resolve()};
         window.addEventListener("online",done,{once:true});
       });
     }
     if(received.has(i)){
       e.progress=Math.max(1,Math.min(96,Math.round(((i+1)/total)*96)));renderList();continue;
     }
     var start=i*chunkSize,end=Math.min(e.file.size,start+chunkSize),blob=e.file.slice(start,end);
     var fd=new FormData();
     fd.append("upload_id",e.uploadId);fd.append("name",e.file.name);fd.append("index",String(i));fd.append("total",String(total));fd.append("size",String(e.file.size));
     if(!isLocalServer&&window.crypto&&crypto.subtle){
       if(blob.size>=1024*1024){e.message="CONFERINDO PARTE "+(i+1)+"/"+total;renderList()}
       fd.append("sha256",await sha256Blob(blob));
     }
     fd.append("chunk",blob,"part-"+i);
     await postChunk(fd,6);
     e.progress=Math.max(1,Math.min(96,Math.round(((i+1)/total)*96)));
     e.message="ENVIANDO "+(i+1)+"/"+total;renderList();
   }

   e.message="CONFERINDO UPLOAD";e.progress=97;renderList();
   var done=null,last=null;
   for(var attempt=1;attempt<=4;attempt++){
     try{
       var r=await fetchTimeout("/api/upload/complete",{method:"POST",headers:{"Content-Type":"application/json"},
         body:JSON.stringify({upload_id:e.uploadId,name:e.file.name,total:total,size:e.file.size}),cache:"no-store"},25000);
       var j=await r.json().catch(function(){return {}});
       if(r.ok&&j.id){done=j;break}
       last=new Error(j.error||("Falha HTTP "+r.status));
     }catch(err){last=err}
     if(attempt<4)await sleep(700*attempt);
   }
   if(!done)throw last||new Error("Falha ao finalizar envio.");
   e.remoteId=done.id;e.duration=Number(done.duration)||e.duration;e.end=Math.min(e.end,e.duration)||e.duration;
   e.status=e.transcript?"transcribed":"ready";e.progress=0;e.message="UPLOAD CONCLUÍDO";renderList();syncActiveFields();
   return e.remoteId;
 }catch(err){
   try{
     e.message="RECUPERANDO CONEXÃO";renderList();
     var recovered=await lookupExistingUpload(e,4);
     if(recovered)return recovered;
   }catch(_){}
   var raw=((err&&err.message)||"Falha ao enviar vídeo.");
   var msg=(err&&err.name==="AbortError")?"A conexão demorou para responder. Toque em Tentar de novo.":raw;
   if(/Failed to fetch|NetworkError|Load failed/i.test(msg))msg="A conexão com o servidor oscilou. Toque em Tentar de novo; o site tentará continuar do ponto salvo.";
   e.status="error";e.error=msg;e.message="ERRO DE CONEXÃO";renderList();syncActiveFields();
   throw new Error(msg);
 }
}

async function uploadFile(e){
 if(!e)throw new Error("Item de vídeo inválido.");
 if(e.remoteId)return e.remoteId;
 if(e._uploadPromise)return await e._uploadPromise;
 e._uploadPromise=_uploadFileCore(e);
 try{return await e._uploadPromise}
 finally{e._uploadPromise=null}
}

async function postJobWithRetry(url,payload){
 var lastError=null;
 for(var attempt=1;attempt<=3;attempt++){
   try{
     var r=await fetchTimeout(url,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(payload),cache:"no-store"},15000);
     var data=await r.json().catch(function(){return {}});
     if(r.ok&&data.job_id)return data;
     lastError=new Error(data.error||("Servidor respondeu "+r.status+"."));
     if(r.status===429&&attempt<3){
       var retry=Math.max(1,Math.min(8,Number(data.retry_after||r.headers.get("Retry-After")||1)));
       await sleep(retry*1000);continue;
     }
     if([502,503,504,522,523,524].indexOf(r.status)<0)break;
   }catch(err){lastError=err}
   if(attempt<3)await new Promise(function(res){setTimeout(res,700*attempt)});
 }
 throw new Error((lastError&&lastError.message)||"Não foi possível iniciar o processamento.");
}

async function startJob(url,payload,e,kind){
 var data=await postJobWithRetry(url,payload);
 e.jobId=data.job_id;e.status=kind==="transcribe"?"transcribing":"rendering";e.progress=0;e.error="";
 e.message=kind==="transcribe"?"IA na fila":"Render na fila";saveDraft(e);renderList();syncActiveFields();
 var pollFailures=0,lastProgress=-1,stablePolls=0;
 while(true){
   var wait=document.hidden?3500:(stablePolls>=6?2000:(stablePolls>=3?1400:900));
   await new Promise(function(res){setTimeout(res,wait)});
   try{
     // V7.23: Render gratuito pode responder lentamente enquanto FFmpeg/IA trabalha.
     // Timeout maior evita marcar uma resposta apenas lenta como queda de conexão.
     var jr=await fetchTimeout("/api/job/"+data.job_id,{cache:"no-store"},20000);
     var j=await jr.json().catch(function(){return {}});

     // Erros HTTP definitivos NÃO são falha de rede. Mostre a causa real imediatamente.
     if(!jr.ok){
       var httpErr=new Error(j.error||("Servidor respondeu "+jr.status+"."));
       httpErr.isJobTerminal=(jr.status>=400&&jr.status<500&&jr.status!==408&&jr.status!==429);
       httpErr.httpStatus=jr.status;
       throw httpErr;
     }

     var reconnected=pollFailures>0;
     pollFailures=0;
     var nextProgress=Number(j.progress)||0;
     stablePolls=(nextProgress===lastProgress)?stablePolls+1:0;
     lastProgress=nextProgress;
     e.progress=nextProgress;
     if(j.status==="queued"&&Number(j.queue_ahead)>=0)e.message="NA FILA · "+(Number(j.queue_ahead)+1)+"º";
     else e.message=j.message||stateText(e.status);
     if(reconnected)e.message="RECONECTADO · "+e.message;
     renderList();if(e.id===activeId)syncActiveFields();

     // V7.23: estes estados vieram do servidor e são terminais.
     // Antes o catch abaixo os transformava incorretamente em “RECONEXÃO 1/12”.
     if(j.status==="done"){e.jobId=null;saveDraft(e);return j.result||{}}
     if(j.status==="error"){
       e.jobId=null;saveDraft(e);
       var jobErr=new Error(j.error||j.message||"Erro no processamento.");jobErr.isJobTerminal=true;throw jobErr;
     }
     if(j.status==="cancelled"){
       e.jobId=null;saveDraft(e);
       var cancelErr=new Error("Processamento cancelado.");cancelErr.isJobTerminal=true;throw cancelErr;
     }
   }catch(err){
     if(err&&err.isJobTerminal)throw err;
     var status=Number(err&&err.httpStatus)||0;
     // 5xx, timeout e erro de transporte podem ser temporários; somente eles entram em reconexão.
     var transient=(!status||status===408||status===429||status>=500);
     if(!transient)throw err;
     pollFailures++;
     e.message="RECONEXÃO "+pollFailures+"/12";renderList();
     if(pollFailures>=12)throw new Error("A conexão com o servidor ficou indisponível por muito tempo. Tente novamente.");
     await sleep(Math.min(5000,600*pollFailures));
   }
 }
}

function isCancelMessage(msg){return /cancelad/i.test(String(msg||""))}
function isMissingRemoteMessage(msg){return /vídeo não encontrado|arquivo.*não.*disponível/i.test(String(msg||""))}

async function startJobRecoveringFile(url,payload,e,kind){
 try{
   return await startJob(url,payload,e,kind);
 }catch(err){
   if(isMissingRemoteMessage(err&&err.message)){
     e.remoteId=null;e.message="REENVIANDO ARQUIVO AO SERVIDOR";renderList();
     await uploadFile(e);
     var retryPayload=Object.assign({},payload,{file_id:e.remoteId});
     return await startJob(url,retryPayload,e,kind);
   }
   throw err;
 }
}

var preuploading=new Set();
async function recoverPriorJob(e){
 if(!e||!e.jobId)return false;
 try{
   var r=await fetchTimeout("/api/job/"+e.jobId,{cache:"no-store"},8000);
   var j=await r.json().catch(function(){return {}});
   if(!r.ok)return false;
   if(j.status==="done"&&j.result){
     var x=j.result||{};
     if(x.transcript){
       e.transcript=x.transcript||e.transcript||"";
       var recoveredPair=ensureSafeCaptionPair(x.top||e.top||"",x.bottom||e.bottom||"",x.clip_transcript||x.transcript||e.transcript||"");
       if(!e.manualCaptionEdited){e.top=recoveredPair.top;e.bottom=recoveredPair.bottom;e.captionBlocked=!!recoveredPair.blocked;}
       else e.captionBlocked=false;
       if(Number(x.suggested_end)>Number(x.suggested_start)){e.start=Number(x.suggested_start);e.end=Number(x.suggested_end)}
       e.status="transcribed";e.message=e.captionBlocked?"TRANSCRIÇÃO RECUPERADA · LEGENDA AGUARDA REVISÃO":"IA RECUPERADA DO SERVIDOR";e.progress=100;
     }else if(x.download_url){
       e.status="done";e.downloadUrl=x.download_url;e.downloadName=x.name||e.downloadName;
       e.outputSize=Number(x.size||0);e.progress=100;e.message="VÍDEO PRONTO RECUPERADO";
     }
     e.jobId=null;saveDraft(e);renderList();syncActiveFields();return true;
   }
   if(j.status==="queued"||j.status==="running"){
     e.message="PROCESSAMENTO ANTERIOR ENCONTRADO";renderList();
   }
 }catch(_){}
 return false;
}
async function preuploadNext(currentId){
 var next=entries.find(function(x){
   return x.id!==currentId&&!x.remoteId&&!x.working&&!preuploading.has(x.id)&&x.status!=="done";
 });
 if(!next)return;
 preuploading.add(next.id);
 try{
   next.message="PRÉ-ENVIANDO PRÓXIMO VÍDEO";
   await uploadFile(next);
 }catch(_){
   if(next.status==="error"){
     next.status="local";next.error="";next.message="Aguardando nova tentativa";
   }
 }finally{
   preuploading.delete(next.id);renderList();
 }
}

async function cancelEntry(id){
 var e=entries.find(function(x){return x.id===id});if(!e||!e.jobId)return;
 try{
   e.message="CANCELANDO";renderList();
   var r=await fetchTimeout("/api/job/"+e.jobId+"/cancel",{method:"POST",cache:"no-store"},10000);
   if(r.ok)e.message="CANCELAMENTO SOLICITADO";
 }catch(_){e.message="TENTANDO CANCELAR…"}
 renderList();
}

async function transcribeOne(id,fromBatch){
 var e=entries.find(function(x){return x.id===id});if(!e||e.working)return;
 if(busy&&!fromBatch)return;
 saveActiveEdits();
 e.working=true;acquireWakeLock();renderList();syncActiveFields();showError(el.editorError,"");
 try{
   await uploadFile(e);
   void preuploadNext(e.id);
   var result=await startJobRecoveringFile("/api/transcribe",{file_id:e.remoteId,mode:el.mode.value},e,"transcribe");
   if(!(result.transcript||"").trim())throw new Error("A IA não encontrou fala suficiente neste vídeo.");
   e.transcript=result.transcript||"";e.clipTranscript=result.clip_transcript||"";
   var safePair=ensureSafeCaptionPair(result.top||"",result.bottom||"",e.clipTranscript||e.transcript);
   if(!e.manualCaptionEdited){
     e.top=safePair.top;e.bottom=safePair.bottom;e.captionBlocked=!!(result.caption_blocked||safePair.blocked);
     if(safePair.replaced&&!e.captionBlocked){e.aiWarnings=Array.isArray(e.aiWarnings)?e.aiWarnings:[];e.aiWarnings.push("legenda genérica/diagnóstica foi substituída por fala real")}
   }else{
     e.captionBlocked=false;
     e.aiWarnings=Array.isArray(e.aiWarnings)?e.aiWarnings:[];e.aiWarnings.push("legenda manual preservada");
   }
   e.aiConfidence=Number(result.confidence);
   e.aiQuality=Number(result.clip_quality||result.quality_score);
   e.aiRefined=!!result.refined;
   e.aiRescue=!!result.rescue_used;
   e.aiStrategy=result.strategy||"";
   e.aiPasses=Number(result.passes||1);
   e.speechCoverage=Number(result.speech_coverage);
   e.repetitionRatio=Number(result.repetition_ratio);
   e.captionQuality=Number(result.caption_quality);
   e.captionOverlap=Number(result.caption_overlap);
   e.captionStrategy=result.caption_strategy||"";
   e.captionRescueUsed=!!result.caption_rescue_used;
   e.clipScore=Number(result.clip_score);e.hookScore=Number(result.hook_score);
   e.closureScore=Number(result.closure_score);e.clipSpeechDensity=Number(result.speech_density);
   e.clipReason=result.clip_reason||"";e.clipGapSeconds=Number(result.clip_gap_seconds);
   e.aiWarnings=(Array.isArray(result.warnings)?result.warnings:[]).concat(Array.isArray(e.aiWarnings)?e.aiWarnings:[]).filter(function(v,i,a){return a.indexOf(v)===i});
   if(e.captionBlocked&&result.caption_reason)e.aiWarnings.push(result.caption_reason);
   e.aiTiming=result.timing||{};
   if(Number.isFinite(Number(result.suggested_start))&&Number.isFinite(Number(result.suggested_end))&&Number(result.suggested_end)>Number(result.suggested_start)){
     e.start=Number(result.suggested_start);e.end=Number(result.suggested_end);
   }
   e.status="transcribed";e.progress=100;
   e.message=e.captionBlocked?"TRANSCRIÇÃO PRONTA · A IA NÃO VAI INVENTAR UMA LEGENDA":(e.captionRescueUsed?"IA REOUVIU O VÍDEO · LEGENDA ESPECÍFICA PRONTA":(e.aiRefined?"IA REFINADA + CORTE + LEGENDAS ESPECÍFICOS":"IA + CORTE + LEGENDAS ESPECÍFICOS"));
   activeId=e.id;
   renderList();
   syncActiveFields();
 }catch(err){e.status="error";e.error=err.message;showError(el.editorError,err.message)}
 finally{e.working=false;wakeUsers=1;releaseWakeLock();renderList();syncActiveFields()}
}

async function processOneAuto(id,fromBatch){
 var e=entries.find(function(x){return x.id===id});if(!e||e.working)return;
 if(busy&&!fromBatch)return;
 if(!e.transcript){
   await transcribeOne(id,fromBatch);
   e=entries.find(function(x){return x.id===id});
   if(!e||e.status==="error"||!e.transcript)return;
 }
 if(!e.manualCaptionEdited&&(e.captionBlocked||!captionIsSafe(e.top,e.clipTranscript||e.transcript,"")||!captionIsSafe(e.bottom,e.clipTranscript||e.transcript,e.top))){
   e.captionBlocked=true;e.message="LEGENDA BLOQUEADA PARA EVITAR TEXTO GENÉRICO/INTERNO";
   showError(el.editorError,"A IA não encontrou duas chamadas factuais seguras. A transcrição foi preservada, mas o vídeo não será exportado com texto genérico ou mensagem interna.");
   renderList();syncActiveFields();return;
 }
 await renderOne(id,fromBatch);
}

async function renderOne(id,fromBatch){
 var e=entries.find(function(x){return x.id===id});if(!e||e.working)return;
 if(busy&&!fromBatch)return;
 saveActiveEdits();
 if(!(e.end>e.start)){showError(el.editorError,"O fim do corte precisa ser maior que o início.");return}
 if(captionLooksInternal(e.top)||captionLooksInternal(e.bottom)){showError(el.editorError,"Texto interno da IA foi bloqueado e não pode ser exportado como legenda.");return}
 if(!e.manualCaptionEdited&&(!captionIsSafe(e.top,e.clipTranscript||e.transcript,"")||!captionIsSafe(e.bottom,e.clipTranscript||e.transcript,e.top))){showError(el.editorError,"A legenda automática ainda não está específica o bastante para este vídeo. Reprocesse a IA ou edite as legendas antes de renderizar.");return}
 if(!e.top.trim()||!e.bottom.trim()){showError(el.editorError,"Gere ou revise as duas legendas antes de exportar.");return}
 e.working=true;acquireWakeLock();renderList();syncActiveFields();showError(el.editorError,"");
 try{
   await uploadFile(e);
   void preuploadNext(e.id);
   var result=await startJobRecoveringFile("/api/render",{file_id:e.remoteId,top:e.top,bottom:e.bottom,start:e.start,end:e.end,zoom:e.zoom,posY:e.posY,mode:el.mode.value},e,"render");
   var appliedZoom=Number(result.applied_zoom),appliedPosY=Number(result.applied_posY);
   if(Number.isFinite(appliedZoom)&&Math.abs(appliedZoom-Number(e.zoom||1))>0.001)throw new Error("O servidor não aplicou o zoom selecionado. Renderize novamente.");
   if(Number.isFinite(appliedPosY)&&Math.abs(appliedPosY-Number(e.posY||0))>0.01)throw new Error("O servidor não aplicou a posição vertical selecionada. Renderize novamente.");
   e.status="done";e.progress=100;e.message="VÍDEO PRONTO · ENQUADRAMENTO SALVO";
   e.downloadUrl=result.download_url;e.downloadName=result.name||"video_editado.mp4";
   e.outputStale=false;e.renderedTop=e.top;e.renderedBottom=e.bottom;e.renderedStart=e.start;e.renderedEnd=e.end;e.renderedZoom=Number.isFinite(appliedZoom)?appliedZoom:e.zoom;e.renderedPosY=Number.isFinite(appliedPosY)?appliedPosY:e.posY;
   saveDraft(e);
   e.outputSize=Number(result.size||0);e.outputDuration=Number(result.duration||0);
   e.outputFps=Number(result.fps||0);e.renderSeconds=Number(result.render_seconds||0);
   e.previewUrl=result.preview_url||null;
   renderList();syncActiveFields();
 }catch(err){
   if(isCancelMessage(err&&err.message)){
     e.status=e.transcript?"transcribed":"local";e.error="";e.progress=0;e.message="CANCELADO";
     showError(el.editorError,"");
   }else{
     e.status="error";e.error=err.message;showError(el.editorError,err.message);
   }
 }
 finally{e.working=false;releaseWakeLock();renderList();syncActiveFields()}
}

async function fetchRangeWithRetry(url,start,end,attempts){
 var last=null;
 for(var i=1;i<=attempts;i++){
   try{
     var r=await fetchTimeout(url,{headers:{"Range":"bytes="+start+"-"+end},cache:"no-store"},30000);
     if(r.status===206||r.ok)return await r.arrayBuffer();
     last=new Error("Falha HTTP "+r.status);
   }catch(err){last=err}
   if(i<attempts)await sleep(700*i);
 }
 throw last||new Error("Falha ao baixar parte do vídeo.");
}

async function downloadEntry(id){
 var e=entries.find(function(x){return x.id===id});if(!e||!e.downloadUrl)return;
 if(e.downloading)return;
 e.downloading=true;e.message="ABRINDO DOWNLOAD";e.progress=0;renderList();syncActiveFields();
 try{
   // Android/Brave: nao monte o MP4 inteiro em memoria. Entregue a rota de
   // download diretamente ao gerenciador nativo do navegador.
   var probe=await fetchTimeout(e.downloadUrl,{method:"HEAD",cache:"no-store"},15000);
   if(!probe.ok)throw new Error("Arquivo indisponível no servidor (HTTP "+probe.status+")");
   var a=document.createElement("a");
   a.href=e.downloadUrl;
   a.download=e.downloadName||"video_editado.mp4";
   a.rel="noopener";
   document.body.appendChild(a);
   a.click();
   a.remove();
   e.progress=100;e.message="DOWNLOAD ENVIADO AO NAVEGADOR";e.error="";
   saveDraft(e);renderList();
 }catch(err){
   e.error="Não consegui iniciar o download. O arquivo pode ter expirado ou o servidor pode ter reiniciado.";
   e.message="ERRO NO DOWNLOAD";
   showError(el.editorError,e.error+" Tente processar o MP4 novamente.");
   renderList();
 }finally{
   e.downloading=false;syncActiveFields();
 }
}

async function removeEntry(id){
 var idx=entries.findIndex(function(e){return e.id===id});if(idx<0)return;var e=entries[idx];
 if(busy||e.working)return;
 try{URL.revokeObjectURL(e.localUrl)}catch(_){}
 entries.splice(idx,1);if(activeId===id)activeId=entries.length?entries[Math.min(idx,entries.length-1)].id:null;renderList();syncActiveFields();
}

async function aiAll(){
 if(busy)return;
 busy=true;renderList();
 var ids=entries.filter(function(e){return !e.transcript&&e.status!=="done"&&!e.working}).map(function(e){return e.id});
 var original=el.aiAll.textContent;
 try{
   for(var i=0;i<ids.length;i++){
     el.aiAll.textContent="IA "+(i+1)+"/"+ids.length;
     await transcribeOne(ids[i],true);
   }
 }finally{
   busy=false;el.aiAll.textContent=original;renderList();
 }
}

async function processAll(){
 if(busy)return;
 busy=true;renderList();
 var ids=entries.filter(function(e){return e.status!=="done"&&!e.working}).map(function(e){return e.id});
 var original=el.all.textContent;
 try{
   for(var i=0;i<ids.length;i++){
     el.all.textContent="AUTOMÁTICO "+(i+1)+"/"+ids.length;
     var e=entries.find(function(x){return x.id===ids[i]});if(!e)continue;
     await processOneAuto(e.id,true);
   }
 }finally{
   busy=false;el.all.textContent=original;renderList();loadHistory();
 }
}

function clearAll(){
 if(busy)return;entries.forEach(function(e){try{URL.revokeObjectURL(e.localUrl)}catch(_){}});entries=[];activeId=null;renderList();syncActiveFields();
}

var historyOffset=0,historyLoading=false;
async function downloadHistoryItem(h,button){
 var result=h.result||{},url="/download/"+h.id,name=result.name||"video_editado.mp4";
 if(button){button.disabled=true;button.textContent="Preparando…"}
 try{
   var head=await fetchTimeout(url,{method:"HEAD",cache:"no-store"},15000);
   var size=Number(head.headers.get("content-length")||result.size||0);
   if(!size||size>300*1024*1024){
     location.href=url;return;
   }
   var conn=navigator.connection||{};
   var chunk=Number(conn.downlink||0)>=10?4*1024*1024:2*1024*1024,parts=[];
   for(var start=0;start<size;start+=chunk){
     var end=Math.min(size-1,start+chunk-1);
     parts.push(await fetchRangeWithRetry(url,start,end,6));
     if(button)button.textContent="Baixando "+Math.round(((end+1)/size)*100)+"%";
   }
   var blob=new Blob(parts,{type:"video/mp4"}),u=URL.createObjectURL(blob),a=document.createElement("a");
   a.href=u;a.download=name;document.body.appendChild(a);a.click();a.remove();
   setTimeout(function(){URL.revokeObjectURL(u)},30000);
   if(button)button.textContent="Concluído ✓";
 }catch(_){
   location.href=url;
 }finally{
   if(button)setTimeout(function(){button.disabled=false;button.textContent="Baixar"},1200);
 }
}

async function loadHistory(append){
 if(historyLoading)return;
 historyLoading=true;
 if(!append)historyOffset=0;
 try{
   var r=await fetch("/api/history?limit=20&offset="+historyOffset,{cache:"no-store"}),j=await r.json();
   if(!r.ok)throw new Error(j.error||"Falha ao carregar histórico.");
   var arr=j.items||[];
   if(!append)el.history.innerHTML="";
   if(!arr.length&&!append){
     el.history.innerHTML='<div class="empty">Nenhum vídeo pronto no histórico.</div>';return;
   }
   var oldMore=el.history.querySelector(".history-more");if(oldMore)oldMore.remove();
   arr.forEach(function(h){
     var row=document.createElement("div");row.className="item";row.setAttribute("role","listitem");
     var when=new Date((h.updated_at||0)*1000).toLocaleString();
     var res=h.result||{},name=res.name||"Vídeo editado";
     row.innerHTML='<div class="thumb histthumb">✅</div><div class="info"><div class="name"></div><div class="meta"></div></div><div class="item-actions"><button class="btn btn-good mini" type="button">Baixar</button></div>';
     row.querySelector(".name").textContent=name;
     row.querySelector(".meta").textContent=when+(res.size?" · "+fmtBytes(Number(res.size)):"")+(res.duration?" · "+fmtTime(Number(res.duration)):"")+(res.cached?" · cache":"");
     var thumb=row.querySelector(".histthumb");
     if(res.preview_url){
       var img=document.createElement("img");img.src=res.preview_url;img.alt="";img.loading="lazy";img.decoding="async";
       img.style.cssText="width:100%;height:100%;object-fit:cover;border-radius:10px";
       thumb.textContent="";thumb.appendChild(img);
     }
     var btn=row.querySelector("button");btn.setAttribute("aria-label","Baixar "+name);
     btn.onclick=function(){downloadHistoryItem(h,btn)};
     el.history.appendChild(row);
   });
   historyOffset+=arr.length;
   if(j.has_more){
     var more=document.createElement("button");
     more.type="button";more.className="btn btn-soft history-more";more.textContent="Carregar mais";
     more.onclick=function(){loadHistory(true)};
     el.history.appendChild(more);
   }
 }catch(_){
   if(!append)el.history.innerHTML='<div class="empty">Não foi possível carregar o histórico.</div>';
 }finally{historyLoading=false}
}

el.pick.onclick=function(){el.input.click()};el.input.onchange=function(){addFiles(el.input.files);el.input.value=""};
["dragenter","dragover"].forEach(function(ev){el.drop.addEventListener(ev,function(e){e.preventDefault();el.drop.classList.add("drag")})});
["dragleave","drop"].forEach(function(ev){el.drop.addEventListener(ev,function(e){e.preventDefault();el.drop.classList.remove("drag")})});
el.drop.addEventListener("drop",function(e){addFiles(e.dataTransfer.files)});
el.top.oninput=function(){saveActiveEdits(true);drawCaptions()};el.bottom.oninput=function(){saveActiveEdits(true);drawCaptions()};
el.start.onchange=function(){saveActiveEdits(false)};el.end.onchange=function(){saveActiveEdits(false)};
function framingInput(){saveActiveEdits(false);updatePreviewTransform();var e=getActive();if(e)lastEditorVisualSig=[e.id,e.top||"",e.bottom||"",Number(e.zoom||1).toFixed(4),Number(e.posY||0)].join("|");if(el.editorStatus)el.editorStatus.textContent="ENQUADRAMENTO SALVO · RENDERIZE PARA APLICAR"}
function framingCommit(){saveActiveEdits(false);updatePreviewTransform();renderList();syncActiveFields()}
el.zoom.oninput=framingInput;el.posY.oninput=framingInput;el.zoom.onchange=framingCommit;el.posY.onchange=framingCommit;
el.play.onclick=function(){var e=getActive();if(!e)return;el.preview.currentTime=Math.min(e.end,Math.max(e.start,el.preview.currentTime<e.start||el.preview.currentTime>=e.end?e.start:el.preview.currentTime));if(el.preview.paused)el.preview.play();else el.preview.pause()};
el.preview.ontimeupdate=function(){var e=getActive();if(e&&el.preview.currentTime>=e.end){el.preview.pause();el.preview.currentTime=e.start}};
el.reset.onclick=function(){var e=getActive();if(!e)return;e.start=0;e.end=e.duration;e.zoom=1;e.posY=0;invalidateRenderedOutput(e,"ENQUADRAMENTO RESETADO · RENDERIZE NOVAMENTE");saveDraft(e);renderList();syncActiveFields()};
el.aiBtn.onclick=function(){var e=getActive();if(e)transcribeOne(e.id)};el.export.onclick=function(){var e=getActive();if(e)renderOne(e.id)};el.download.onclick=function(){var e=getActive();if(e)downloadEntry(e.id)};
el.aiAll.onclick=aiAll;el.all.onclick=processAll;el.clear.onclick=clearAll;el.refreshHistory.onclick=function(){if(!document.hidden)loadHistory(false)};
var resizeTimer=null;
document.addEventListener("keydown",function(ev){
 var tag=(document.activeElement&&document.activeElement.tagName||"").toLowerCase();
 var typing=tag==="input"||tag==="textarea"||tag==="select";
 if(ev.key==="Escape"){
   var e=getActive();if(e&&e.working){ev.preventDefault();cancelEntry(e.id)}
   return;
 }
 if(!typing&&ev.ctrlKey&&ev.key==="Enter"){
   var e=getActive();if(e&&!e.working){ev.preventDefault();processOneAuto(e.id)}
 }
 if(!typing&&ev.key===" "&&getActive()){
   ev.preventDefault();el.play.click();
 }
});
window.addEventListener("resize",function(){
 clearTimeout(resizeTimer);resizeTimer=setTimeout(drawCaptions,100);
});

var healthFailures=0;
async function checkHealth(){
 try{
   var r=await fetchTimeout("/api/health",{cache:"no-store"},10000),h=await r.json();
   if(!r.ok||!h.ok)throw new Error();
   healthFailures=0;
   el.server.textContent="ONLINE";
   lastHealth=h;
   var q=Number(h.active_jobs||0),load=(h.load1==null?"—":h.load1);
   var free=(h.disk_free_percent==null?"—":h.disk_free_percent+"%");
   el.diag.textContent="IA: "+(h.ai||h.whisper)+" · "+h.encoder+" · Pipeline "+h.pipeline+" · fila "+q+" · carga "+load+" · disco livre "+free;
   var tel=h.telemetry||{};
   el.diag.title="Memória: "+(h.memory_mb==null?"—":h.memory_mb+" MB")
     +" · Cache hit: "+(tel.cache_hit_rate==null?"—":Math.round(tel.cache_hit_rate*100)+"%")
     +" · API média: "+(tel.avg_request_ms==null?"—":Number(tel.avg_request_ms).toFixed(1)+" ms")
     +" · Erros HTTP: "+Number(tel.http_errors||0);
   if(el.versionBadge)el.versionBadge.textContent="VERSÃO "+String(h.build||h.pipeline||"v?").toUpperCase();
   showError(el.globalError,"");
 }catch(_){
   healthFailures++;
   if(healthFailures>=3){
     el.server.textContent="OFFLINE";
     el.diag.textContent="Servidor temporariamente indisponível. Seus ajustes locais continuam salvos.";
   }else{
     el.server.textContent="RECONECTANDO";
     el.diag.textContent="A conexão oscilou. Tentando reconectar sem perder o lote.";
   }
 }
}
checkHealth();
setInterval(function(){
 if(entries.length&& !busy){try{saveActiveEdits()}catch(_){}}
},5000);
setInterval(function(){if(!document.hidden)checkHealth()},20000);
document.addEventListener("visibilitychange",function(){
 if(document.hidden){try{saveActiveEdits(false)}catch(_){};return}
 checkHealth();
 var e=getActive();if(e&&e.jobId&&!e.working)recoverPriorJob(e);
});

renderListNow();syncActiveFields();drawCaptions();
(window.requestIdleCallback||function(fn){setTimeout(fn,200)})(function(){loadHistory(false)});
window.addEventListener("beforeunload",function(ev){
 if(busy||entries.some(function(e){return e.working})){ev.preventDefault();ev.returnValue="";}
});
window.addEventListener("pageshow",function(ev){
 updateNetBadge();checkHealth();
 if(ev.persisted){
   renderList();syncActiveFields();
   var e=getActive();if(e&&e.jobId&&!e.working)recoverPriorJob(e);
 }
});
window.addEventListener("pagehide",function(){
 try{saveActiveEdits(false)}catch(_){}
 releaseWakeLock();
 entries.forEach(function(e){try{if(e.localUrl)URL.revokeObjectURL(e.localUrl)}catch(_){}});
});
if("serviceWorker" in navigator){
 navigator.serviceWorker.register("/sw.js",{updateViaCache:"none"}).then(function(reg){
   reg.update().catch(function(){});
   if(reg.waiting)reg.waiting.postMessage({type:"SKIP_WAITING"});
   reg.addEventListener("updatefound",function(){
     var worker=reg.installing;if(!worker)return;
     worker.addEventListener("statechange",function(){
       if(worker.state==="installed"&&navigator.serviceWorker.controller){
         worker.postMessage({type:"SKIP_WAITING"});
       }
     });
   });
 }).catch(function(){});
 navigator.serviceWorker.addEventListener("controllerchange",function(){
   try{sessionStorage.setItem("cortes:sw-updated","1")}catch(_){}
   checkHealth();
 });
 navigator.serviceWorker.ready.then(function(reg){
   if(reg&&reg.active)reg.active.postMessage({type:"PING"});
 }).catch(function(){});
}
})();
