
from __future__ import annotations
import json, os, re, shutil, subprocess, threading, time, uuid, zipfile
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import requests
from flask import Flask, request, jsonify, send_file, send_from_directory

BASE = Path(__file__).resolve().parent
STATIC = BASE / "static"
ASSETS = BASE / "assets"
JOBS = BASE / "jobs"
JOBS.mkdir(exist_ok=True)

app = Flask(__name__, static_folder=str(STATIC), static_url_path="")
POOL = ThreadPoolExecutor(max_workers=1)  # Render Free: 0.1 CPU / 512MB, avoid parallel FFmpeg.
LOCK = threading.Lock()

MAX_FILES = 20
MAX_SIZE = 800 * 1024 * 1024
MAX_DURATION = 150.0
PATTERN_ID = "PADRAO_GIRO_V1"

CANVAS_W, CANVAS_H = 1080, 1920
VIDEO_Y, VIDEO_H = 555, 810
TEMPLATE = ASSETS / "template_clean.webp"
BOXES = ASSETS / "boxes_overlay.png"
FONT = "/usr/share/fonts/truetype/dejavu/DejaVuSansCondensed-Bold.ttf"

TOP_Y = [195,270,345,419,492]
BOT_Y = [1408,1491,1575,1659,1743]
TOP_WIDTHS = [612,717,717,717,459]
BOT_WIDTHS = [744,486,738,738,618]

GROQ_API_KEY = os.getenv("GROQ_API_KEY","").strip()
GROQ_STT_MODEL = os.getenv("GROQ_STT_MODEL","whisper-large-v3-turbo")
GROQ_STT_PRECISE_MODEL = os.getenv("GROQ_STT_PRECISE_MODEL","whisper-large-v3")
GROQ_TEXT_MODEL = os.getenv("GROQ_TEXT_MODEL","openai/gpt-oss-20b")

def p_item(item_id): return JOBS / item_id
def jfile(item_id): return p_item(item_id) / "job.json"

def load_job(item_id):
    p=jfile(item_id)
    return json.loads(p.read_text(encoding="utf-8")) if p.exists() else None

def save_job(item_id, **updates):
    with LOCK:
        p=p_item(item_id); p.mkdir(parents=True, exist_ok=True)
        data=load_job(item_id) or {"id":item_id,"created_at":time.time()}
        data.update(updates); data["updated_at"]=time.time()
        tmp=p/"job.tmp"; tmp.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding="utf-8"); tmp.replace(jfile(item_id))
        return data

def ffprobe(path):
    r=subprocess.run([
        "ffprobe","-v","error","-show_entries",
        "format=duration,size:stream=codec_type,codec_name,width,height,r_frame_rate",
        "-of","json",str(path)
    ],capture_output=True,text=True,timeout=30)
    if r.returncode: raise RuntimeError("Não foi possível ler o vídeo.")
    d=json.loads(r.stdout or "{}"); streams=d.get("streams",[])
    v=next((s for s in streams if s.get("codec_type")=="video"),{})
    a=next((s for s in streams if s.get("codec_type")=="audio"),{})
    return {
        "duration":float(d.get("format",{}).get("duration") or 0),
        "size":int(d.get("format",{}).get("size") or 0),
        "video_codec":v.get("codec_name"),"audio_codec":a.get("codec_name"),
        "width":v.get("width"),"height":v.get("height"),"fps":v.get("r_frame_rate"),
        "has_audio":bool(a)
    }

def normalize(s): return re.sub(r"\s+"," ",s or "").strip()

def groq_transcribe(audio_path, mode="auto"):
    if not GROQ_API_KEY:
        raise RuntimeError("GROQ_API_KEY não configurada no servidor.")
    model = GROQ_STT_PRECISE_MODEL if mode == "precise" else GROQ_STT_MODEL
    with open(audio_path,"rb") as f:
        r=requests.post(
            "https://api.groq.com/openai/v1/audio/transcriptions",
            headers={"Authorization":f"Bearer {GROQ_API_KEY}"},
            files={"file":(audio_path.name,f,"audio/mpeg")},
            data={"model":model,"language":"pt","response_format":"json","temperature":"0"},
            timeout=180
        )
    if r.status_code>=400:
        raise RuntimeError(f"Falha na transcrição Groq ({r.status_code}): {r.text[:220]}")
    return normalize(r.json().get("text",""))

def _caption_words(s):
    return [w for w in re.findall(r"[A-ZÁÉÍÓÚÂÊÔÃÕÇ0-9%$€£.,-]+", (s or "").upper()) if len(w) > 2]

def _too_similar(a,b):
    A=set(_caption_words(a)); B=set(_caption_words(b))
    if not A or not B: return True
    return len(A & B) / max(1, min(len(A),len(B))) > 0.58

def _numbers_ok(caption, transcript):
    nums=lambda x:set(re.findall(r"(?:R\$\s*)?\d[\d.,%]*", x or ""))
    t=nums(transcript); c=nums(caption)
    return all(n in t for n in c)

def groq_captions(transcript):
    if not transcript: return "",""
    if not GROQ_API_KEY:
        return fallback_captions(transcript)
    base_rules = f"""Você cria DUAS chamadas factuais para um vídeo vertical de notícia.
REGRAS OBRIGATÓRIAS:
- Use SOMENTE fatos presentes na transcrição. Não deduza, aconselhe, julgue ou complete lacunas.
- Nunca invente valores, datas, nomes, causas, consequências ou recomendações.
- Português do Brasil correto, CAIXA ALTA.
- Topo: QUEM/O QUE ACONTECEU.
- Base: um SEGUNDO fato verificável, resultado ou detalhe já dito na transcrição.
- Topo e base não podem repetir a mesma informação.
- Evite linguagem de conselho como DEVE, DEVERIA, PRECISA, TEM QUE, a menos que essas palavras façam parte de uma fala citada essencial.
- Preserve exatamente nomes próprios, números, valores e datas.
- Cada legenda: no máximo 13 palavras e no máximo 86 caracteres.
- Se faltar informação para uma segunda chamada segura, resuma outro detalhe literal da transcrição; nunca invente.
Responda SOMENTE JSON válido: {{"top":"...","bottom":"..."}}

TRANSCRIÇÃO:
{transcript[:12000]}"""
    for attempt in range(2):
        prompt = base_rules + ("\nREVISE COM MAIS RIGOR: a tentativa anterior falhou validação. Seja ainda mais literal e curto." if attempt else "")
        try:
            r=requests.post(
                "https://api.groq.com/openai/v1/chat/completions",
                headers={"Authorization":f"Bearer {GROQ_API_KEY}","Content-Type":"application/json"},
                json={
                    "model":GROQ_TEXT_MODEL,
                    "temperature":0.0,
                    "messages":[{"role":"user","content":prompt}],
                    "response_format":{"type":"json_object"}
                },
                timeout=90
            )
            if r.status_code>=400: continue
            content=r.json()["choices"][0]["message"]["content"]
            d=json.loads(content)
            top=normalize(d.get("top","")).upper()
            bottom=normalize(d.get("bottom","")).upper()
            valid=(top and bottom and top!=bottom and len(top)<=86 and len(bottom)<=86
                   and len(top.split())<=13 and len(bottom.split())<=13
                   and not _too_similar(top,bottom)
                   and _numbers_ok(top,transcript) and _numbers_ok(bottom,transcript))
            if valid: return top,bottom
        except Exception:
            pass
    return fallback_captions(transcript)

def fallback_captions(text):
    clean=normalize(text)
    sents=[normalize(x) for x in re.split(r"(?<=[.!?])\s+",clean) if normalize(x)]
    if not sents:
        return "",""
    def clip(s):
        words=s.split()[:13]
        out=" ".join(words).upper()
        while len(out)>86 and len(words)>4:
            words=words[:-1]; out=" ".join(words).upper()
        return out
    top=clip(sents[0])
    bottom=""
    for cand in sents[1:]:
        c=clip(cand)
        if c and not _too_similar(top,c):
            bottom=c; break
    if not bottom:
        words=clean.split()
        bottom=clip(" ".join(words[13:26])) if len(words)>13 else clip(clean)
    return top,bottom

def esc(s):
    return (s or "").replace("\\","\\\\").replace(":","\\:").replace("'","\\'").replace("%","\\%")

def wrap_caption(text,widths):
    words=normalize(text).upper().split()
    if not words: return ["" for _ in widths],69,False
    for fs in range(69,35,-1):
        lines=[];i=0
        for maxw in widths:
            cur=[]
            while i<len(words):
                cand=" ".join(cur+[words[i]])
                if cur and len(cand)*fs*.53 > maxw-35: break
                cur.append(words[i]);i+=1
            lines.append(" ".join(cur))
        if i>=len(words): return lines,fs,False
    return lines,36,True

def render_video(item_id,src,top,bottom,zoom=1.02,xpos=0,ypos=0):
    out=p_item(item_id)/"final.mp4"
    tlines,tsize,tover=wrap_caption(top,TOP_WIDTHS)
    blines,bsize,bover=wrap_caption(bottom,BOT_WIDTHS)
    if tover or bover:
        raise RuntimeError("Legenda grande demais para o padrão. Encurte antes de exportar.")

    m=ffprobe(src);sw,sh=m["width"] or 720,m["height"] or 1280
    scale=max(CANVAS_W/sw,VIDEO_H/sh)*float(zoom)
    ww=max(CANVAS_W,int(round(sw*scale/2)*2));hh=max(VIDEO_H,int(round(sh*scale/2)*2))
    mx=max(0,(ww-CANVAS_W)//2);my=max(0,(hh-VIDEO_H)//2)
    cx=max(0,min(ww-CANVAS_W,mx+int((float(xpos)/20)*mx)))
    cy=max(0,min(hh-VIDEO_H,my+int((float(ypos)/20)*my)))

    filters=[
        f"[1:v]scale={CANVAS_W}:{CANVAS_H}[bg]",
        f"[0:v]scale={ww}:{hh},crop={CANVAS_W}:{VIDEO_H}:{cx}:{cy}[vid]",
        f"[bg][vid]overlay=0:{VIDEO_Y}[tmp]",
        f"[2:v]scale={CANVAS_W}:{CANVAS_H}[bx]",
        "[tmp][bx]overlay=0:0[base]"
    ]
    chain="[base]";n=0
    for line,y in list(zip(tlines,TOP_Y))+list(zip(blines,BOT_Y)):
        if not line: continue
        fs=tsize if y in TOP_Y else bsize
        nxt=f"d{n}";n+=1
        filters.append(f"{chain}drawtext=fontfile='{FONT}':text='{esc(line)}':fontcolor=black:fontsize={fs}:x=(w-text_w)/2:y={y}-text_h/2[{nxt}]")
        chain=f"[{nxt}]"
    filters.append(f"{chain}null[outv]")

    # ultrafast: much more appropriate for Render's tiny free CPU.
    r=subprocess.run([
        "ffmpeg","-y","-i",str(src),"-loop","1","-i",str(TEMPLATE),"-loop","1","-i",str(BOXES),
        "-filter_complex",";".join(filters),
        "-map","[outv]","-map","0:a?",
        "-r","30","-c:v","libx264","-profile:v","high","-pix_fmt","yuv420p",
        "-preset","ultrafast","-crf","22",
        "-c:a","aac","-b:a","128k","-movflags","+faststart","-shortest",str(out)
    ],capture_output=True,text=True,timeout=900)
    if r.returncode:
        raise RuntimeError("Falha no FFmpeg: "+(r.stderr[-500:] if r.stderr else "erro"))
    return out

def process_item(item_id):
    j=load_job(item_id)
    if not j:return
    src=Path(j["source"])
    try:
        save_job(item_id,state="validating",progress=5,stage="VALIDANDO")
        meta=ffprobe(src)
        if not meta["duration"] or meta["duration"]>MAX_DURATION: raise RuntimeError("Vídeo precisa ter até 2min30.")
        if not meta["has_audio"]: raise RuntimeError("Vídeo sem áudio.")
        save_job(item_id,metadata=meta)

        audio=p_item(item_id)/"audio.mp3"
        save_job(item_id,state="extracting",progress=15,stage="EXTRAINDO ÁUDIO")
        r=subprocess.run(["ffmpeg","-y","-i",str(src),"-vn","-ac","1","-ar","16000","-b:a","48k",str(audio)],
                         capture_output=True,text=True,timeout=120)
        if r.returncode: raise RuntimeError("Falha ao extrair áudio.")

        save_job(item_id,state="transcribing",progress=30,stage="TRANSCREVENDO NO SERVIDOR")
        transcript=groq_transcribe(audio, j.get("mode","auto"))
        save_job(item_id,transcript=transcript,progress=62)

        save_job(item_id,state="captioning",progress=70,stage="CRIANDO LEGENDAS")
        top,bottom=groq_captions(transcript)
        save_job(item_id,top=top,bottom=bottom,progress=78)

        save_job(item_id,state="rendering",progress=82,stage="RENDERIZANDO MP4")
        final=render_video(item_id,src,top,bottom)
        save_job(item_id,state="ready",progress=100,stage="PRONTO",final=str(final))
        try: audio.unlink(missing_ok=True)
        except Exception: pass
    except Exception as e:
        save_job(item_id,state="error",progress=0,stage="ERRO",error=str(e))

@app.get("/")
def index(): return send_from_directory(STATIC,"index.html")

@app.get("/assets/<path:name>")
def asset(name): return send_from_directory(ASSETS,name)

@app.get("/health")
def health():
    return jsonify(ok=True,version="V11",pattern=PATTERN_ID,groq=bool(GROQ_API_KEY),render_server=True)

@app.post("/api/upload")
def upload():
    files=request.files.getlist("videos")
    if not files:return jsonify(error="Nenhum vídeo recebido."),400
    if len(files)>MAX_FILES:return jsonify(error="Máximo de 20 vídeos."),400
    batch_id=uuid.uuid4().hex[:12];jobs=[]
    mode=(request.form.get("mode") or "auto").strip().lower()
    if mode not in {"auto","precise"}: mode="auto"
    for f in files:
        item_id=uuid.uuid4().hex[:18];p=p_item(item_id);p.mkdir(parents=True,exist_ok=True)
        ext=Path(f.filename or "video.mp4").suffix or ".mp4";dest=p/f"input{ext}"
        # Stream to disk; don't read entire upload into RAM.
        f.save(dest)
        if dest.stat().st_size>MAX_SIZE:
            shutil.rmtree(p,ignore_errors=True);return jsonify(error=f"{f.filename}: acima de 800 MB."),413
        j=save_job(item_id,batch_id=batch_id,filename=f.filename,source=str(dest),mode=mode,state="queued",progress=1,stage="NA FILA",cancelled=False)
        jobs.append(j);POOL.submit(process_item,item_id)
    return jsonify(batch_id=batch_id,jobs=jobs)

@app.get("/api/batch/<batch_id>")
def batch(batch_id):
    arr=[]
    for p in JOBS.iterdir():
        if not p.is_dir():continue
        j=load_job(p.name)
        if j and j.get("batch_id")==batch_id:arr.append(j)
    arr.sort(key=lambda x:x.get("created_at",0))
    return jsonify(batch_id=batch_id,jobs=arr)

@app.post("/api/item/<item_id>/rerender")
def rerender(item_id):
    j=load_job(item_id)
    if not j:return jsonify(error="Não encontrado."),404
    b=request.get_json(silent=True) or {}
    top=normalize(b.get("top",j.get("top","")));bottom=normalize(b.get("bottom",j.get("bottom","")))
    try:
        final=render_video(item_id,Path(j["source"]),top,bottom,float(b.get("zoom",1.02)),float(b.get("x",0)),float(b.get("y",0)))
        return jsonify(save_job(item_id,top=top,bottom=bottom,state="ready",progress=100,stage="PRONTO",final=str(final)))
    except Exception as e:
        return jsonify(save_job(item_id,state="error",stage="ERRO",error=str(e))),400

@app.get("/api/item/<item_id>/download")
def download(item_id):
    j=load_job(item_id)
    if not j or not j.get("final"):return jsonify(error="Ainda não pronto."),404
    return send_file(j["final"],as_attachment=True,download_name=f"GIRO_{Path(j['filename']).stem}.mp4",mimetype="video/mp4")

@app.get("/api/batch/<batch_id>/zip")
def batch_zip(batch_id):
    ready=[]
    for p in JOBS.iterdir():
        if not p.is_dir():continue
        j=load_job(p.name)
        if j and j.get("batch_id")==batch_id and j.get("state")=="ready" and j.get("final"):ready.append(j)
    if not ready:return jsonify(error="Nenhum vídeo pronto."),404
    z=JOBS/f"{batch_id}.zip"
    with zipfile.ZipFile(z,"w",zipfile.ZIP_STORED) as zf:
        for i,j in enumerate(ready,1):
            zf.write(j["final"],f"GIRO_{i:02d}_{Path(j['filename']).stem}.mp4")
    return send_file(z,as_attachment=True,download_name=f"GIRO_LOTE_{batch_id}.zip")

if __name__=="__main__":
    app.run(host="0.0.0.0",port=int(os.getenv("PORT","10000")),threaded=True)
