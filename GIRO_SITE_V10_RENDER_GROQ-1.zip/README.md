# Giro da Notícia V11 — correção de sessão e legendas

Correções principais:
- não exibe legendas antigas quando a fila está 0/0;
- se o Render reiniciar e perder os jobs temporários, a interface limpa o vídeo/legendas antigos e avisa que a sessão expirou;
- botões de download e rerender ficam desativados quando não existe vídeo pronto;
- o editor acompanha as legendas geradas pelo servidor sem manter texto velho;
- evita colisão quando dois vídeos têm o mesmo nome;
- modo AUTO usa whisper-large-v3-turbo; modo PRECISO usa whisper-large-v3;
- geração das legendas foi endurecida para não inventar conselho, valor, data ou consequência;
- números gerados precisam existir na transcrição;
- topo e base passam por verificação de repetição;
- health informa version=V11.

O padrão visual PADRAO_GIRO_V1 continua bloqueado e não foi alterado.
