# Giro da Notícia V10 — Render + Groq

## Objetivo
Versão simplificada para hospedagem no Render Free:
- upload de até 20 vídeos;
- vídeo salvo por streaming no disco (sem carregar o arquivo inteiro em RAM);
- FFmpeg extrai áudio mono 16 kHz em MP3 48 kbps;
- Groq Whisper Large V3 Turbo faz a transcrição;
- Groq gera as duas legendas;
- FFmpeg renderiza 1080x1920;
- download individual e ZIP;
- padrão visual PADRAO_GIRO_V1 permanece bloqueado.

## Publicar no Render
1. Coloque estes arquivos em um repositório GitHub.
2. No Render: New > Blueprint ou Web Service.
3. Se usar Blueprint, selecione este repositório e o `render.yaml`.
4. Crie a variável secreta `GROQ_API_KEY`.
5. Faça o deploy.
6. Abra `/health` para confirmar `groq: true`.

## Limitação do plano gratuito
O Render Free tem CPU/RAM bem limitados e pode desligar por inatividade. Esta versão foi ajustada para teste e processa um render por vez.
