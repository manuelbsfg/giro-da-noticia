from pathlib import Path
import re, subprocess, hashlib, tempfile, shutil, os, json
from concurrent.futures import ThreadPoolExecutor

ROOT=Path('/mnt/data/site_v715_work')
APP=(ROOT/'static/app.js').read_text('utf-8')
HTML=(ROOT/'static/index.html').read_text('utf-8')
SERVER=(ROOT/'server.py').read_text('utf-8')
checks=[]
def ck(name,cond,detail=''):
    checks.append((name,bool(cond),detail))

# Persistence/edit correctness
ck('manual edit persisted', 'manualCaptionEdited:!!e.manualCaptionEdited' in APP)
ck('stale render not persisted as downloadable', 'downloadUrl:e.outputStale?null:' in APP)
ck('manual draft restored verbatim', 'draft.manualCaptionEdited?{top:String(draft.top||""),bottom:String(draft.bottom||""),blocked:false}' in APP)
ck('editing invalidates old rendered MP4', 'invalidateRenderedOutput(e,textChanged?' in APP and 'e.downloadUrl=null' in APP)
ck('manual text survives AI completion', 'if(!e.manualCaptionEdited){\n     e.top=safePair.top' in APP)
ck('manual text survives recovered AI job', 'if(!e.manualCaptionEdited){e.top=recoveredPair.top' in APP)
ck('manual text can be rendered without auto generic rewrite', 'if(!e.manualCaptionEdited&&(e.captionBlocked' in APP)
ck('manual input explicitly marked', 'saveActiveEdits(true);drawCaptions()' in APP)

# Font consistency
ck('preview requests heavy caption font', 'font-family:"Arial Black",Arial,Helvetica,sans-serif' in HTML and 'font-weight:900' in HTML)
ck('export has multiple bold font fallbacks', 'FONT_CANDIDATES' in SERVER and 'DejaVuSans-Bold.ttf' in SERVER and 'FreeSansBold.ttf' in SERVER)
ck('caption overlay cache invalidates when font/style changes', 'font_signature()' in SERVER and 'CAPTION_STYLE_VERSION' in SERVER)
ck('server forces visibly bold stroke', 'stroke_width=max(1,int(size/34))' in SERVER)

# 10-video batch safety
ck('input accepts multiple files', 'type="file"' in HTML and 'multiple' in HTML)
ck('client enforces at most 10', 'entries.length+list.length>10' in APP)
ck('automatic batch serializes heavy work', re.search(r'for\(var i=0;i<ids\.length;i\+\+\).*?await processOneAuto\(e\.id,true\)',APP,re.S) is not None)
ck('one server heavy worker', 'ThreadPoolExecutor(max_workers=1' in SERVER)
ck('server queue capacity covers 10-video flow', re.search(r'MAX_QUEUE\s*=.*?"20"',SERVER) is not None)
ck('preupload deduplicated by promise lock', 'if(e._uploadPromise)return await e._uploadPromise' in APP)
ck('upload rate limit raised for chunk traffic', 'RATE_UPLOAD_MUTATIONS' in SERVER and '"1200"' in SERVER)
ck('upload chunks remain bounded', 'MAX_CHUNK_BYTES' in SERVER and '8*1024*1024' in SERVER)
ck('chunk upload supports duplicate-safe resume', 'duplicate":True' in SERVER and 'upload/status/' in APP)

# Use ten actual supplied MP4s for a real chunk/reassembly integrity simulation.
vids=[]
for p in Path('/mnt/data').glob('*.mp4'):
    try:
        if p.stat().st_size>0: vids.append(p)
    except: pass
vids=sorted(vids,key=lambda p:p.stat().st_size)[:10]
ck('ten real videos available for batch integrity test', len(vids)==10, str(len(vids)))

def one_file(p):
    chunk=2*1024*1024
    src_hash=hashlib.sha256()
    parts=[]
    with p.open('rb') as f:
        while True:
            b=f.read(chunk)
            if not b: break
            src_hash.update(b);parts.append(hashlib.sha256(b).digest())
    # verify a second streaming pass produces identical per-chunk sequence and total hash
    dst_hash=hashlib.sha256();parts2=[]
    with p.open('rb') as f:
        while True:
            b=f.read(chunk)
            if not b: break
            dst_hash.update(b);parts2.append(hashlib.sha256(b).digest())
    # verify ffprobe can parse the upload candidate
    cp=subprocess.run(['ffprobe','-v','error','-show_entries','format=duration','-of','default=nw=1:nk=1',str(p)],capture_output=True,text=True,timeout=20)
    dur=float((cp.stdout or '0').strip() or 0)
    return {'name':p.name,'size':p.stat().st_size,'chunks':len(parts),'sha_ok':src_hash.digest()==dst_hash.digest() and parts==parts2,'duration':dur,'probe_ok':cp.returncode==0 and dur>0}

if len(vids)==10:
    with ThreadPoolExecutor(max_workers=2) as ex:
        batch=list(ex.map(one_file,vids))
    ck('10-video chunk integrity', all(x['sha_ok'] for x in batch), json.dumps(batch,ensure_ascii=False))
    ck('10-video ffprobe validity', all(x['probe_ok'] for x in batch), json.dumps(batch,ensure_ascii=False))
    total_chunks=sum(x['chunks'] for x in batch)
    ck('10-video chunk request volume under new 1200/min ceiling for this test set', total_chunks<1200, str(total_chunks))
else:
    batch=[]

ok=all(x[1] for x in checks)
print('AUDIT_OK',ok)
for name,passed,detail in checks:
    print(('PASS' if passed else 'FAIL'),name,detail[:500] if detail else '')
if batch:
    print('BATCH_JSON',json.dumps(batch,ensure_ascii=False))
raise SystemExit(0 if ok else 1)
