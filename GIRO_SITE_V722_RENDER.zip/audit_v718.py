from pathlib import Path
import ast,re,json
src=Path('server.py').read_text('utf-8')
assert 'PIPELINE_VERSION = "v7.18"' in src
assert 'GEMINI_API_KEY = os.getenv("GEMINI_API_KEY"' in src
assert 'gemini-3.5-transcribe' in src
assert 'gemini-3.8-flash' in src
assert 'Whisper fallback' in src
assert 'x-goog-api-key' in src
js=Path('static/app.js').read_text('utf-8')
assert 'GEMINI_API_KEY' not in js
assert 'AIza' not in js
# Execute only pure parser helpers, without Flask/faster-whisper.
need={'clean_text','_jaccard','_normalized_words','_token_set','_dedupe_segments','_seconds_offset','_gemini_response_text','_gemini_word_rows','_word_rows_to_segments','_synthetic_segments','_json_object_from_text'}
tree=ast.parse(src)
selected=[]
for n in tree.body:
    if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name in need:
        selected.append(n)
mod=ast.Module(body=selected,type_ignores=[])
ns={'re':re,'json':json}
exec(compile(mod,'server.py','exec'),ns)
sample={
 'candidates':[{'content':{'parts':[
   {'text':'João confirmou a mudança nesta manhã.'},
   {'audioTranscription':{'words':[
     {'word':'João','startOffset':'0.20s','endOffset':'0.50s'},
     {'word':'confirmou','startOffset':'0.52s','endOffset':'0.95s'},
     {'word':'a','startOffset':'0.97s','endOffset':'1.05s'},
     {'word':'mudança.','startOffset':'1.07s','endOffset':'1.55s'},
     {'word':'A','startOffset':'2.00s','endOffset':'2.10s'},
     {'word':'decisão','startOffset':'2.12s','endOffset':'2.55s'},
     {'word':'vale','startOffset':'2.56s','endOffset':'2.80s'},
     {'word':'hoje.','startOffset':'2.82s','endOffset':'3.20s'}
   ]}}
 ]}}]
}
text=ns['_gemini_response_text'](sample)
rows=ns['_gemini_word_rows'](sample)
segments=ns['_word_rows_to_segments'](rows)
assert 'João confirmou' in text
assert len(rows)==8
assert len(segments)>=2
assert abs(segments[0]['start']-0.2)<0.01
assert ns['_json_object_from_text']('```json\n{"top":"A","bottom":"B"}\n```')['bottom']=='B'
print('V7.18 AUDIT OK')
print('Gemini transcript model: gemini-3.5-transcribe')
print('Gemini caption model: gemini-3.8-flash')
print('Whisper fallback: enabled')
print('Browser secret exposure: none detected')
print('Word timestamp parser: OK')
print('Caption JSON parser: OK')
